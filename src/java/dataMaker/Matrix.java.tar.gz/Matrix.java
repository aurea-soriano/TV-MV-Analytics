/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dataMaker;

import color.PseudoRainbow;
import java.awt.Color;
import java.awt.image.BufferedImage;
import java.util.Arrays;
import utils.Measures;
import utils.Measures;

/**
 *
 * @author aurea
 */
public class Matrix {

    private double[][] V = null;
    private int rows = 0;
    private int cols = 0;
    private double minValue = Double.POSITIVE_INFINITY;
    private double maxValue = Double.NEGATIVE_INFINITY;

    public double[][] getV() {
        return V;
    }

    public void setV(double[][] v) {
        V = v;
        if (v != null) {
            rows = v.length;
            if (v.length > 0) {
                cols = v[0].length;
            }
        }
    }

    public int getRows() {
        return rows;
    }

    public void setRows(int rowsOfVMatrix) {
        rows = rowsOfVMatrix;
    }

    public void setValue(int row, int col, double value) {
        this.V[row][col] = value;
    }

    public double getValue(int row, int col) {
        return this.V[row][col];
    }

    public int getCols() {
        return cols;
    }

    public void setCols(int colsOfVMatrix) {
        cols = colsOfVMatrix;
    }

    public Matrix() {
        V = new double[0][0];
    }

    public Matrix(int rowsSize, int colSize) {
        rows = rowsSize;
        cols = colSize;
        V = new double[rowsSize][colSize];
        fillZeros();
    }

    public Matrix(Matrix m) {
        V = new double[m.getRows()][m.getCols()];
        for (int i = 0; i < m.getRows(); i++) {
            System.arraycopy(m.V[i], 0, this.V[i], 0, m.getCols());
        }
    }

    public void fillZeros() {

        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < cols; j++) {
                this.V[i][j] = 0.0;
            }
        }
    }

    public void print() {

        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < cols; j++) {
                System.out.print(this.V[i][j] + " ");
            }
            System.out.println();
        }
    }

    public double[][] normalize(double minValueGeneral, double maxValueGeneral) {
        /*    double minTmp, maxTmp;
         for (int i = 0; i < rows; i++) {
         minTmp = Arrays.stream(V[i]).min().getAsDouble();
         maxTmp = Arrays.stream(V[i]).max().getAsDouble();
         if (minTmp < minValue) {
         minValue = minTmp;
         }
         if (maxTmp > maxValue) {
         maxValue = maxTmp;
         }
         }
         */
        double[][] normalizedV = new double[rows][cols];
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < cols; j++) {
                double value = Measures.minmax(V[i][j], minValueGeneral, maxValueGeneral, 0.0, 255.0);
                
                normalizedV[i][j] = value;
                
                //System.out.println("min :"+minValueGeneral+" max: "+maxValueGeneral+" value "+V[i][j]+" transform "+value);

            }

        }
        return normalizedV;
    }

    public BufferedImage getBufferedImage() {
        BufferedImage b = new BufferedImage(cols, rows, 3);
        Color[] colors = (new PseudoRainbow()).getColorScale();
        for (int y = 0; y < cols; y++) {
            for (int x = 0; x < rows; x++) {
                int rgb = colors[(int) V[x][y]].getRGB();
                b.setRGB(y, x, rgb);
            }
        }

        return b;

    }

}
