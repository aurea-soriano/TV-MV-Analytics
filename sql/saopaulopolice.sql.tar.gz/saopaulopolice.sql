--
-- PostgreSQL database dump
--

-- Dumped from database version 9.5.10
-- Dumped by pg_dump version 9.5.10

SET statement_timeout = 0;
SET lock_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET search_path = public, pg_catalog;

--
-- Name: _final_median(anyarray); Type: FUNCTION; Schema: public; Owner: aurea
--

CREATE FUNCTION _final_median(anyarray) RETURNS numeric
    LANGUAGE sql IMMUTABLE
    AS $_$ 
  WITH q AS
  (
     SELECT val
     FROM unnest($1) val
     WHERE VAL IS NOT NULL
     ORDER BY 1
  ),
  cnt AS
  (
    SELECT COUNT(*) AS c FROM q
  )
  SELECT AVG(val)::numeric

  FROM 
  (
    SELECT val FROM q
    LIMIT  2 - MOD((SELECT c FROM cnt), 2)
    OFFSET GREATEST(CEIL((SELECT c FROM cnt) / 2.0) - 1,0)  
  ) q2;
$_$;


ALTER FUNCTION public._final_median(anyarray) OWNER TO aurea;

--
-- Name: getavgbytimeinterval(text[], integer, timestamp without time zone, timestamp without time zone, numeric); Type: FUNCTION; Schema: public; Owner: aurea
--

CREATE FUNCTION getavgbytimeinterval(saopaulopoliceattributes text[], area integer, initdate timestamp without time zone, enddate timestamp without time zone, valuetimeinterval numeric) RETURNS TABLE(round numeric[], instance_time timestamp without time zone)
    LANGUAGE plpgsql
    AS $$
DECLARE 
query1 text;
attr integer;
numAttr integer;
BEGIN
numAttr:= array_length(saopaulopoliceattributes,1);	
query1 := 'select array(select round(unnest(array[';
 FOR attr IN SELECT generate_subscripts( saopaulopoliceattributes, 1 ) LOOP
          query1 := query1 ||'avg(instance.'||saopaulopoliceattributes[attr]||')';
	IF attr< numAttr THEN
    query1 := query1 ||',';
  END IF;
    END loop;

query1 := query1 ||']),6)) as rounds, 
 to_timestamp(floor((extract(''epoch'' from instance_time) /'|| valuetimeinterval||' )) * '|| valuetimeinterval||') 
    AT TIME ZONE ''UTC'' as interval_alias
FROM instance
where ';


query1 := query1 ||' area_id = '||area||' and date_trunc(''day'',  instance_time ) >=  date_trunc(''day'',  TIMESTAMP '''||initDate ||''') and  
date_trunc(''day'',  instance_time ) <= date_trunc(''day'',  TIMESTAMP '''||endDate||''')  GROUP BY interval_alias
ORDER BY interval_alias';
    RETURN QUERY EXECUTE query1;  
  RETURN;
END;
$$;


ALTER FUNCTION public.getavgbytimeinterval(saopaulopoliceattributes text[], area integer, initdate timestamp without time zone, enddate timestamp without time zone, valuetimeinterval numeric) OWNER TO aurea;

--
-- Name: getavgbytimeintervalforallareas(text[], timestamp without time zone, timestamp without time zone, numeric); Type: FUNCTION; Schema: public; Owner: aurea
--

CREATE FUNCTION getavgbytimeintervalforallareas(saopaulopoliceattributes text[], initdate timestamp without time zone, enddate timestamp without time zone, valuetimeinterval numeric) RETURNS TABLE(round numeric[], instance_time timestamp without time zone)
    LANGUAGE plpgsql
    AS $$
DECLARE 
query1 text;
attr integer;
numAttr integer;
BEGIN
numAttr:= array_length(saopaulopoliceattributes,1);	
query1 := 'select array(select round(unnest(array[';
 FOR attr IN SELECT generate_subscripts( saopaulopoliceattributes, 1 ) LOOP
          query1 := query1 ||'avg(instance.'||saopaulopoliceattributes[attr]||')';
	IF attr< numAttr THEN
    query1 := query1 ||',';
  END IF;
    END loop;

query1 := query1 ||']),6)) as rounds, 
 to_timestamp(floor((extract(''epoch'' from instance_time) /'|| valuetimeinterval||' )) * '|| valuetimeinterval||') 
    AT TIME ZONE ''UTC'' as interval_alias
FROM instance
where ';


query1 := query1 ||' date_trunc(''day'',  instance_time ) >=  date_trunc(''day'',  TIMESTAMP '''||initDate ||''') and  
date_trunc(''day'',  instance_time ) <= date_trunc(''day'',  TIMESTAMP '''||endDate||''')  GROUP BY interval_alias
ORDER BY interval_alias';
    RETURN QUERY EXECUTE query1;  
  RETURN;
END;
$$;


ALTER FUNCTION public.getavgbytimeintervalforallareas(saopaulopoliceattributes text[], initdate timestamp without time zone, enddate timestamp without time zone, valuetimeinterval numeric) OWNER TO aurea;

--
-- Name: getdatabyintervaldates(text[], text, integer, timestamp without time zone, timestamp without time zone); Type: FUNCTION; Schema: public; Owner: aurea
--

CREATE FUNCTION getdatabyintervaldates(saopaulopoliceattributes text[], attributetarget text, area integer, initdate timestamp without time zone, enddate timestamp without time zone) RETURNS TABLE(valuesattributes numeric[], valueclassificationattribute numeric, instance_time timestamp without time zone)
    LANGUAGE plpgsql
    AS $$
DECLARE 
query1 text;
attr integer;
numAttr integer;
BEGIN
numAttr:= array_length(saopaulopoliceattributes,1);	
query1 := 'select array(select round(unnest(array[';
 FOR attr IN SELECT generate_subscripts( saopaulopoliceattributes, 1 ) LOOP
          query1 := query1 ||' instance.'||saopaulopoliceattributes[attr]||' ';
	IF attr< numAttr THEN
    query1 := query1 ||',';
  END IF;
    END loop;

query1 := query1 ||']),4)) as valuesattributes, instance.'||attributeTarget||' as valueclassificationattribute,
 date_trunc(''hour'',instance_time) as instance_time';

query1 := query1 ||' FROM instance
where ';
FOR attr IN SELECT generate_subscripts( saopaulopoliceattributes, 1 ) LOOP
       query1 := query1 ||'instance.'||saopaulopoliceattributes[attr]||'!= ''NaN''  and ';
END loop;
query1 := query1 ||' area_id = '||area||' and date_trunc(''day'',  instance_time ) >=  date_trunc(''day'',  TIMESTAMP '''||initDate ||''') and  
date_trunc(''day'',  instance_time ) <= date_trunc(''day'',  TIMESTAMP '''||endDate||''') ';


    RETURN QUERY EXECUTE query1;  
  RETURN;
END;
$$;


ALTER FUNCTION public.getdatabyintervaldates(saopaulopoliceattributes text[], attributetarget text, area integer, initdate timestamp without time zone, enddate timestamp without time zone) OWNER TO aurea;

--
-- Name: getdatabyintervaldatesforallsource1(text[], text, timestamp without time zone, timestamp without time zone); Type: FUNCTION; Schema: public; Owner: aurea
--

CREATE FUNCTION getdatabyintervaldatesforallsource1(saopaulopoliceattributes text[], attributetarget text, initdate timestamp without time zone, enddate timestamp without time zone) RETURNS TABLE(valuesattributes numeric[], valueclassificationattribute numeric, instance_time timestamp without time zone)
    LANGUAGE plpgsql
    AS $$
DECLARE 
query1 text;
attr integer;
numAttr integer;
BEGIN
numAttr:= array_length(saopaulopoliceattributes,1);	
query1 := 'select array(select round(unnest(array[';
 FOR attr IN SELECT generate_subscripts( saopaulopoliceattributes, 1 ) LOOP
          query1 := query1 ||' instance.'||saopaulopoliceattributes[attr]||' ';
	IF attr< numAttr THEN
    query1 := query1 ||',';
  END IF;
    END loop;

query1 := query1 ||']),4)) as valuesattributes, instance.'||attributeTarget||' as valueclassificationattribute,
 date_trunc(''hour'',instance_time) as instance_time';

query1 := query1 ||' FROM instance
where ';
FOR attr IN SELECT generate_subscripts( saopaulopoliceattributes, 1 ) LOOP
       query1 := query1 ||'instance.'||saopaulopoliceattributes[attr]||'!= ''NaN''  and ';
END loop;
query1 := query1 ||' date_trunc(''day'',  instance_time ) >=  date_trunc(''day'',  TIMESTAMP '''||initDate ||''') and  
date_trunc(''day'',  instance_time ) <= date_trunc(''day'',  TIMESTAMP '''||endDate||''') ';


    RETURN QUERY EXECUTE query1;  
  RETURN;
END;
$$;


ALTER FUNCTION public.getdatabyintervaldatesforallsource1(saopaulopoliceattributes text[], attributetarget text, initdate timestamp without time zone, enddate timestamp without time zone) OWNER TO aurea;

--
-- Name: getmaxandminvalueclassificationbyintervaldates(text[], text, integer, timestamp without time zone, timestamp without time zone); Type: FUNCTION; Schema: public; Owner: aurea
--

CREATE FUNCTION getmaxandminvalueclassificationbyintervaldates(saopaulopoliceattributes text[], attributetarget text, area integer, initdate timestamp without time zone, enddate timestamp without time zone) RETURNS TABLE(maxvalue numeric, minvalue numeric)
    LANGUAGE plpgsql
    AS $$
DECLARE 
query1 text;
attr integer;
numAttr integer;
BEGIN
numAttr:= array_length(saopaulopoliceattributes,1);	
query1 := 'select MIN(-1 *instance.'||attributeTarget||')*-1 as maxvalue,  MIN(instance.'||attributeTarget||') as minvalue ';

query1 := query1 ||'FROM instance
where ';

query1 := query1 ||' area_id = '||area||' and date_trunc(''day'',  instance_time ) >=  date_trunc(''day'',  TIMESTAMP '''||initDate ||''') and  
date_trunc(''day'',  instance_time ) <= date_trunc(''day'',  TIMESTAMP '''||endDate||''') ';



    RETURN QUERY EXECUTE query1;  
  RETURN;
END;
$$;


ALTER FUNCTION public.getmaxandminvalueclassificationbyintervaldates(saopaulopoliceattributes text[], attributetarget text, area integer, initdate timestamp without time zone, enddate timestamp without time zone) OWNER TO aurea;

--
-- Name: getmaxandminvalueclassificationbyintervaldatesforallsource1(text[], text, timestamp without time zone, timestamp without time zone); Type: FUNCTION; Schema: public; Owner: aurea
--

CREATE FUNCTION getmaxandminvalueclassificationbyintervaldatesforallsource1(saopaulopoliceattributes text[], attributetarget text, initdate timestamp without time zone, enddate timestamp without time zone) RETURNS TABLE(maxvalue numeric, minvalue numeric)
    LANGUAGE plpgsql
    AS $$
DECLARE 
query1 text;
attr integer;
numAttr integer;
BEGIN
numAttr:= array_length(saopaulopoliceattributes,1);	
query1 := 'select MIN(-1 *instance.'||attributeTarget||')*-1 as maxvalue,  MIN(instance.'||attributeTarget||') as minvalue ';

query1 := query1 ||'FROM instance
where ';

query1 := query1 ||' date_trunc(''day'',  instance_time ) >=  date_trunc(''day'',  TIMESTAMP '''||initDate ||''') and  
date_trunc(''day'',  instance_time ) <= date_trunc(''day'',  TIMESTAMP '''||endDate||''') ';


    RETURN QUERY EXECUTE query1;  
  RETURN;
END;
$$;


ALTER FUNCTION public.getmaxandminvalueclassificationbyintervaldatesforallsource1(saopaulopoliceattributes text[], attributetarget text, initdate timestamp without time zone, enddate timestamp without time zone) OWNER TO aurea;

--
-- Name: getmaxbytimeinterval(text[], integer, timestamp without time zone, timestamp without time zone, numeric); Type: FUNCTION; Schema: public; Owner: aurea
--

CREATE FUNCTION getmaxbytimeinterval(saopaulopoliceattributes text[], area integer, initdate timestamp without time zone, enddate timestamp without time zone, valuetimeinterval numeric) RETURNS TABLE(round numeric[], instance_time timestamp without time zone)
    LANGUAGE plpgsql
    AS $$
DECLARE 
query1 text;
attr integer;
numAttr integer;
BEGIN
numAttr:= array_length(saopaulopoliceattributes,1);	
query1 := 'select array(select round(unnest(array[';
 FOR attr IN SELECT generate_subscripts( saopaulopoliceattributes, 1 ) LOOP
          query1 := query1 ||'MIN(-1 *instance.'||saopaulopoliceattributes[attr]||')*-1';
	IF attr< numAttr THEN
    query1 := query1 ||',';
  END IF;
    END loop;

query1 := query1 ||']),4)) as rounds, 
 to_timestamp(floor((extract(''epoch'' from instance_time) /'|| valuetimeinterval||' )) * '|| valuetimeinterval||') 
    AT TIME ZONE ''UTC'' as interval_alias
FROM instance
where ';

query1 := query1 ||' area_id = '||area||' and date_trunc(''day'',  instance_time ) >=  date_trunc(''day'',  TIMESTAMP '''||initDate ||''') and  
date_trunc(''day'',  instance_time ) <= date_trunc(''day'',  TIMESTAMP '''||endDate||''') GROUP BY interval_alias
ORDER BY interval_alias';
    RETURN QUERY EXECUTE query1;  
  RETURN;
END;
$$;


ALTER FUNCTION public.getmaxbytimeinterval(saopaulopoliceattributes text[], area integer, initdate timestamp without time zone, enddate timestamp without time zone, valuetimeinterval numeric) OWNER TO aurea;

--
-- Name: getmaxbytimeintervalforallareas(text[], timestamp without time zone, timestamp without time zone, numeric); Type: FUNCTION; Schema: public; Owner: aurea
--

CREATE FUNCTION getmaxbytimeintervalforallareas(saopaulopoliceattributes text[], initdate timestamp without time zone, enddate timestamp without time zone, valuetimeinterval numeric) RETURNS TABLE(round numeric[], instance_time timestamp without time zone)
    LANGUAGE plpgsql
    AS $$
DECLARE 
query1 text;
attr integer;
numAttr integer;
BEGIN
numAttr:= array_length(saopaulopoliceattributes,1);	
query1 := 'select array(select round(unnest(array[';
 FOR attr IN SELECT generate_subscripts( saopaulopoliceattributes, 1 ) LOOP
          query1 := query1 ||'MIN(-1 *instance.'||saopaulopoliceattributes[attr]||')*-1';
	IF attr< numAttr THEN
    query1 := query1 ||',';
  END IF;
    END loop;

query1 := query1 ||']),4)) as rounds, 
 to_timestamp(floor((extract(''epoch'' from instance_time) /'|| valuetimeinterval||' )) * '|| valuetimeinterval||') 
    AT TIME ZONE ''UTC'' as interval_alias
FROM instance
where ';


query1 := query1 ||' date_trunc(''day'',  instance_time ) >=  date_trunc(''day'',  TIMESTAMP '''||initDate ||''') and  
date_trunc(''day'',  instance_time ) <= date_trunc(''day'',  TIMESTAMP '''||endDate||''')  GROUP BY interval_alias
ORDER BY interval_alias';
    RETURN QUERY EXECUTE query1;  
  RETURN;
END;
$$;


ALTER FUNCTION public.getmaxbytimeintervalforallareas(saopaulopoliceattributes text[], initdate timestamp without time zone, enddate timestamp without time zone, valuetimeinterval numeric) OWNER TO aurea;

--
-- Name: getmedianbytimeinterval(text[], integer, timestamp without time zone, timestamp without time zone, numeric); Type: FUNCTION; Schema: public; Owner: aurea
--

CREATE FUNCTION getmedianbytimeinterval(saopaulopoliceattributes text[], area integer, initdate timestamp without time zone, enddate timestamp without time zone, valuetimeinterval numeric) RETURNS TABLE(round numeric[], instance_time timestamp without time zone)
    LANGUAGE plpgsql
    AS $$
DECLARE 
query1 text;
attr integer;
numAttr integer;
BEGIN
numAttr:= array_length(saopaulopoliceattributes,1);	
query1 := 'select array(select round(unnest(array[';
 FOR attr IN SELECT generate_subscripts( saopaulopoliceattributes, 1 ) LOOP
          query1 := query1 ||'median(instance.'||saopaulopoliceattributes[attr]||')';
	IF attr< numAttr THEN
    query1 := query1 ||',';
  END IF;
    END loop;

query1 := query1 ||']),6)) as rounds, 
 to_timestamp(floor((extract(''epoch'' from instance_time) /'|| valuetimeinterval||' )) * '|| valuetimeinterval||') 
    AT TIME ZONE ''UTC'' as interval_alias
FROM instance
where ';

query1 := query1 ||' area_id = '||area||' and date_trunc(''day'',  instance_time ) >=  date_trunc(''day'',  TIMESTAMP '''||initDate ||''') and  
date_trunc(''day'',  instance_time ) <= date_trunc(''day'',  TIMESTAMP '''||endDate||''')  GROUP BY interval_alias
ORDER BY interval_alias';
    RETURN QUERY EXECUTE query1;  
  RETURN;
END;
$$;


ALTER FUNCTION public.getmedianbytimeinterval(saopaulopoliceattributes text[], area integer, initdate timestamp without time zone, enddate timestamp without time zone, valuetimeinterval numeric) OWNER TO aurea;

--
-- Name: getmedianbytimeintervalforallareas(text[], timestamp without time zone, timestamp without time zone, numeric); Type: FUNCTION; Schema: public; Owner: aurea
--

CREATE FUNCTION getmedianbytimeintervalforallareas(saopaulopoliceattributes text[], initdate timestamp without time zone, enddate timestamp without time zone, valuetimeinterval numeric) RETURNS TABLE(round numeric[], instance_time timestamp without time zone)
    LANGUAGE plpgsql
    AS $$
DECLARE 
query1 text;
attr integer;
numAttr integer;
BEGIN
numAttr:= array_length(saopaulopoliceattributes,1);	
query1 := 'select array(select round(unnest(array[';
 FOR attr IN SELECT generate_subscripts( saopaulopoliceattributes, 1 ) LOOP
          query1 := query1 ||'median(instance.'||saopaulopoliceattributes[attr]||')';
	IF attr< numAttr THEN
    query1 := query1 ||',';
  END IF;
    END loop;

query1 := query1 ||']),6)) as rounds, 
 to_timestamp(floor((extract(''epoch'' from instance_time) /'|| valuetimeinterval||' )) * '|| valuetimeinterval||') 
    AT TIME ZONE ''UTC'' as interval_alias
FROM observation
where ';

query1 := query1 ||'  date_trunc(''day'',  instance_time ) >=  date_trunc(''day'',  TIMESTAMP '''||initDate ||''') and  
date_trunc(''day'',  instance_time ) <= date_trunc(''day'',  TIMESTAMP '''||endDate||''')  GROUP BY interval_alias
ORDER BY interval_alias';
    RETURN QUERY EXECUTE query1;  
  RETURN;
END;
$$;


ALTER FUNCTION public.getmedianbytimeintervalforallareas(saopaulopoliceattributes text[], initdate timestamp without time zone, enddate timestamp without time zone, valuetimeinterval numeric) OWNER TO aurea;

--
-- Name: getminbytimeinterval(text[], integer, timestamp without time zone, timestamp without time zone, numeric); Type: FUNCTION; Schema: public; Owner: aurea
--

CREATE FUNCTION getminbytimeinterval(saopaulopoliceattributes text[], area integer, initdate timestamp without time zone, enddate timestamp without time zone, valuetimeinterval numeric) RETURNS TABLE(round numeric[], instance_time timestamp without time zone)
    LANGUAGE plpgsql
    AS $$
DECLARE 
query1 text;
attr integer;
numAttr integer;
BEGIN
numAttr:= array_length(saopaulopoliceattributes,1);	
query1 := 'select array(select round(unnest(array[';
 FOR attr IN SELECT generate_subscripts( saopaulopoliceattributes, 1 ) LOOP
          query1 := query1 ||'MIN(instance.'||saopaulopoliceattributes[attr]||')';
	IF attr< numAttr THEN
    query1 := query1 ||',';
  END IF;
    END loop;

query1 := query1 ||']),6)) as rounds, 
 to_timestamp(floor((extract(''epoch'' from instance_time) /'|| valuetimeinterval||' )) * '|| valuetimeinterval||') 
    AT TIME ZONE ''UTC'' as interval_alias
FROM instance
where ';

query1 := query1 ||' area_id = '||area||' and  date_trunc(''day'',  instance_time ) >=  date_trunc(''day'',  TIMESTAMP '''||initDate ||''') and  
date_trunc(''day'',  instance_time ) <= date_trunc(''day'',  TIMESTAMP '''||endDate||''')  GROUP BY interval_alias
ORDER BY interval_alias';
    RETURN QUERY EXECUTE query1;  
  RETURN;
END;
$$;


ALTER FUNCTION public.getminbytimeinterval(saopaulopoliceattributes text[], area integer, initdate timestamp without time zone, enddate timestamp without time zone, valuetimeinterval numeric) OWNER TO aurea;

--
-- Name: getminbytimeintervalforallareas(text[], timestamp without time zone, timestamp without time zone, numeric); Type: FUNCTION; Schema: public; Owner: aurea
--

CREATE FUNCTION getminbytimeintervalforallareas(saopaulopoliceattributes text[], initdate timestamp without time zone, enddate timestamp without time zone, valuetimeinterval numeric) RETURNS TABLE(round numeric[], instance_time timestamp without time zone)
    LANGUAGE plpgsql
    AS $$
DECLARE 
query1 text;
attr integer;
numAttr integer;
BEGIN
numAttr:= array_length(saopaulopoliceattributes,1);	
query1 := 'select array(select round(unnest(array[';
 FOR attr IN SELECT generate_subscripts( saopaulopoliceattributes, 1 ) LOOP
          query1 := query1 ||'MIN(instance.'||saopaulopoliceattributes[attr]||')';
	IF attr< numAttr THEN
    query1 := query1 ||',';
  END IF;
    END loop;

query1 := query1 ||']),6)) as rounds, 
 to_timestamp(floor((extract(''epoch'' from instance_time) /'|| valuetimeinterval||' )) * '|| valuetimeinterval||') 
    AT TIME ZONE ''UTC'' as interval_alias
FROM instance
where ';


query1 := query1 ||' date_trunc(''day'',  instance_time ) >=  date_trunc(''day'',  TIMESTAMP '''||initDate ||''') and  
date_trunc(''day'',  instance_time ) <= date_trunc(''day'',  TIMESTAMP '''||endDate||''') GROUP BY interval_alias
ORDER BY interval_alias';
    RETURN QUERY EXECUTE query1;  
  RETURN;
END;
$$;


ALTER FUNCTION public.getminbytimeintervalforallareas(saopaulopoliceattributes text[], initdate timestamp without time zone, enddate timestamp without time zone, valuetimeinterval numeric) OWNER TO aurea;

--
-- Name: getstdbytimeinterval(text[], integer, timestamp without time zone, timestamp without time zone, numeric); Type: FUNCTION; Schema: public; Owner: aurea
--

CREATE FUNCTION getstdbytimeinterval(saopaulopoliceattributes text[], area integer, initdate timestamp without time zone, enddate timestamp without time zone, valuetimeinterval numeric) RETURNS TABLE(round numeric[], instance_time timestamp without time zone)
    LANGUAGE plpgsql
    AS $$
DECLARE 
query1 text;
attr integer;
numAttr integer;
BEGIN
numAttr:= array_length(saopaulopoliceattributes,1);	
query1 := 'select array(select round(unnest(array[';
 FOR attr IN SELECT generate_subscripts( saopaulopoliceattributes, 1 ) LOOP
          query1 := query1 ||'stddev(instance.'||saopaulopoliceattributes[attr]||')';
	IF attr< numAttr THEN
    query1 := query1 ||',';
  END IF;
    END loop;

query1 := query1 ||']),6)) as rounds, 
 to_timestamp(floor((extract(''epoch'' from instance_time) /'|| valuetimeinterval||' )) * '|| valuetimeinterval||') 
    AT TIME ZONE ''UTC'' as interval_alias
FROM instance
where ';

query1 := query1 ||' area_id = '||area||' and date_trunc(''day'',  instance_time ) >=  date_trunc(''day'',  TIMESTAMP '''||initDate ||''') and  
date_trunc(''day'',  instance_time ) <= date_trunc(''day'',  TIMESTAMP '''||endDate||''')  GROUP BY interval_alias
ORDER BY interval_alias';
    RETURN QUERY EXECUTE query1;  
  RETURN;
END;
$$;


ALTER FUNCTION public.getstdbytimeinterval(saopaulopoliceattributes text[], area integer, initdate timestamp without time zone, enddate timestamp without time zone, valuetimeinterval numeric) OWNER TO aurea;

--
-- Name: getstdbytimeintervalforallareas(text[], timestamp without time zone, timestamp without time zone, numeric); Type: FUNCTION; Schema: public; Owner: aurea
--

CREATE FUNCTION getstdbytimeintervalforallareas(saopaulopoliceattributes text[], initdate timestamp without time zone, enddate timestamp without time zone, valuetimeinterval numeric) RETURNS TABLE(round numeric[], instance_time timestamp without time zone)
    LANGUAGE plpgsql
    AS $$
DECLARE 
query1 text;
attr integer;
numAttr integer;
BEGIN
numAttr:= array_length(saopaulopoliceattributes,1);	
query1 := 'select array(select round(unnest(array[';
 FOR attr IN SELECT generate_subscripts( saopaulopoliceattributes, 1 ) LOOP
          query1 := query1 ||'stddev(instance.'||saopaulopoliceattributes[attr]||')';
	IF attr< numAttr THEN
    query1 := query1 ||',';
  END IF;
    END loop;

query1 := query1 ||']),6)) as rounds, 
 to_timestamp(floor((extract(''epoch'' from instance_time) /'|| valuetimeinterval||' )) * '|| valuetimeinterval||') 
    AT TIME ZONE ''UTC'' as interval_alias
FROM observation
where ';

query1 := query1 ||'  date_trunc(''day'',  instance_time ) >=  date_trunc(''day'',  TIMESTAMP '''||initDate ||''') and  
date_trunc(''day'',  instance_time ) <= date_trunc(''day'',  TIMESTAMP '''||endDate||''')  GROUP BY interval_alias
ORDER BY interval_alias';
    RETURN QUERY EXECUTE query1;  
  RETURN;
END;
$$;


ALTER FUNCTION public.getstdbytimeintervalforallareas(saopaulopoliceattributes text[], initdate timestamp without time zone, enddate timestamp without time zone, valuetimeinterval numeric) OWNER TO aurea;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: area; Type: TABLE; Schema: public; Owner: aurea
--

CREATE TABLE area (
    area_id integer NOT NULL,
    area_name character varying(40) NOT NULL,
    area_description character varying(40),
    area_category character varying(40)
);


ALTER TABLE area OWNER TO aurea;

--
-- Name: instance_id_seq; Type: SEQUENCE; Schema: public; Owner: aurea
--

CREATE SEQUENCE instance_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE instance_id_seq OWNER TO aurea;

--
-- Name: instance; Type: TABLE; Schema: public; Owner: aurea
--

CREATE TABLE instance (
    instance_id bigint DEFAULT nextval('instance_id_seq'::regclass) NOT NULL,
    area_id integer,
    drug_possession numeric NOT NULL,
    drug_traffic numeric NOT NULL,
    drug_seizure numeric NOT NULL,
    illegal_weapon_possession numeric NOT NULL,
    seized_firearms numeric NOT NULL,
    flagrant_issued numeric NOT NULL,
    offenders_detained_in_flagrante numeric NOT NULL,
    offenders_detained_on_warrant numeric NOT NULL,
    people_arrested_in_flagrante numeric NOT NULL,
    people_arrested_on_warrant numeric NOT NULL,
    prisons_issued numeric NOT NULL,
    recovered_vehicles numeric NOT NULL,
    police_inquiries numeric NOT NULL,
    instance_time timestamp without time zone NOT NULL,
    areaid_attr numeric,
    murder numeric DEFAULT 'NaN'::numeric NOT NULL
);


ALTER TABLE instance OWNER TO aurea;

--
-- Name: saopaulopolice_attribute; Type: TABLE; Schema: public; Owner: aurea
--

CREATE TABLE saopaulopolice_attribute (
    saopaulopolice_attribute_id integer NOT NULL,
    saopaulopolice_attribute_name character varying(40) NOT NULL,
    saopaulopolice_attribute_category character varying(40) NOT NULL
);


ALTER TABLE saopaulopolice_attribute OWNER TO aurea;

--
-- Data for Name: area; Type: TABLE DATA; Schema: public; Owner: aurea
--

COPY area (area_id, area_name, area_description, area_category) FROM stdin;
13	Sorocaba	\N	Mesoregion
12	São José dos Campos	\N	Mesoregion
11	São José do Rio Preto	\N	Mesoregion
10	Santos	\N	Mesoregion
9	Ribeirão Preto	\N	Mesoregion
8	Presidente Prudente	\N	Mesoregion
7	Piracicaba	\N	Mesoregion
4	Campinas	\N	Mesoregion
3	Bauru	\N	Mesoregion
2	Araçatuba	\N	Mesoregion
5	Capital 	\N	Capital
6	Grande São Paulo	\N	Capital
1	State	\N	TotalState
\.


--
-- Data for Name: instance; Type: TABLE DATA; Schema: public; Owner: aurea
--

COPY instance (instance_id, area_id, drug_possession, drug_traffic, drug_seizure, illegal_weapon_possession, seized_firearms, flagrant_issued, offenders_detained_in_flagrante, offenders_detained_on_warrant, people_arrested_in_flagrante, people_arrested_on_warrant, prisons_issued, recovered_vehicles, police_inquiries, instance_time, areaid_attr, murder) FROM stdin;
921	6	89	106	33	211	603	867	120	13	1158	388	1379	1844	4653	2002-11-30 00:00:00	6	283
922	6	93	95	26	224	538	879	95	8	1165	316	1318	1851	4908	2002-12-31 00:00:00	6	310
929	6	132	124	47	196	615	1014	177	31	1411	586	1723	1838	5707	2003-07-31 00:00:00	6	270
930	6	100	120	35	234	562	989	199	9	1355	420	1521	1826	5326	2003-08-31 00:00:00	6	234
931	6	92	132	34	221	607	966	216	53	1326	443	1593	1826	5229	2003-09-30 00:00:00	6	244
932	6	110	159	44	217	607	1034	242	31	1403	493	1877	1856	5316	2003-10-31 00:00:00	6	222
933	6	99	118	37	215	632	947	212	15	1298	421	1596	1625	5160	2003-11-30 00:00:00	6	237
934	6	81	110	35	196	547	836	135	12	1124	353	1281	1579	4840	2003-12-31 00:00:00	6	269
941	6	90	108	26	172	463	785	149	24	1099	337	1293	1551	4514	2004-07-31 00:00:00	6	192
942	6	99	143	30	178	583	898	217	30	1301	374	1471	1603	5009	2004-08-31 00:00:00	6	200
943	6	91	155	41	184	536	896	249	21	1276	250	1295	1563	4568	2004-09-30 00:00:00	6	212
944	6	92	134	42	194	525	905	212	5	1328	320	1401	1568	4667	2004-10-31 00:00:00	6	195
945	6	98	140	48	181	518	902	201	5	1293	334	1331	1580	4852	2004-11-30 00:00:00	6	177
946	6	66	145	26	183	513	856	152	29	1144	322	1293	1475	5014	2004-12-31 00:00:00	6	199
952	6	82	162	51	164	499	881	175	28	1271	450	1456	1520	4743	2005-06-30 00:00:00	6	159
953	6	91	143	31	153	465	805	154	19	1148	400	1294	1494	4291	2005-07-31 00:00:00	6	162
954	6	100	178	38	182	527	900	190	19	1259	473	1497	1513	4968	2005-08-31 00:00:00	6	193
955	6	88	198	43	172	494	865	209	37	1221	440	1457	1473	4410	2005-09-30 00:00:00	6	126
956	6	97	201	40	148	545	874	188	19	1243	401	1424	1552	4353	2005-10-31 00:00:00	6	201
957	6	85	180	49	141	466	835	175	17	1204	426	1325	1448	4599	2005-11-30 00:00:00	6	147
958	6	87	210	53	145	450	836	156	9	1162	396	1320	1237	4171	2005-12-31 00:00:00	6	162
964	6	93	227	52	113	329	798	182	16	1129	521	1449	1304	4262	2006-06-30 00:00:00	6	163
965	6	112	222	44	124	338	840	166	13	1175	515	1428	1194	4278	2006-07-31 00:00:00	6	156
966	6	126	236	48	122	424	977	208	19	1407	583	1722	1171	4379	2006-08-31 00:00:00	6	147
968	6	89	222	35	147	404	959	153	24	1321	388	1513	1277	4984	2006-10-31 00:00:00	6	137
969	6	78	227	31	147	372	949	138	8	1274	516	1601	1077	4718	2006-11-30 00:00:00	6	150
970	6	116	201	52	133	349	878	183	17	1149	417	1439	1086	4767	2006-12-31 00:00:00	6	162
5	1	1642	964	181	1625	3417	5824	697	156	7539	3601	8180	8066	27841	2002-05-31 00:00:00	1	1066
6	1	1547	990	204	1346	2896	4964	656	90	6468	3133	7126	7109	24683	2002-06-30 00:00:00	1	972
971	6	109	252	40	111	345	1029	166	18	1392	466	1599	1107	5115	2007-01-31 00:00:00	6	122
7	1	1589	1022	170	1384	3077	5221	600	125	6677	3085	7406	7137	25433	2002-07-31 00:00:00	1	967
8	1	1950	1167	203	1460	3265	5469	631	102	7115	3590	7819	7020	27542	2002-08-31 00:00:00	1	912
973	6	122	283	67	131	437	1105	208	33	1474	706	1958	1533	5287	2007-03-31 00:00:00	6	123
9	1	1749	1080	189	1466	3049	5035	603	108	6404	3498	7389	6804	26286	2002-09-30 00:00:00	1	964
10	1	1736	1152	199	1416	3371	5242	719	139	6790	2774	7209	7117	29296	2002-10-31 00:00:00	1	1032
974	6	107	292	45	113	370	1034	169	26	1479	410	1635	1167	4853	2007-04-30 00:00:00	6	145
975	6	103	278	30	119	370	1039	153	30	1423	459	1648	1157	5484	2007-05-31 00:00:00	6	131
11	1	1757	1118	195	1426	3096	5311	695	111	7080	3171	7457	6894	26118	2002-11-30 00:00:00	1	1037
12	1	1650	885	193	1344	2852	5168	493	87	6706	2852	7031	7150	26534	2002-12-31 00:00:00	1	1111
977	6	127	223	43	81	316	790	113	7	1070	383	1268	1168	4759	2007-07-31 00:00:00	6	127
13	1	1815	1048	220	1379	3224	5456	649	135	7291	3028	7587	7285	26154	2003-01-31 00:00:00	1	995
978	6	84	248	44	102	382	982	152	15	1389	507	1648	1175	5306	2007-08-31 00:00:00	6	138
14	1	1840	1135	150	1357	2963	5392	586	227	7224	3137	7979	6914	27501	2003-02-28 00:00:00	1	1040
979	6	74	261	46	117	360	980	97	30	1310	427	1519	1090	4835	2007-09-30 00:00:00	6	115
980	6	80	329	56	115	350	1039	151	16	1436	569	1709	1110	5578	2007-10-31 00:00:00	6	113
981	6	104	294	53	128	302	984	168	23	1325	795	1950	1057	5122	2007-11-30 00:00:00	6	120
982	6	78	227	33	98	327	860	106	25	1203	379	1353	970	4899	2007-12-31 00:00:00	6	110
983	6	81	352	53	81	317	991	136	22	1353	438	1526	1030	5503	2008-01-31 00:00:00	6	119
15	1	1977	1146	189	1692	3384	6059	699	195	7924	3285	8259	7468	27894	2003-03-31 00:00:00	1	1101
16	1	1815	1212	137	1581	3480	5908	674	189	7902	3425	8370	7151	28797	2003-04-30 00:00:00	1	1063
985	6	79	313	63	96	325	1026	150	24	1447	734	1872	1254	5095	2008-03-31 00:00:00	6	134
17	1	1817	1204	166	1599	3521	5982	747	134	8138	3871	8719	7671	30642	2003-05-31 00:00:00	1	989
986	6	119	303	52	89	351	1027	162	17	1358	686	1767	1326	5526	2008-04-30 00:00:00	6	106
18	1	1701	1076	168	1526	3212	5734	662	114	7758	3773	8468	7005	29592	2003-06-30 00:00:00	1	933
19	1	1804	1188	199	1338	3260	5524	758	197	7360	3881	8084	7152	29775	2003-07-31 00:00:00	1	887
987	6	93	308	47	113	297	932	180	12	1197	488	1551	1176	4978	2008-05-31 00:00:00	6	122
988	6	90	300	59	93	325	966	156	43	1300	655	1765	1225	5804	2008-06-30 00:00:00	6	127
20	1	1822	1249	173	1431	3291	5802	763	136	7884	3576	8171	7516	29514	2003-08-31 00:00:00	1	940
21	1	1802	1219	174	1403	3456	5782	786	189	7689	3643	8275	7426	29986	2003-09-30 00:00:00	1	913
989	6	93	344	60	96	305	1112	147	15	1419	528	1763	1066	5595	2008-07-31 00:00:00	6	121
22	1	1919	1323	214	1448	3590	5872	791	172	7885	3814	8756	7608	30413	2003-10-31 00:00:00	1	861
990	6	77	294	46	100	279	1049	190	28	1366	584	1739	1202	5355	2008-08-31 00:00:00	6	112
23	1	1742	1099	187	1222	3163	5245	710	135	7099	3448	7624	6638	27758	2003-11-30 00:00:00	1	862
24	1	1644	1036	142	1277	3007	5214	601	123	6924	3096	7371	6550	26642	2003-12-31 00:00:00	1	928
25	1	1742	1134	178	1277	3052	5587	672	86	7455	2869	7497	6536	25066	2004-01-31 00:00:00	1	821
27	1	1730	1164	178	1273	3364	5711	836	161	7759	3809	8204	7023	30139	2004-03-31 00:00:00	1	804
28	1	1878	1183	172	1271	3002	5547	895	139	7381	3534	7794	7101	27218	2004-04-30 00:00:00	1	814
29	1	1717	1201	203	1243	2870	5533	954	211	7374	3795	7877	7238	28322	2004-05-31 00:00:00	1	839
30	1	1719	1179	176	1138	2847	5311	940	174	7027	3669	7636	7027	28167	2004-06-30 00:00:00	1	805
31	1	1568	1127	186	1071	2606	5015	691	121	6668	3010	7054	6962	25906	2004-07-31 00:00:00	1	756
32	1	1791	1306	193	1210	2784	5617	878	169	7504	2996	7538	7387	27949	2004-08-31 00:00:00	1	777
33	1	1598	1135	174	1160	2799	5246	918	106	6919	2521	6821	6904	26034	2004-09-30 00:00:00	1	816
34	1	1665	1256	183	1148	2752	5377	816	116	7371	2646	7030	7150	27113	2004-10-31 00:00:00	1	747
35	1	1626	1204	197	1078	2808	5395	809	160	7213	3030	7208	6823	27161	2004-11-30 00:00:00	1	664
36	1	1564	1108	195	1036	3164	5170	769	144	6896	3009	7075	6737	27399	2004-12-31 00:00:00	1	754
37	1	1578	1194	180	1082	2584	5358	804	148	7081	3055	7461	6861	24565	2005-01-31 00:00:00	1	764
39	1	1652	1327	244	1198	2772	5800	962	148	7686	3459	7937	7060	28109	2005-03-31 00:00:00	1	697
40	1	1559	1318	204	1076	2587	5502	880	149	7347	3363	7552	6742	26023	2005-04-30 00:00:00	1	655
41	1	1632	1355	228	1027	2607	5585	980	150	7396	3424	7723	6786	26704	2005-05-31 00:00:00	1	629
42	1	1634	1350	222	966	3055	5283	900	164	7196	3907	7537	7016	27778	2005-06-30 00:00:00	1	598
43	1	1502	1178	193	952	2454	5012	737	181	6585	3563	7110	6782	24654	2005-07-31 00:00:00	1	597
44	1	1893	1464	227	1028	3199	5680	1039	172	7516	4000	7981	6933	28244	2005-08-31 00:00:00	1	639
45	1	1803	1470	306	1002	2416	5327	1168	199	7091	3586	7588	6725	26333	2005-09-30 00:00:00	1	498
46	1	1773	1457	217	1018	2708	5440	1050	155	7270	2997	7389	6778	25337	2005-10-31 00:00:00	1	630
47	1	1721	1361	252	966	2470	5176	1015	120	6881	3394	7232	6419	26014	2005-11-30 00:00:00	1	540
48	1	1688	1383	243	905	2219	5026	842	113	6620	3004	6868	6010	24300	2005-12-31 00:00:00	1	588
991	6	87	283	52	80	279	930	194	20	1211	527	1551	1224	5085	2008-09-30 00:00:00	6	107
992	6	69	256	31	68	277	877	195	29	1143	406	1346	1276	5143	2008-10-31 00:00:00	6	146
49	1	1916	1432	250	887	2206	5022	861	132	6667	3426	7172	5914	24126	2006-01-31 00:00:00	1	521
51	1	1862	1556	273	1034	2421	5716	1044	160	7464	3766	7960	6685	27994	2006-03-31 00:00:00	1	580
52	1	1883	1521	258	938	2189	5372	951	135	7203	3495	7588	6537	24093	2006-04-30 00:00:00	1	526
53	1	1848	1511	216	879	2592	5126	937	105	7024	3667	7357	5904	26380	2006-05-31 00:00:00	1	816
54	1	1499	1443	222	755	2002	4918	894	102	6526	3460	7004	5907	24407	2006-06-30 00:00:00	1	545
55	1	1716	1422	222	827	2040	5103	800	101	7106	3617	7368	5899	23883	2006-07-31 00:00:00	1	533
56	1	1935	1710	252	828	2373	5673	922	123	7647	4569	8557	5751	27808	2006-08-31 00:00:00	1	534
57	1	1703	1596	202	769	1963	5116	898	109	6853	3029	7108	5658	24679	2006-09-30 00:00:00	1	471
58	1	1625	1567	249	818	2203	6031	944	125	7947	3011	7985	6148	30609	2006-10-31 00:00:00	1	485
59	1	1651	1536	235	832	2089	5902	890	123	7395	3648	8187	5528	28089	2006-11-30 00:00:00	1	501
60	1	1868	1372	265	748	1824	5417	735	110	7019	3253	7449	5188	27228	2006-12-31 00:00:00	1	526
61	1	2014	1715	299	760	1765	6056	845	131	7915	3561	8289	5624	27579	2007-01-31 00:00:00	1	439
64	1	2092	1904	268	774	1979	5981	1046	175	7851	3822	8461	5804	28605	2007-04-30 00:00:00	1	467
65	1	1906	2005	277	750	2124	6103	927	157	7994	4237	8991	5853	31671	2007-05-31 00:00:00	1	467
66	1	1835	2064	333	798	2110	5920	951	151	7690	4867	8887	5557	29282	2007-06-30 00:00:00	1	400
67	1	1761	1704	246	635	1838	5264	805	113	6794	3552	7465	5389	27367	2007-07-31 00:00:00	1	381
69	1	2055	1929	306	740	1899	5872	1077	143	7840	3967	8433	5033	28309	2007-09-30 00:00:00	1	408
70	1	1965	2126	303	721	1929	6069	1025	170	8111	4192	8884	5304	30425	2007-10-31 00:00:00	1	426
71	1	2045	2088	296	759	1881	5977	970	185	7861	5343	9551	4824	27988	2007-11-30 00:00:00	1	422
72	1	1800	1795	253	639	1697	5393	856	117	7161	3139	7737	4511	26157	2007-12-31 00:00:00	1	434
73	1	2027	2226	292	639	1731	5805	882	127	7550	3537	8149	4701	28045	2008-01-31 00:00:00	1	384
74	1	2106	2302	290	697	1800	6276	874	186	8258	3828	8841	4880	28018	2008-02-28 00:00:00	1	413
75	1	2029	2232	302	667	1795	6102	890	143	8073	4820	9331	5471	27769	2008-03-31 00:00:00	1	400
76	1	1879	2245	297	629	1773	6062	787	130	8714	4534	9044	5389	28649	2008-04-30 00:00:00	1	334
77	1	1903	2179	291	622	1669	5773	786	123	7755	4087	8646	5486	26104	2008-05-31 00:00:00	1	398
78	1	2032	2255	310	571	1609	5870	796	147	7769	4227	8829	5199	29106	2008-06-30 00:00:00	1	372
79	1	2060	2217	340	560	1636	6312	699	217	8196	4142	9139	4888	29060	2008-07-31 00:00:00	1	377
80	1	1933	2145	335	542	1766	6123	758	162	7970	4193	9020	5108	27873	2008-08-31 00:00:00	1	362
81	1	1467	1937	285	440	1461	5527	753	121	7097	3220	8012	4824	25163	2008-09-30 00:00:00	1	354
82	1	1304	1555	247	447	1589	5183	659	89	6587	2450	7098	5284	22120	2008-10-31 00:00:00	1	435
83	1	1580	1846	346	530	1626	5339	694	135	6878	3399	7889	5456	24012	2008-11-30 00:00:00	1	439
84	1	1793	1824	288	516	1822	5658	701	162	7127	3656	8337	5402	26110	2008-12-31 00:00:00	1	428
85	1	2022	2166	346	638	1677	6508	737	166	8271	4329	9444	6168	26258	2009-01-31 00:00:00	1	388
87	1	2015	2247	386	679	2140	7010	923	238	8875	4321	10125	6791	31417	2009-03-31 00:00:00	1	422
88	1	1993	2201	324	624	1914	6721	814	176	8718	4068	9791	6526	29712	2009-04-30 00:00:00	1	433
89	1	2004	2162	250	677	1925	6720	825	214	8612	4140	9837	6829	31396	2009-05-31 00:00:00	1	447
90	1	1849	2295	218	569	1895	6473	905	210	8324	4457	9664	6461	29321	2009-06-30 00:00:00	1	342
91	1	1819	2288	229	574	1807	6360	825	181	8374	4145	9347	6568	29104	2009-07-31 00:00:00	1	367
92	1	1833	2455	271	605	1802	6674	889	207	8740	4829	10076	6451	30943	2009-08-31 00:00:00	1	370
93	1	1889	2481	237	551	1707	6545	1040	175	8308	4267	9659	5871	30481	2009-09-30 00:00:00	1	390
94	1	2057	2792	251	616	1829	6976	974	195	9031	5646	11125	6257	30366	2009-10-31 00:00:00	1	398
95	1	1827	2353	265	570	1734	6411	964	158	8480	3876	9199	5608	30416	2009-11-30 00:00:00	1	405
96	1	1763	2258	233	570	1699	6320	772	149	8257	3825	9143	5617	29515	2009-12-31 00:00:00	1	421
97	1	1854	2428	208	557	1563	6303	732	166	8332	3751	9079	5628	26965	2010-01-31 00:00:00	1	452
101	1	1633	2481	252	558	1554	6444	963	173	8331	4572	9681	6100	30247	2010-05-31 00:00:00	1	393
102	1	1547	2459	242	581	1553	6178	849	139	7864	3529	8705	5958	28667	2010-06-30 00:00:00	1	311
103	1	1600	2535	193	476	1463	6212	938	162	7951	3573	8934	6236	27538	2010-07-31 00:00:00	1	320
104	1	1979	2809	263	515	1592	6641	1057	154	8581	4234	9713	5988	30783	2010-08-31 00:00:00	1	342
993	6	80	315	36	102	355	905	157	33	1182	512	1494	1223	4936	2008-11-30 00:00:00	6	126
105	1	1994	2699	282	519	1467	6240	943	190	7759	3610	8973	5942	29300	2010-09-30 00:00:00	1	310
106	1	1969	2736	193	498	1527	6374	1033	149	8028	3091	8747	6254	28630	2010-10-31 00:00:00	1	370
107	1	1888	2486	237	514	1542	6205	949	168	7770	3377	8631	6138	28743	2010-11-30 00:00:00	1	395
108	1	2058	2405	247	498	1545	6083	819	168	7678	3557	8675	6026	28745	2010-12-31 00:00:00	1	397
109	1	2171	2726	212	486	1509	6474	921	133	8073	3924	9529	6248	27922	2011-01-31 00:00:00	1	376
994	6	77	265	42	73	304	925	130	18	1173	532	1514	1248	4869	2008-12-31 00:00:00	6	128
111	1	2498	3316	347	557	1566	7434	1009	183	9493	4159	10588	7008	31755	2011-03-31 00:00:00	1	326
112	1	2257	2841	327	599	1587	7035	1039	180	8834	3789	10167	6437	29939	2011-04-30 00:00:00	1	386
113	1	2335	3316	363	616	1873	7396	1206	258	9206	4652	11238	6869	33312	2011-05-31 00:00:00	1	360
114	1	1921	3016	291	553	1737	6802	1030	215	8401	4351	10366	6524	31398	2011-06-30 00:00:00	1	324
115	1	1926	2895	261	527	1592	6448	974	207	8050	4004	9625	6947	29948	2011-07-31 00:00:00	1	394
116	1	2222	3043	289	580	1625	7510	1076	255	9217	4492	11055	7355	34214	2011-08-31 00:00:00	1	371
117	1	2181	2997	352	586	1611	6951	1085	237	8908	4210	10278	7696	32461	2011-09-30 00:00:00	1	336
118	1	2147	2986	285	559	1495	7225	1121	223	8916	3778	10300	7450	30664	2011-10-31 00:00:00	1	385
119	1	2060	2976	316	540	1508	6876	1128	226	8741	3666	10058	7220	30562	2011-11-30 00:00:00	1	370
120	1	2334	2660	313	531	1432	6761	964	147	8393	3269	9415	6962	29741	2011-12-31 00:00:00	1	423
121	1	2483	3429	307	565	1514	7657	1153	159	9186	3387	10189	7348	30537	2012-01-31 00:00:00	1	386
123	1	2420	3458	389	625	1681	8125	1315	221	9962	3933	11469	8211	38672	2012-03-31 00:00:00	1	410
124	1	2385	3315	333	625	1552	8027	1269	241	9970	3903	11406	8075	35933	2012-04-30 00:00:00	1	392
125	1	2425	3632	315	636	1644	8534	1443	302	10144	4442	12009	8243	39428	2012-05-31 00:00:00	1	342
126	1	2287	3352	332	563	1439	7713	1259	227	9322	4035	10971	7339	36411	2012-06-30 00:00:00	1	434
995	6	75	309	48	110	298	1015	143	28	1349	668	1559	1322	5360	2009-01-31 00:00:00	6	111
127	1	2024	3416	334	515	1582	7425	1147	277	9146	3874	10645	7210	35807	2012-07-31 00:00:00	1	380
128	1	2637	3686	371	619	1516	8310	1423	274	10260	4600	11994	7792	39604	2012-08-31 00:00:00	1	419
129	1	2299	3452	369	562	1543	7727	1182	216	9294	3831	10754	7095	35210	2012-09-30 00:00:00	1	429
131	1	2324	3336	349	566	1504	7447	1207	238	9038	3749	10670	7084	34599	2012-11-30 00:00:00	1	535
132	1	2228	3172	333	535	1458	8034	1076	214	9639	3623	10924	7503	33555	2012-12-31 00:00:00	1	565
997	6	92	335	46	138	425	1147	168	36	1479	601	1859	1421	6098	2009-03-31 00:00:00	6	121
133	1	2603	3894	427	588	1489	9399	1373	263	11174	3299	11999	8011	36848	2013-01-31 00:00:00	1	456
135	1	2702	3864	381	602	1549	10140	1582	319	11925	3856	13326	8084	37626	2013-03-31 00:00:00	1	432
136	1	2760	4014	367	639	1696	9741	1581	314	11871	4024	13369	8132	39747	2013-04-30 00:00:00	1	386
137	1	2657	4147	401	617	1594	10115	1568	358	12053	5423	14671	7669	37951	2013-05-31 00:00:00	1	350
138	1	2441	3617	361	510	1474	9425	1471	314	11479	4312	13440	7921	36716	2013-06-30 00:00:00	1	372
139	1	2185	3431	330	491	1517	8748	1366	256	10488	3663	12121	8081	33957	2013-07-31 00:00:00	1	330
140	1	2653	3775	388	575	1790	9324	1561	325	11138	4065	12946	8302	37075	2013-08-31 00:00:00	1	399
141	1	2598	3318	354	599	1650	8644	1364	270	10511	3864	12399	7752	33972	2013-09-30 00:00:00	1	408
142	1	2503	3279	305	530	1551	9037	1528	278	11025	4016	12765	8237	35207	2013-10-31 00:00:00	1	413
143	1	2466	3338	319	519	1614	9030	1471	327	10863	4369	13132	7963	34348	2013-11-30 00:00:00	1	377
144	1	2077	2864	271	607	1481	8845	1396	195	10485	3250	11727	8345	30588	2013-12-31 00:00:00	1	425
145	1	2298	3178	277	557	1595	9135	1543	201	11059	3398	12156	9135	35674	2014-01-31 00:00:00	1	447
147	1	2227	3431	251	609	1569	9403	1703	282	11245	3540	12563	8564	34446	2014-03-31 00:00:00	1	416
148	1	1986	3155	298	589	1518	8802	1584	313	10631	3872	12247	8635	35190	2014-04-30 00:00:00	1	387
149	1	2159	3461	322	502	1517	8833	1682	415	10683	4274	12804	8703	34119	2014-05-31 00:00:00	1	366
150	1	2051	3486	345	604	1476	9209	1615	436	11218	3908	12775	8087	34671	2014-06-30 00:00:00	1	332
151	1	2281	3809	338	541	1531	8928	1831	462	10888	4608	13120	7774	35150	2014-07-31 00:00:00	1	363
152	1	2496	3842	368	518	1389	8923	1780	455	10798	4765	13257	7968	34987	2014-08-31 00:00:00	1	340
153	1	2421	3831	408	541	1465	8819	1759	415	10744	4742	13144	7904	34672	2014-09-30 00:00:00	1	351
154	1	2340	3836	406	502	1395	8952	1794	358	10905	3838	12483	8120	36341	2014-10-31 00:00:00	1	395
155	1	2152	3323	364	496	1551	8531	1606	395	10327	4649	12857	7858	32654	2014-11-30 00:00:00	1	378
156	1	1935	3004	285	491	1577	8250	1360	319	9871	3673	11594	7947	31289	2014-12-31 00:00:00	1	395
159	1	2325	3880	399	613	1639	9433	1743	497	11382	5024	14077	7902	35467	2015-03-31 00:00:00	1	365
160	1	2269	3792	388	551	1560	8964	1760	440	10688	4920	13302	7194	33098	2015-04-30 00:00:00	1	360
161	1	2344	3998	356	579	1456	9387	1837	477	11354	4958	14010	7681	34178	2015-05-31 00:00:00	1	304
162	1	2600	4002	378	558	1354	9470	1727	530	11383	5095	14267	6806	35005	2015-06-30 00:00:00	1	276
163	1	2546	3993	385	520	1411	9493	1649	462	11390	5608	14247	7112	33663	2015-07-31 00:00:00	1	291
164	1	3052	3935	384	532	1549	9755	1819	461	11665	5490	14759	6769	35227	2015-08-31 00:00:00	1	345
165	1	2975	3596	332	582	1649	9411	1681	425	11333	5110	14062	6786	33710	2015-09-30 00:00:00	1	295
166	1	3263	3522	296	558	1479	9281	1701	447	11220	5344	14153	7336	33090	2015-10-31 00:00:00	1	322
167	1	3462	3467	337	502	1325	8969	1721	475	10828	4777	13287	7544	32343	2015-11-30 00:00:00	1	316
168	1	3269	3178	338	532	1379	9002	1737	344	10691	4227	12723	7630	32219	2015-12-31 00:00:00	1	358
169	1	3201	3682	340	571	1367	9154	1749	349	11087	4304	13006	7327	29676	2016-01-31 00:00:00	1	307
171	1	3270	3989	412	559	1528	10552	1923	571	12689	5739	15707	7288	37008	2016-03-31 00:00:00	1	318
172	1	2932	3926	422	552	1432	10248	1826	457	12297	5135	14767	6775	34521	2016-04-30 00:00:00	1	348
1275	8	36	10	6	49	63	73	4	0	91	57	85	17	585	2002-01-31 00:00:00	8	4
173	1	2780	4066	362	583	1416	9963	1902	443	12049	5889	15262	6965	34031	2016-05-31 00:00:00	1	278
174	1	3063	4257	342	568	1401	9801	1852	551	11734	6117	14960	6917	36168	2016-06-30 00:00:00	1	241
175	1	2435	3689	300	571	1416	9468	1638	518	11432	5704	14412	6806	32587	2016-07-31 00:00:00	1	301
1277	8	53	18	10	70	90	75	4	1	118	95	96	9	680	2002-03-31 00:00:00	8	3
1278	8	54	13	6	63	69	89	5	5	118	139	133	19	865	2002-04-30 00:00:00	8	11
1279	8	33	20	4	58	73	80	2	6	98	130	115	17	740	2002-05-31 00:00:00	8	4
1280	8	49	21	4	46	55	68	0	4	96	94	93	12	691	2002-06-30 00:00:00	8	2
176	1	2546	3743	339	468	1448	9534	1725	556	11459	6212	14895	7024	36294	2016-08-31 00:00:00	1	295
1281	8	40	16	4	38	71	73	4	0	93	116	106	26	640	2002-07-31 00:00:00	8	7
1282	8	47	25	9	45	58	90	4	4	107	153	141	10	765	2002-08-31 00:00:00	8	2
1283	8	63	24	6	47	60	75	8	4	98	126	134	8	651	2002-09-30 00:00:00	8	7
1284	8	50	23	2	54	89	85	6	4	112	114	145	5	713	2002-10-31 00:00:00	8	7
177	1	2513	3536	317	526	1279	9299	1753	578	11222	5565	14086	6744	34543	2016-09-30 00:00:00	1	293
1285	8	66	19	2	36	51	94	10	11	110	120	151	24	614	2002-11-30 00:00:00	8	8
1286	8	61	18	8	35	63	97	6	8	118	104	123	18	680	2002-12-31 00:00:00	8	6
1287	8	64	13	8	44	55	82	1	1	95	116	155	11	580	2003-01-31 00:00:00	8	9
1289	8	69	26	6	63	72	107	9	4	135	108	162	20	721	2003-03-31 00:00:00	8	8
178	1	2449	3609	318	540	1461	9737	1644	456	11601	6014	14899	7221	33336	2016-10-31 00:00:00	1	355
1290	8	58	32	7	71	86	110	4	5	152	116	159	23	633	2003-04-30 00:00:00	8	6
1291	8	58	18	5	71	79	83	7	5	123	145	137	11	657	2003-05-31 00:00:00	8	7
1292	8	63	24	5	56	68	98	8	8	139	126	163	8	653	2003-06-30 00:00:00	8	5
1293	8	48	30	3	53	51	89	9	5	118	126	143	20	635	2003-07-31 00:00:00	8	8
179	1	2269	3739	330	453	1320	9229	1621	472	11040	5637	14052	6921	33205	2016-11-30 00:00:00	1	284
1294	8	52	28	7	56	66	96	11	6	123	144	168	11	682	2003-08-31 00:00:00	8	7
1295	8	74	22	7	48	69	93	10	1	120	113	154	15	678	2003-09-30 00:00:00	8	8
1296	8	86	20	5	54	89	76	7	5	101	145	158	11	625	2003-10-31 00:00:00	8	5
1297	8	56	16	5	48	64	56	2	2	74	123	114	5	585	2003-11-30 00:00:00	8	5
998	6	76	300	42	108	332	1068	142	15	1438	574	1764	1394	5407	2009-04-30 00:00:00	6	110
999	6	95	267	26	108	381	1000	152	46	1288	647	1730	1430	5565	2009-05-31 00:00:00	6	125
1298	8	61	17	6	47	66	77	5	2	97	99	136	12	565	2003-12-31 00:00:00	8	8
1299	8	57	19	6	33	81	117	5	2	156	66	160	9	510	2004-01-31 00:00:00	8	5
1301	8	51	22	2	26	66	92	4	7	113	135	152	17	685	2004-03-31 00:00:00	8	7
1302	8	54	20	5	42	60	92	8	5	128	124	146	14	617	2004-04-30 00:00:00	8	6
1000	6	85	320	40	97	332	982	153	42	1375	725	1784	1326	5588	2009-06-30 00:00:00	6	84
1001	6	99	294	28	93	331	973	129	40	1391	592	1732	1403	6246	2009-07-31 00:00:00	6	93
1303	8	67	23	5	35	61	87	2	4	109	120	153	16	613	2004-05-31 00:00:00	8	6
1304	8	53	21	3	32	53	94	6	4	117	127	135	15	669	2004-06-30 00:00:00	8	6
1305	8	66	15	5	21	53	84	5	4	111	81	123	15	539	2004-07-31 00:00:00	8	5
1306	8	71	16	9	30	42	76	2	7	96	72	123	21	572	2004-08-31 00:00:00	8	6
1002	6	76	335	20	117	335	1030	179	12	1369	805	1944	1378	5755	2009-08-31 00:00:00	6	98
1003	6	86	364	34	94	345	942	189	25	1301	595	1620	1164	5775	2009-09-30 00:00:00	6	118
1307	8	49	21	9	28	48	83	5	4	102	61	121	18	517	2004-09-30 00:00:00	8	6
1308	8	39	17	3	37	55	98	1	7	117	72	142	20	700	2004-10-31 00:00:00	8	10
1309	8	53	22	12	27	47	83	7	9	98	99	136	14	628	2004-11-30 00:00:00	8	10
1004	6	99	388	35	107	383	1045	147	32	1461	914	2065	1292	5754	2009-10-31 00:00:00	6	95
1005	6	70	340	18	97	299	951	169	10	1272	560	1603	1150	5909	2009-11-30 00:00:00	6	104
1310	8	53	24	7	28	213	99	6	8	133	123	154	17	608	2004-12-31 00:00:00	8	4
1311	8	50	10	12	41	64	92	3	9	109	64	131	20	518	2005-01-31 00:00:00	8	9
1313	8	64	35	14	39	79	135	14	7	178	132	210	14	752	2005-03-31 00:00:00	8	10
1314	8	70	35	14	30	57	94	2	7	119	125	167	14	647	2005-04-30 00:00:00	8	13
1006	6	76	287	36	93	297	877	140	13	1214	608	1558	1157	5318	2009-12-31 00:00:00	6	122
1007	6	56	330	30	101	297	961	132	16	1298	562	1581	1036	5287	2010-01-31 00:00:00	6	115
1315	8	80	38	11	30	58	108	8	9	131	125	162	13	664	2005-05-31 00:00:00	8	5
1316	8	56	29	12	25	98	103	7	13	133	124	156	22	631	2005-06-30 00:00:00	8	12
1317	8	63	32	10	23	36	97	5	14	123	114	170	25	585	2005-07-31 00:00:00	8	6
1318	8	62	36	16	29	64	101	18	11	126	157	185	28	733	2005-08-31 00:00:00	8	2
1320	8	81	18	26	55	76	111	10	2	149	113	170	21	605	2005-10-31 00:00:00	8	9
1321	8	77	32	8	40	95	98	8	4	130	107	160	21	552	2005-11-30 00:00:00	8	9
1322	8	88	25	15	33	42	90	3	4	116	103	147	18	536	2005-12-31 00:00:00	8	5
1323	8	66	20	8	34	56	93	3	6	127	122	156	21	604	2006-01-31 00:00:00	8	4
1325	8	59	30	22	24	59	101	7	9	140	152	191	15	691	2006-03-31 00:00:00	8	5
1009	6	76	388	32	95	295	1116	194	26	1476	653	1827	1250	5815	2010-03-31 00:00:00	6	83
180	1	2154	3355	343	469	1339	8690	1575	293	10507	5038	12926	7227	32071	2016-12-31 00:00:00	1	362
1326	8	81	20	22	26	56	91	21	12	121	125	167	17	532	2006-04-30 00:00:00	8	4
1327	8	79	33	6	18	45	86	8	13	114	171	181	21	675	2006-05-31 00:00:00	8	4
1328	8	59	26	5	18	19	70	12	1	88	128	142	15	521	2006-06-30 00:00:00	8	3
1329	8	57	28	13	25	49	81	8	13	109	115	143	6	543	2006-07-31 00:00:00	8	3
1330	8	87	30	22	34	47	83	6	3	114	169	169	12	653	2006-08-31 00:00:00	8	6
1331	8	65	31	12	22	34	84	8	6	111	112	152	16	495	2006-09-30 00:00:00	8	6
1332	8	71	31	32	28	40	98	7	2	129	110	148	20	819	2006-10-31 00:00:00	8	5
1333	8	87	31	17	27	41	118	3	6	151	137	195	15	712	2006-11-30 00:00:00	8	2
1334	8	76	41	24	27	27	107	6	2	119	126	152	24	694	2006-12-31 00:00:00	8	9
1335	8	101	31	27	30	45	113	5	7	155	146	200	23	673	2007-01-31 00:00:00	8	5
1337	8	81	54	28	20	39	111	7	13	144	195	220	12	850	2007-03-31 00:00:00	8	5
1338	8	78	33	18	24	39	105	4	12	133	153	166	13	662	2007-04-30 00:00:00	8	2
1339	8	81	51	17	31	40	96	5	13	114	185	213	17	687	2007-05-31 00:00:00	8	8
1340	8	100	55	27	28	40	120	7	7	156	162	212	15	788	2007-06-30 00:00:00	8	3
1341	8	91	35	7	21	26	81	5	4	109	140	160	17	678	2007-07-31 00:00:00	8	5
1342	8	85	70	27	25	41	133	12	8	170	152	230	16	877	2007-08-31 00:00:00	8	3
1343	8	94	56	38	26	29	116	6	7	141	133	190	14	761	2007-09-30 00:00:00	8	4
1344	8	73	46	30	34	50	128	4	10	159	115	193	13	884	2007-10-31 00:00:00	8	2
1345	8	101	47	21	19	39	114	15	12	144	174	216	13	839	2007-11-30 00:00:00	8	4
1346	8	61	39	15	27	43	107	7	6	138	140	171	19	728	2007-12-31 00:00:00	8	9
1347	8	78	47	25	28	66	114	9	3	144	114	183	12	764	2008-01-31 00:00:00	8	4
1349	8	84	43	21	26	33	124	3	6	156	172	231	16	790	2008-03-31 00:00:00	8	6
1350	8	80	55	21	12	24	119	10	9	171	123	186	27	723	2008-04-30 00:00:00	8	7
1351	8	69	50	22	17	30	111	7	8	149	148	193	36	715	2008-05-31 00:00:00	8	4
1352	8	91	59	19	20	33	124	10	5	159	145	193	30	839	2008-06-30 00:00:00	8	2
1353	8	121	66	18	20	39	156	8	10	195	152	226	13	809	2008-07-31 00:00:00	8	2
1354	8	113	67	27	16	39	167	9	5	215	190	267	18	865	2008-08-31 00:00:00	8	4
1355	8	93	37	23	13	29	100	6	12	125	125	183	17	670	2008-09-30 00:00:00	8	7
1356	8	95	51	22	12	33	118	9	4	150	93	170	20	673	2008-10-31 00:00:00	8	2
1357	8	93	49	26	14	34	117	17	6	152	140	181	30	707	2008-11-30 00:00:00	8	4
1358	8	80	48	30	17	36	124	8	8	151	117	169	18	781	2008-12-31 00:00:00	8	4
1359	8	105	69	35	17	33	157	10	0	194	165	251	24	688	2009-01-31 00:00:00	8	6
1361	8	74	44	18	15	34	141	9	9	171	143	199	27	878	2009-03-31 00:00:00	8	4
1362	8	75	47	26	23	30	146	13	6	175	143	230	36	885	2009-04-30 00:00:00	8	6
1363	8	91	42	21	24	33	124	6	9	159	195	238	27	884	2009-05-31 00:00:00	8	5
1364	8	104	53	11	16	41	123	9	12	149	152	209	28	794	2009-06-30 00:00:00	8	1
1365	8	124	35	17	14	25	118	13	6	145	161	201	16	846	2009-07-31 00:00:00	8	1
1366	8	102	52	26	14	40	124	12	10	165	197	230	23	885	2009-08-31 00:00:00	8	6
1367	8	101	65	13	16	31	151	4	10	184	181	247	30	852	2009-09-30 00:00:00	8	3
1368	8	119	56	17	17	41	144	4	4	187	199	274	24	804	2009-10-31 00:00:00	8	3
1369	8	89	48	13	25	31	137	10	7	194	130	213	25	788	2009-11-30 00:00:00	8	2
1370	8	107	69	8	19	33	145	5	18	179	124	199	22	858	2009-12-31 00:00:00	8	4
1371	8	86	41	9	13	20	112	3	13	132	116	189	20	722	2010-01-31 00:00:00	8	13
1373	8	73	54	13	14	34	150	9	10	189	143	205	34	847	2010-03-31 00:00:00	8	5
1374	8	89	43	14	14	38	136	13	8	166	138	220	28	807	2010-04-30 00:00:00	8	5
1375	8	79	50	15	25	45	130	26	8	162	183	229	43	858	2010-05-31 00:00:00	8	8
1376	8	75	49	11	20	28	125	16	2	159	120	196	38	754	2010-06-30 00:00:00	8	5
1377	8	84	54	10	18	37	144	19	6	180	125	208	28	730	2010-07-31 00:00:00	8	4
1378	8	105	67	6	17	24	121	17	7	158	146	201	26	821	2010-08-31 00:00:00	8	5
1379	8	87	59	9	11	21	145	9	8	172	126	202	23	788	2010-09-30 00:00:00	8	3
1380	8	110	74	9	20	43	159	26	10	193	100	210	21	718	2010-10-31 00:00:00	8	7
1381	8	90	50	12	18	34	113	13	2	149	103	166	31	721	2010-11-30 00:00:00	8	6
1382	8	100	53	11	15	37	141	18	10	176	144	216	39	812	2010-12-31 00:00:00	8	6
1383	8	96	64	11	15	36	156	18	0	201	106	235	19	754	2011-01-31 00:00:00	8	5
1387	8	128	85	18	20	28	179	30	6	233	149	309	37	870	2011-05-31 00:00:00	8	10
1388	8	116	78	9	13	39	164	26	13	200	149	288	38	804	2011-06-30 00:00:00	8	9
1389	8	134	88	7	17	34	157	36	9	207	146	284	18	848	2011-07-31 00:00:00	8	3
1390	8	121	80	13	16	39	189	26	8	229	150	324	24	956	2011-08-31 00:00:00	8	6
1392	8	110	88	12	15	31	184	19	8	219	144	309	31	845	2011-10-31 00:00:00	8	9
1393	8	108	78	11	14	75	163	24	8	206	121	266	16	845	2011-11-30 00:00:00	8	3
1394	8	108	67	21	12	30	155	12	5	200	130	243	31	752	2011-12-31 00:00:00	8	1
1395	8	102	76	18	21	32	146	28	7	176	108	243	46	764	2012-01-31 00:00:00	8	4
1397	8	131	87	24	12	28	196	35	11	248	162	340	35	992	2012-03-31 00:00:00	8	2
1398	8	135	84	16	8	19	191	30	14	249	151	315	25	971	2012-04-30 00:00:00	8	6
1399	8	121	83	18	14	53	199	28	11	236	138	315	33	1120	2012-05-31 00:00:00	8	6
1400	8	125	69	18	22	26	205	20	5	234	175	347	53	1017	2012-06-30 00:00:00	8	8
1401	8	116	92	17	12	45	190	24	17	229	138	299	32	933	2012-07-31 00:00:00	8	8
1402	8	167	81	21	24	39	209	25	13	257	199	385	24	1165	2012-08-31 00:00:00	8	6
1403	8	123	66	15	21	34	209	23	4	238	135	314	24	980	2012-09-30 00:00:00	8	3
1404	8	128	78	15	23	60	188	31	5	231	154	323	30	1157	2012-10-31 00:00:00	8	9
1405	8	125	78	8	17	26	184	16	15	223	144	301	32	1077	2012-11-30 00:00:00	8	5
1406	8	87	63	13	20	35	199	11	12	241	104	287	26	952	2012-12-31 00:00:00	8	10
1407	8	132	80	15	14	35	277	27	16	314	120	382	32	1208	2013-01-31 00:00:00	8	9
1409	8	123	111	11	19	39	307	19	7	349	112	395	24	1140	2013-03-31 00:00:00	8	6
1410	8	116	90	12	14	42	269	28	11	306	154	375	40	1187	2013-04-30 00:00:00	8	5
1010	6	65	359	15	93	317	978	146	9	1360	616	1697	1252	5343	2010-04-30 00:00:00	6	98
1411	8	110	96	10	18	24	295	30	7	344	190	432	50	1129	2013-05-31 00:00:00	8	1
1412	8	114	115	11	19	25	250	41	8	310	181	388	48	1100	2013-06-30 00:00:00	8	2
365	3	155	49	13	66	170	310	6	2	394	163	400	65	1182	2002-01-31 00:00:00	3	9
1413	8	112	96	10	17	29	246	30	6	278	151	368	43	1010	2013-07-31 00:00:00	8	2
1414	8	131	120	21	18	45	282	42	6	314	148	394	38	1134	2013-08-31 00:00:00	8	3
1415	8	148	63	13	22	55	261	35	8	319	127	369	45	958	2013-09-30 00:00:00	8	10
1011	6	78	369	28	97	268	994	204	18	1363	654	1784	1258	5711	2010-05-31 00:00:00	6	106
1416	8	123	98	8	12	30	270	37	11	327	168	393	41	1089	2013-10-31 00:00:00	8	7
366	3	161	53	16	92	155	251	3	8	330	175	357	81	1220	2002-02-28 00:00:00	3	15
1417	8	114	75	9	21	41	229	30	8	271	133	327	45	1056	2013-11-30 00:00:00	8	12
1418	8	80	62	12	22	24	224	23	3	252	136	317	47	875	2013-12-31 00:00:00	8	5
1419	8	95	80	6	16	26	236	24	6	285	155	359	49	949	2014-01-31 00:00:00	8	4
1012	6	62	355	37	103	261	934	183	18	1273	534	1572	1255	5317	2010-06-30 00:00:00	6	83
1421	8	101	86	15	21	41	226	49	13	292	168	335	42	955	2014-03-31 00:00:00	8	5
367	3	170	65	20	86	159	310	11	13	383	240	451	96	1233	2002-03-31 00:00:00	3	19
1422	8	93	112	17	14	23	243	57	12	286	154	354	43	996	2014-04-30 00:00:00	8	2
1423	8	134	127	18	14	27	247	31	25	297	162	367	39	1001	2014-05-31 00:00:00	8	7
1424	8	89	104	27	15	18	230	45	26	281	146	342	34	1035	2014-06-30 00:00:00	8	4
1013	6	78	383	31	73	257	971	195	10	1320	531	1588	1148	5197	2010-07-31 00:00:00	6	72
1425	8	84	112	26	17	26	203	38	17	247	160	314	40	1060	2014-07-31 00:00:00	8	1
368	3	153	65	21	74	152	283	18	11	354	236	433	88	1303	2002-04-30 00:00:00	3	18
1426	8	118	129	32	12	28	248	40	13	300	181	373	28	1063	2014-08-31 00:00:00	8	3
1427	8	120	97	28	17	27	186	28	29	209	183	318	27	989	2014-09-30 00:00:00	8	3
1428	8	125	115	21	14	30	227	42	21	275	188	347	34	1249	2014-10-31 00:00:00	8	6
1014	6	94	435	51	72	247	1060	249	20	1365	665	1767	1322	5704	2010-08-31 00:00:00	6	76
1015	6	80	359	34	111	257	945	166	18	1252	567	1588	1292	5320	2010-09-30 00:00:00	6	58
369	3	148	52	20	83	162	260	12	18	343	248	405	98	1416	2002-05-31 00:00:00	3	14
1429	8	112	93	14	22	34	228	34	28	266	171	358	51	1073	2014-11-30 00:00:00	8	8
1430	8	82	94	11	15	24	226	23	18	261	151	343	45	1035	2014-12-31 00:00:00	8	4
1442	8	136	100	4	16	30	225	34	24	269	181	378	32	948	2015-12-31 00:00:00	8	6
1016	6	76	400	35	75	288	1006	238	15	1329	389	1463	1362	5415	2010-10-31 00:00:00	6	94
1443	8	137	93	13	17	35	208	39	27	239	142	326	43	776	2016-01-31 00:00:00	8	5
1445	8	137	112	11	11	26	232	34	44	258	240	436	50	1139	2016-03-31 00:00:00	8	5
1446	8	122	105	16	22	38	236	29	15	277	228	436	49	1084	2016-04-30 00:00:00	8	5
1447	8	123	136	12	10	29	251	31	34	299	324	544	46	1015	2016-05-31 00:00:00	8	4
1448	8	140	128	20	14	26	247	44	27	288	340	553	45	1014	2016-06-30 00:00:00	8	3
1449	8	118	104	11	14	36	219	28	36	264	307	493	39	954	2016-07-31 00:00:00	8	6
1450	8	139	119	20	17	40	220	26	28	267	294	473	54	1075	2016-08-31 00:00:00	8	3
370	3	139	62	13	62	98	253	15	8	322	217	394	78	1239	2002-06-30 00:00:00	3	11
1451	8	106	110	20	16	32	229	28	27	269	221	423	45	1147	2016-09-30 00:00:00	8	1
1452	8	124	114	17	14	36	228	39	27	270	293	472	62	1087	2016-10-31 00:00:00	8	8
1453	8	103	119	15	17	22	205	31	35	245	244	422	41	966	2016-11-30 00:00:00	8	2
1017	6	87	324	42	86	296	922	169	14	1205	435	1414	1288	5400	2010-11-30 00:00:00	6	95
1454	8	113	99	20	12	48	204	24	22	240	221	405	60	1022	2016-12-31 00:00:00	8	9
1455	8	114	102	9	20	38	191	31	19	246	209	369	44	906	2017-01-31 00:00:00	8	7
181	1	2428	3997	308	470	1356	9241	1631	295	11129	5388	13659	7020	31850	2017-01-31 00:00:00	1	310
182	1	2374	3732	321	472	1301	9027	1584	405	10815	5653	13803	6194	31156	2017-02-28 00:00:00	1	312
1018	6	71	301	53	89	253	954	138	7	1265	477	1475	1177	5206	2010-12-31 00:00:00	6	103
1019	6	68	358	36	62	262	967	158	13	1242	574	1605	1321	5525	2011-01-31 00:00:00	6	88
1021	6	132	483	92	90	364	1193	182	19	1576	670	1927	1558	5927	2011-03-31 00:00:00	6	88
1022	6	103	390	69	101	273	1120	192	13	1497	550	1785	1468	5625	2011-04-30 00:00:00	6	98
1023	6	86	485	103	88	259	1145	232	22	1448	749	1953	1479	5899	2011-05-31 00:00:00	6	94
1024	6	71	420	89	84	263	1082	178	16	1337	798	1936	1429	5504	2011-06-30 00:00:00	6	76
371	3	152	45	11	71	125	227	7	15	274	234	375	112	1072	2002-07-31 00:00:00	3	15
372	3	178	48	16	95	168	271	5	11	332	247	405	107	1326	2002-08-31 00:00:00	3	10
373	3	149	47	15	102	175	247	14	9	290	244	401	80	1295	2002-09-30 00:00:00	3	20
374	3	176	69	30	81	143	252	13	14	305	213	373	93	1539	2002-10-31 00:00:00	3	16
375	3	148	60	24	78	152	271	8	7	357	240	414	101	1194	2002-11-30 00:00:00	3	13
376	3	164	46	27	78	151	249	8	7	328	219	371	94	1195	2002-12-31 00:00:00	3	13
377	3	168	43	13	98	179	260	14	5	358	227	386	102	1185	2003-01-31 00:00:00	3	10
378	3	164	59	20	55	123	267	10	15	336	177	358	83	1252	2003-02-28 00:00:00	3	14
379	3	181	55	11	103	182	312	20	6	399	247	447	90	1348	2003-03-31 00:00:00	3	21
380	3	158	62	10	85	144	304	20	20	415	241	442	83	1438	2003-04-30 00:00:00	3	14
381	3	177	60	18	77	173	307	17	9	402	251	446	106	1402	2003-05-31 00:00:00	3	13
382	3	158	58	17	75	164	266	15	11	323	284	437	76	1482	2003-06-30 00:00:00	3	17
383	3	139	60	30	82	173	267	11	13	333	261	390	88	1311	2003-07-31 00:00:00	3	11
384	3	169	73	29	78	201	315	22	16	418	265	452	86	1480	2003-08-31 00:00:00	3	17
385	3	156	62	27	60	184	304	13	6	413	221	419	77	1449	2003-09-30 00:00:00	3	11
386	3	179	62	52	93	183	282	14	15	364	275	402	84	1480	2003-10-31 00:00:00	3	21
387	3	145	65	31	49	124	258	23	15	347	235	379	88	1331	2003-11-30 00:00:00	3	13
388	3	153	59	18	58	159	275	16	6	357	251	409	97	1172	2003-12-31 00:00:00	3	18
389	3	166	65	35	62	161	304	33	4	400	177	424	81	1058	2004-01-31 00:00:00	3	8
391	3	184	73	19	78	187	285	14	16	403	268	422	109	1415	2004-03-31 00:00:00	3	12
392	3	164	86	23	64	154	268	17	14	358	224	390	87	1267	2004-04-30 00:00:00	3	16
393	3	157	50	32	61	135	254	13	22	351	271	404	101	1295	2004-05-31 00:00:00	3	20
394	3	116	54	18	37	200	245	28	6	329	288	408	92	1260	2004-06-30 00:00:00	3	13
395	3	141	79	25	64	142	253	26	10	331	204	369	95	1093	2004-07-31 00:00:00	3	16
396	3	138	73	24	51	110	259	31	11	319	165	328	113	1293	2004-08-31 00:00:00	3	14
397	3	135	59	21	41	97	211	13	3	263	162	284	104	1059	2004-09-30 00:00:00	3	17
398	3	136	72	21	46	96	270	26	5	368	190	388	108	1186	2004-10-31 00:00:00	3	21
399	3	124	57	23	51	122	244	21	11	318	213	376	103	1208	2004-11-30 00:00:00	3	12
400	3	136	68	27	46	252	258	14	11	345	225	393	123	1215	2004-12-31 00:00:00	3	14
401	3	141	56	20	46	143	251	20	17	326	202	384	94	987	2005-01-31 00:00:00	3	20
402	3	115	66	23	54	145	219	28	10	295	208	345	74	1105	2005-02-28 00:00:00	3	18
403	3	147	84	33	68	146	322	28	24	428	275	481	99	1332	2005-03-31 00:00:00	3	19
404	3	139	80	24	55	102	265	19	19	335	298	443	82	1238	2005-04-30 00:00:00	3	14
405	3	162	91	46	64	137	274	21	18	358	254	410	110	1166	2005-05-31 00:00:00	3	20
406	3	128	86	24	60	179	285	28	11	358	294	463	90	1204	2005-06-30 00:00:00	3	10
407	3	121	61	30	42	101	240	8	13	291	241	405	70	1040	2005-07-31 00:00:00	3	21
408	3	195	96	31	38	89	264	20	12	346	283	427	90	1293	2005-08-31 00:00:00	3	13
410	3	188	69	11	51	111	267	17	15	353	191	405	109	1129	2005-10-31 00:00:00	3	23
411	3	163	73	23	44	105	211	23	13	272	243	365	117	1131	2005-11-30 00:00:00	3	4
412	3	160	68	30	41	93	257	20	7	334	190	393	109	1507	2005-12-31 00:00:00	3	19
413	3	177	97	14	43	114	257	20	6	339	217	385	128	1286	2006-01-31 00:00:00	3	11
414	3	172	75	35	59	102	249	41	11	315	261	406	117	1199	2006-02-28 00:00:00	3	14
415	3	172	89	30	53	127	279	23	19	345	269	464	123	1401	2006-03-31 00:00:00	3	13
416	3	186	106	36	46	85	285	24	13	375	230	423	89	1176	2006-04-30 00:00:00	3	14
417	3	178	105	20	45	139	273	29	2	362	276	434	102	1299	2006-05-31 00:00:00	3	8
418	3	168	87	30	32	74	246	27	4	329	260	384	109	1280	2006-06-30 00:00:00	3	8
419	3	183	75	26	36	112	240	27	4	318	307	431	82	1157	2006-07-31 00:00:00	3	11
420	3	215	124	32	45	113	319	20	5	408	319	498	66	1332	2006-08-31 00:00:00	3	4
421	3	145	110	37	37	72	286	19	5	362	239	431	78	1285	2006-09-30 00:00:00	3	16
422	3	174	117	46	32	86	357	15	15	469	216	492	68	1623	2006-10-31 00:00:00	3	18
423	3	197	128	17	35	93	329	31	10	426	307	508	65	1484	2006-11-30 00:00:00	3	11
424	3	181	112	41	34	71	322	16	18	424	260	517	72	1465	2006-12-31 00:00:00	3	13
425	3	176	108	39	31	71	310	22	13	385	302	490	85	1271	2007-01-31 00:00:00	3	8
426	3	204	138	38	43	100	340	32	17	439	369	573	64	1391	2007-02-28 00:00:00	3	7
427	3	178	119	38	40	98	304	27	10	397	481	657	78	1585	2007-03-31 00:00:00	3	7
428	3	215	113	29	39	96	318	23	12	414	281	499	71	1512	2007-04-30 00:00:00	3	10
429	3	177	99	50	32	84	282	22	13	361	340	532	108	1491	2007-05-31 00:00:00	3	10
430	3	155	107	36	42	100	297	25	4	381	448	568	80	1310	2007-06-30 00:00:00	3	10
431	3	175	90	21	33	89	248	18	15	297	285	418	96	1366	2007-07-31 00:00:00	3	11
432	3	193	121	43	20	71	294	28	6	388	357	525	84	1628	2007-08-31 00:00:00	3	9
433	3	215	128	35	32	81	266	28	20	341	340	471	84	1438	2007-09-30 00:00:00	3	9
434	3	186	128	26	26	72	275	27	36	357	304	460	86	1388	2007-10-31 00:00:00	3	16
435	3	170	122	26	31	73	300	33	15	415	468	573	73	1358	2007-11-30 00:00:00	3	11
436	3	171	106	36	36	100	268	27	3	328	285	433	78	1318	2007-12-31 00:00:00	3	13
437	3	180	129	34	30	79	270	22	10	361	240	342	76	1292	2008-01-31 00:00:00	3	14
439	3	161	119	46	22	71	262	31	15	329	361	484	93	1534	2008-03-31 00:00:00	3	11
440	3	176	114	39	29	64	280	24	8	381	328	482	93	1554	2008-04-30 00:00:00	3	14
441	3	201	111	29	27	84	251	29	13	325	281	427	81	1349	2008-05-31 00:00:00	3	12
442	3	157	104	37	28	79	276	15	10	338	328	486	79	1408	2008-06-30 00:00:00	3	9
443	3	208	114	44	36	67	292	21	11	365	270	478	80	1355	2008-07-31 00:00:00	3	8
444	3	179	93	53	20	54	271	20	12	355	289	427	76	1260	2008-08-31 00:00:00	3	11
445	3	117	63	34	14	49	232	10	5	286	153	339	61	1080	2008-09-30 00:00:00	3	9
446	3	113	59	37	17	47	210	15	4	260	104	289	63	639	2008-10-31 00:00:00	3	12
447	3	165	80	65	14	76	233	12	10	287	242	393	113	1317	2008-11-30 00:00:00	3	8
448	3	181	75	38	26	102	266	20	14	332	313	485	88	1414	2008-12-31 00:00:00	3	12
449	3	177	108	55	32	81	306	17	15	398	338	525	89	1127	2009-01-31 00:00:00	3	10
450	3	228	132	33	29	80	357	22	8	442	340	600	111	1329	2009-02-28 00:00:00	3	15
451	3	218	122	102	28	80	340	22	19	428	371	574	109	1768	2009-03-31 00:00:00	3	11
452	3	169	122	39	35	112	336	30	17	445	324	543	122	1635	2009-04-30 00:00:00	3	6
453	3	197	145	37	26	74	355	35	27	453	343	583	130	1762	2009-05-31 00:00:00	3	11
454	3	199	135	32	16	75	314	46	21	402	409	615	101	1573	2009-06-30 00:00:00	3	11
455	3	184	141	27	28	87	323	31	14	415	391	593	104	1414	2009-07-31 00:00:00	3	7
456	3	203	154	53	24	69	375	44	24	472	372	614	110	1712	2009-08-31 00:00:00	3	8
457	3	166	167	40	20	69	362	35	17	465	381	640	90	1706	2009-09-30 00:00:00	3	8
458	3	152	135	33	20	93	315	31	16	406	380	565	83	1561	2009-10-31 00:00:00	3	10
459	3	152	114	36	19	79	313	30	11	379	345	562	97	1557	2009-11-30 00:00:00	3	14
460	3	115	113	30	28	107	329	21	16	420	366	605	126	1540	2009-12-31 00:00:00	3	9
461	3	138	133	36	24	85	331	31	20	418	370	592	89	1290	2010-01-31 00:00:00	3	22
462	3	130	159	36	20	62	352	36	15	472	315	575	88	1500	2010-02-28 00:00:00	3	13
463	3	171	143	38	30	82	354	23	27	434	349	559	138	1770	2010-03-31 00:00:00	3	17
464	3	111	117	32	24	65	279	34	19	339	358	514	81	1688	2010-04-30 00:00:00	3	14
465	3	178	169	38	33	79	365	37	9	459	354	597	89	1499	2010-05-31 00:00:00	3	8
466	3	135	155	51	24	69	323	39	8	415	286	513	106	1593	2010-06-30 00:00:00	3	15
467	3	132	122	31	34	85	302	32	14	383	274	519	135	1401	2010-07-31 00:00:00	3	18
468	3	173	165	39	29	72	299	44	11	384	308	509	108	1522	2010-08-31 00:00:00	3	19
469	3	181	149	59	25	82	339	45	17	421	250	528	90	1687	2010-09-30 00:00:00	3	12
470	3	175	169	25	38	97	381	51	10	471	267	570	99	1524	2010-10-31 00:00:00	3	17
471	3	161	135	45	18	65	302	42	11	377	278	488	123	1486	2010-11-30 00:00:00	3	13
472	3	176	110	33	28	68	278	28	17	345	331	499	112	1523	2010-12-31 00:00:00	3	14
473	3	178	132	38	30	97	304	49	12	378	332	530	129	1301	2011-01-31 00:00:00	3	9
474	3	238	147	46	31	89	310	32	17	379	359	598	121	1471	2011-02-28 00:00:00	3	10
477	3	254	172	41	29	81	380	70	26	467	370	671	113	1682	2011-05-31 00:00:00	3	10
478	3	201	159	28	27	97	310	68	11	398	339	602	112	1681	2011-06-30 00:00:00	3	8
479	3	220	170	23	28	79	338	49	12	421	271	605	123	1445	2011-07-31 00:00:00	3	14
480	3	211	164	25	17	49	337	54	20	421	369	693	117	1750	2011-08-31 00:00:00	3	9
482	3	220	165	32	29	109	353	54	8	421	323	677	117	1608	2011-10-31 00:00:00	3	22
483	3	149	158	29	25	78	339	41	17	435	305	628	156	1533	2011-11-30 00:00:00	3	10
484	3	181	155	53	26	80	336	54	15	428	349	679	138	1608	2011-12-31 00:00:00	3	14
485	3	180	177	56	31	63	353	55	13	413	275	610	170	1474	2012-01-31 00:00:00	3	12
487	3	208	187	77	28	88	436	60	27	536	403	831	146	2127	2012-03-31 00:00:00	3	18
488	3	204	173	46	30	58	379	77	19	448	317	693	167	1850	2012-04-30 00:00:00	3	13
489	3	231	221	44	30	67	410	72	20	511	373	783	159	2028	2012-05-31 00:00:00	3	10
490	3	209	211	46	26	62	398	76	20	493	349	729	163	1846	2012-06-30 00:00:00	3	15
491	3	222	183	59	26	79	365	54	31	431	327	697	144	1807	2012-07-31 00:00:00	3	17
492	3	262	215	52	44	101	431	78	25	535	415	832	175	2262	2012-08-31 00:00:00	3	14
493	3	178	191	61	34	88	382	57	25	444	278	659	140	1898	2012-09-30 00:00:00	3	10
494	3	226	199	67	40	92	391	62	30	466	375	762	161	2162	2012-10-31 00:00:00	3	19
495	3	185	184	68	18	56	355	66	24	432	311	668	174	1977	2012-11-30 00:00:00	3	23
496	3	196	182	46	28	67	418	65	21	496	308	726	188	1842	2012-12-31 00:00:00	3	17
497	3	218	224	63	39	98	483	76	18	585	231	711	182	1996	2013-01-31 00:00:00	3	17
498	3	247	216	60	38	94	500	88	21	611	328	798	155	1980	2013-02-28 00:00:00	3	8
499	3	211	209	68	27	75	517	64	30	618	327	838	180	2231	2013-03-31 00:00:00	3	15
500	3	211	248	67	36	82	527	97	28	620	325	845	191	2381	2013-04-30 00:00:00	3	15
501	3	215	268	60	36	88	545	115	29	664	388	926	160	2085	2013-05-31 00:00:00	3	9
502	3	203	219	53	30	59	510	87	28	606	362	864	132	1910	2013-06-30 00:00:00	3	9
503	3	200	228	48	25	79	476	84	30	557	323	788	154	1826	2013-07-31 00:00:00	3	8
504	3	260	263	70	35	81	506	109	24	601	344	842	135	1953	2013-08-31 00:00:00	3	7
505	3	202	224	82	46	99	466	87	28	543	291	754	140	1954	2013-09-30 00:00:00	3	16
506	3	215	198	54	49	123	471	83	39	557	310	775	177	1970	2013-10-31 00:00:00	3	11
507	3	212	230	73	40	84	457	97	30	542	305	761	172	1763	2013-11-30 00:00:00	3	7
508	3	161	201	46	34	88	504	91	9	584	241	737	188	1541	2013-12-31 00:00:00	3	22
509	3	202	214	55	33	76	525	113	13	637	250	768	230	1810	2014-01-31 00:00:00	3	22
510	3	194	232	51	35	90	486	93	31	592	298	782	207	2088	2014-02-28 00:00:00	3	11
1025	6	80	370	57	88	290	1019	163	20	1285	689	1796	1513	5624	2011-07-31 00:00:00	6	100
1026	6	102	421	63	93	284	1201	211	34	1499	695	1975	1595	5964	2011-08-31 00:00:00	6	94
511	3	191	245	49	32	81	510	107	16	596	237	746	184	2063	2014-03-31 00:00:00	3	20
512	3	181	218	46	29	52	469	97	14	550	262	720	198	2299	2014-04-30 00:00:00	3	8
729	5	270	141	19	415	1034	1757	235	23	2205	487	2044	3615	7015	2002-01-31 00:00:00	5	475
513	3	186	208	52	27	85	491	107	28	581	286	774	228	1925	2014-05-31 00:00:00	3	15
514	3	195	259	58	35	74	503	128	47	598	286	783	196	1909	2014-06-30 00:00:00	3	17
741	5	201	252	23	353	1089	1562	159	22	2135	656	1880	3374	7318	2003-01-31 00:00:00	5	404
515	3	209	342	57	41	86	572	144	42	682	338	902	187	2040	2014-07-31 00:00:00	3	15
516	3	212	289	48	38	78	510	139	52	592	331	836	182	1946	2014-08-31 00:00:00	3	13
517	3	228	260	48	31	57	492	109	63	578	313	801	163	2016	2014-09-30 00:00:00	3	10
1027	6	89	399	74	66	266	1091	206	33	1451	646	1830	1696	5503	2011-09-30 00:00:00	6	93
518	3	197	280	73	30	59	533	127	38	620	289	817	168	1948	2014-10-31 00:00:00	3	16
1028	6	83	422	34	100	310	1144	240	31	1515	725	1938	1704	5626	2011-10-31 00:00:00	6	100
1029	6	89	376	55	86	238	1139	223	53	1422	568	1813	1603	5518	2011-11-30 00:00:00	6	88
519	3	181	244	37	29	72	495	114	53	572	369	862	184	1876	2014-11-30 00:00:00	3	13
1030	6	93	351	62	92	262	1055	184	14	1288	505	1640	1502	5337	2011-12-31 00:00:00	6	125
520	3	192	209	33	26	76	464	87	34	570	263	723	183	2026	2014-12-31 00:00:00	3	11
1031	6	89	432	33	95	279	1105	191	34	1396	570	1821	1546	5434	2012-01-31 00:00:00	6	97
533	3	217	221	56	34	73	476	107	31	579	298	770	184	1543	2016-01-31 00:00:00	3	15
535	3	219	302	49	30	86	549	112	64	647	415	962	154	2200	2016-03-31 00:00:00	3	18
1033	6	102	436	30	118	283	1224	238	24	1522	632	2011	1688	6743	2012-03-31 00:00:00	6	98
536	3	170	256	56	39	74	498	116	63	596	373	867	143	1861	2016-04-30 00:00:00	3	17
1034	6	111	416	41	102	266	1246	196	30	1596	546	1974	1705	6024	2012-04-30 00:00:00	6	92
537	3	191	262	41	43	86	505	117	38	621	393	894	170	1852	2016-05-31 00:00:00	3	10
1036	6	91	395	33	75	226	1183	187	21	1483	585	1877	1540	6266	2012-06-30 00:00:00	6	118
539	3	171	227	39	31	71	484	85	64	577	350	834	189	1606	2016-07-31 00:00:00	3	14
1037	6	69	454	51	69	234	1173	177	31	1513	586	1886	1517	6239	2012-07-31 00:00:00	6	106
1038	6	105	510	48	89	216	1239	222	40	1582	667	2060	1675	6767	2012-08-31 00:00:00	6	90
540	3	190	218	43	30	82	441	106	63	516	434	872	165	1989	2016-08-31 00:00:00	3	10
1040	6	97	465	50	90	232	1245	211	17	1569	525	1924	1590	6774	2012-10-31 00:00:00	6	155
541	3	209	219	41	32	67	475	93	45	537	343	817	183	1949	2016-09-30 00:00:00	3	10
1041	6	80	478	49	73	245	1167	209	26	1550	535	1852	1535	6002	2012-11-30 00:00:00	6	158
1042	6	80	422	61	84	246	1262	201	25	1593	508	1906	1551	5650	2012-12-31 00:00:00	6	125
542	3	186	266	45	36	98	532	122	43	635	429	957	221	1639	2016-10-31 00:00:00	3	12
1043	6	69	462	36	85	231	1444	251	13	1847	547	2101	1626	6345	2013-01-31 00:00:00	6	127
545	3	181	222	58	36	91	466	106	27	573	292	758	183	1580	2017-01-31 00:00:00	3	11
1045	6	116	544	49	68	244	1513	313	16	1935	530	2176	1617	6309	2013-03-31 00:00:00	6	99
546	3	175	221	42	31	74	452	97	41	534	381	835	151	1791	2017-02-28 00:00:00	3	16
1055	6	99	437	25	82	259	1415	257	37	1800	518	2034	2063	6310	2014-01-31 00:00:00	6	121
1058	6	83	371	30	86	245	1364	249	43	1781	516	2002	1835	5883	2014-04-30 00:00:00	6	97
1059	6	89	345	30	74	244	1282	243	45	1644	636	2054	1947	5571	2014-05-31 00:00:00	6	101
1060	6	82	402	47	83	238	1421	304	48	1861	525	2153	1789	5890	2014-06-30 00:00:00	6	81
2003	11	55	23	3	55	88	168	11	10	207	99	190	65	953	2002-01-31 00:00:00	11	10
1061	6	86	425	42	62	277	1309	286	34	1707	696	2210	1646	6136	2014-07-31 00:00:00	6	100
1062	6	71	404	42	94	271	1420	325	65	1876	767	2393	1752	6130	2014-08-31 00:00:00	6	88
1063	6	78	430	59	84	233	1465	287	39	1890	661	2271	1772	6104	2014-09-30 00:00:00	6	80
1064	6	76	341	44	59	254	1268	318	41	1662	579	1970	1958	6336	2014-10-31 00:00:00	6	79
2005	11	61	39	6	35	54	148	7	20	209	212	199	54	960	2002-03-31 00:00:00	11	13
731	5	240	148	22	348	926	1672	234	57	2166	521	1982	3889	6728	2002-03-31 00:00:00	5	499
732	5	250	228	30	389	1152	1937	220	37	2518	524	2252	3852	7824	2002-04-30 00:00:00	5	427
733	5	270	204	24	401	1052	1934	262	37	2443	679	2325	3971	7826	2002-05-31 00:00:00	5	410
734	5	197	245	34	334	1012	1575	221	8	2069	667	1948	3386	6760	2002-06-30 00:00:00	5	371
735	5	198	267	18	354	980	1678	228	19	2120	592	2020	3404	7403	2002-07-31 00:00:00	5	356
736	5	274	319	21	328	1018	1666	254	10	2263	685	2036	3204	7242	2002-08-31 00:00:00	5	361
737	5	240	297	10	369	948	1546	203	10	2007	743	1944	3095	7047	2002-09-30 00:00:00	5	362
738	5	251	278	14	354	1060	1573	233	17	2088	495	1866	3177	7900	2002-10-31 00:00:00	5	387
2006	11	47	43	5	68	76	141	10	10	183	198	162	74	1106	2002-04-30 00:00:00	11	11
2007	11	41	36	5	68	64	135	12	4	183	237	163	81	1134	2002-05-31 00:00:00	11	8
2008	11	58	60	2	57	59	148	10	8	184	206	184	53	927	2002-06-30 00:00:00	11	5
739	5	244	309	14	381	998	1565	249	16	2180	613	1902	3071	7049	2002-11-30 00:00:00	5	418
743	5	270	286	15	393	1080	1794	145	64	2315	598	2088	3441	7227	2003-03-31 00:00:00	5	414
744	5	210	318	12	372	1060	1705	160	57	2263	691	2091	3218	7507	2003-04-30 00:00:00	5	375
745	5	277	287	23	397	1103	1777	161	28	2369	765	2215	3505	8126	2003-05-31 00:00:00	5	362
746	5	274	230	18	399	1053	1664	141	19	2266	925	2134	3223	8032	2003-06-30 00:00:00	5	371
753	5	250	239	10	316	941	1488	105	5	2013	848	1903	2969	7614	2004-01-31 00:00:00	5	330
1065	6	95	402	66	76	270	1319	247	38	1695	763	2205	1788	5706	2014-11-30 00:00:00	6	106
1066	6	56	287	36	69	251	1226	225	48	1604	459	1807	1925	5131	2014-12-31 00:00:00	6	100
1079	6	327	428	45	71	237	1410	271	27	1797	677	2236	1559	5235	2016-01-31 00:00:00	6	74
2009	11	51	46	3	47	59	159	6	17	192	138	201	65	919	2002-07-31 00:00:00	11	7
1081	6	400	485	46	78	242	1756	395	42	2252	803	2790	1601	6457	2016-03-31 00:00:00	6	67
1082	6	405	522	56	74	216	1707	350	59	2089	742	2610	1552	5696	2016-04-30 00:00:00	6	70
1083	6	290	490	33	77	212	1657	331	42	2178	880	2665	1524	5865	2016-05-31 00:00:00	6	62
1084	6	399	499	30	70	175	1534	357	75	1888	814	2466	1468	6061	2016-06-30 00:00:00	6	44
1085	6	268	474	28	76	203	1549	375	30	1963	777	2473	1592	5675	2016-07-31 00:00:00	6	77
1086	6	225	555	37	57	235	1626	421	69	1960	817	2579	1524	5969	2016-08-31 00:00:00	6	60
1087	6	249	512	38	60	164	1537	369	127	1904	789	2456	1427	5787	2016-09-30 00:00:00	6	66
1088	6	255	449	34	66	231	1582	267	54	1975	828	2613	1562	5542	2016-10-31 00:00:00	6	85
1091	6	166	529	33	65	190	1493	307	45	1832	874	2469	1574	5603	2017-01-31 00:00:00	6	78
1825	12	117	80	51	77	140	402	39	10	500	220	589	223	1962	2002-05-31 00:00:00	12	47
1826	12	124	60	25	65	126	332	27	16	421	188	506	170	1838	2002-06-30 00:00:00	12	45
1827	12	110	68	32	86	159	358	26	7	434	225	568	165	1744	2002-07-31 00:00:00	12	52
1828	12	138	74	22	70	172	412	20	1	487	235	593	193	2107	2002-08-31 00:00:00	12	54
1829	12	130	68	19	63	144	392	43	9	452	232	588	229	2081	2002-09-30 00:00:00	12	44
1830	12	119	72	22	62	126	396	70	21	490	194	590	217	2158	2002-10-31 00:00:00	12	38
1831	12	135	89	40	84	135	393	46	16	517	154	525	186	2000	2002-11-30 00:00:00	12	41
1833	12	130	79	31	72	151	427	70	9	537	156	585	226	2002	2003-01-31 00:00:00	12	45
1835	12	124	87	19	109	179	477	87	5	606	238	772	226	2264	2003-03-31 00:00:00	12	62
1836	12	110	89	24	90	203	413	62	2	559	232	659	228	2170	2003-04-30 00:00:00	12	61
1837	12	87	91	13	96	165	425	37	3	556	263	635	223	2123	2003-05-31 00:00:00	12	56
1838	12	101	89	19	107	199	435	42	6	566	255	704	220	2171	2003-06-30 00:00:00	12	41
1839	12	102	91	30	79	164	402	52	2	500	279	626	237	2144	2003-07-31 00:00:00	12	28
1840	12	103	86	13	76	166	442	67	8	580	192	627	262	2197	2003-08-31 00:00:00	12	42
1841	12	109	105	27	75	164	433	55	15	559	193	607	244	2193	2003-09-30 00:00:00	12	48
1842	12	112	91	27	79	167	444	61	10	572	227	688	229	2137	2003-10-31 00:00:00	12	37
1843	12	119	85	27	63	161	398	48	5	555	199	598	175	1871	2003-11-30 00:00:00	12	32
1844	12	103	85	18	78	167	391	43	13	527	208	603	173	1936	2003-12-31 00:00:00	12	34
1845	12	108	84	20	82	168	412	53	7	546	142	563	165	1668	2004-01-31 00:00:00	12	35
1847	12	82	101	30	74	172	375	77	3	483	211	575	220	2180	2004-03-31 00:00:00	12	42
1848	12	100	91	26	68	182	357	60	8	454	203	525	212	1950	2004-04-30 00:00:00	12	47
1849	12	85	84	31	72	175	329	57	20	425	174	522	225	1947	2004-05-31 00:00:00	12	45
1850	12	96	85	14	72	140	315	61	8	433	213	502	244	1892	2004-06-30 00:00:00	12	33
1851	12	87	68	22	54	122	331	39	0	432	192	521	241	1749	2004-07-31 00:00:00	12	37
1852	12	89	94	37	61	143	400	57	14	549	173	576	259	1891	2004-08-31 00:00:00	12	59
1853	12	75	94	26	62	124	338	87	4	444	156	502	217	1866	2004-09-30 00:00:00	12	46
1854	12	85	101	20	52	157	330	46	2	456	153	488	213	1790	2004-10-31 00:00:00	12	33
1855	12	81	87	22	53	124	321	68	11	444	165	499	222	1715	2004-11-30 00:00:00	12	43
1856	12	110	98	36	48	122	320	50	10	435	189	511	250	1711	2004-12-31 00:00:00	12	35
1857	12	96	112	20	52	134	348	63	3	482	190	562	292	1669	2005-01-31 00:00:00	12	34
1859	12	75	106	23	66	123	414	69	6	533	203	626	237	1777	2005-03-31 00:00:00	12	31
1860	12	88	101	6	64	138	328	78	8	447	181	503	191	1428	2005-04-30 00:00:00	12	39
1861	12	84	120	20	61	145	369	71	8	468	182	574	250	1693	2005-05-31 00:00:00	12	25
1862	12	87	90	23	54	128	348	54	8	478	222	543	234	1612	2005-06-30 00:00:00	12	20
740	5	206	215	17	317	898	1524	115	9	1997	477	1755	3106	7009	2002-12-31 00:00:00	5	413
2010	11	71	62	7	56	83	198	7	3	240	207	230	69	1229	2002-08-31 00:00:00	11	6
765	5	190	257	16	256	836	1503	150	25	2003	806	1784	3097	7721	2005-01-31 00:00:00	5	290
777	5	166	278	20	217	614	1402	192	9	1826	715	1640	2534	7751	2006-01-31 00:00:00	5	183
1863	12	70	74	28	47	99	295	45	1	367	197	465	257	1447	2005-07-31 00:00:00	12	30
789	5	190	290	22	177	479	1582	109	13	2131	625	1789	2533	8097	2007-01-31 00:00:00	5	140
801	5	200	449	30	176	556	1532	164	14	1961	759	1816	1917	8265	2008-01-31 00:00:00	5	97
813	5	184	479	25	156	488	1676	184	33	2137	615	2016	2534	7334	2009-01-31 00:00:00	5	107
825	5	152	411	23	125	445	1589	154	18	2270	604	1913	2355	7262	2010-01-31 00:00:00	5	131
1864	12	104	121	16	63	173	382	92	6	505	228	601	296	1728	2005-08-31 00:00:00	12	25
1865	12	98	113	29	53	121	362	89	8	462	212	583	240	1677	2005-09-30 00:00:00	12	26
1866	12	103	131	21	52	133	368	97	7	465	166	524	204	1545	2005-10-31 00:00:00	12	31
1867	12	85	99	31	67	148	370	76	2	468	165	540	211	1500	2005-11-30 00:00:00	12	32
1868	12	75	86	23	46	108	307	42	4	398	194	468	224	1472	2005-12-31 00:00:00	12	29
1869	12	130	111	36	50	144	346	64	17	486	215	560	247	1497	2006-01-31 00:00:00	12	25
1871	12	107	121	44	57	172	374	79	6	489	183	544	266	1791	2006-03-31 00:00:00	12	48
1872	12	92	124	29	43	130	387	47	8	501	231	593	252	1452	2006-04-30 00:00:00	12	25
1873	12	100	103	40	54	141	363	51	5	510	201	554	235	1732	2006-05-31 00:00:00	12	57
1874	12	63	93	14	46	194	339	61	4	447	186	512	250	1536	2006-06-30 00:00:00	12	36
1875	12	72	85	22	41	89	351	68	8	490	202	559	274	1467	2006-07-31 00:00:00	12	30
1876	12	113	120	41	41	127	372	62	1	491	242	615	254	1766	2006-08-31 00:00:00	12	29
1878	12	72	121	15	45	105	394	68	1	497	187	569	281	1767	2006-10-31 00:00:00	12	31
1879	12	84	107	19	58	99	393	64	6	450	224	595	215	1783	2006-11-30 00:00:00	12	26
1880	12	100	103	27	42	81	352	48	5	469	187	546	205	1735	2006-12-31 00:00:00	12	29
1881	12	101	147	27	60	110	431	75	5	565	222	629	208	1752	2007-01-31 00:00:00	12	35
1882	12	112	149	18	45	100	386	53	9	514	194	579	195	1795	2007-02-28 00:00:00	12	18
1883	12	116	185	25	51	110	456	95	3	604	329	726	214	2034	2007-03-31 00:00:00	12	24
1884	12	90	134	32	35	87	388	119	16	506	206	598	222	1970	2007-04-30 00:00:00	12	25
1885	12	84	146	29	45	100	398	80	4	540	279	660	190	1936	2007-05-31 00:00:00	12	25
1886	12	61	147	30	35	88	350	53	5	475	267	603	205	1823	2007-06-30 00:00:00	12	18
1887	12	73	115	23	24	54	311	74	2	388	247	529	190	1629	2007-07-31 00:00:00	12	16
1888	12	96	148	28	48	89	399	74	4	485	252	651	243	1897	2007-08-31 00:00:00	12	24
1889	12	105	142	30	34	93	396	119	3	547	267	666	175	1753	2007-09-30 00:00:00	12	17
1893	12	106	192	36	34	64	389	80	2	546	243	632	176	1715	2008-01-31 00:00:00	12	35
1895	12	78	144	27	35	108	370	87	4	457	276	646	216	1826	2008-03-31 00:00:00	12	18
1896	12	68	153	39	40	85	377	67	6	509	294	676	229	1831	2008-04-30 00:00:00	12	23
1897	12	83	139	24	35	79	358	67	10	486	215	573	231	1811	2008-05-31 00:00:00	12	15
1898	12	96	164	35	37	83	387	76	4	539	237	624	226	1837	2008-06-30 00:00:00	12	19
1899	12	96	163	35	36	61	404	69	6	517	273	678	201	1780	2008-07-31 00:00:00	12	16
1900	12	86	160	41	24	71	407	90	8	522	221	626	203	1872	2008-08-31 00:00:00	12	27
1901	12	64	126	32	13	54	346	84	6	407	168	515	161	1501	2008-09-30 00:00:00	12	23
1905	12	133	166	25	37	68	477	57	6	606	293	770	224	1609	2009-01-31 00:00:00	12	28
1906	12	113	183	36	43	82	497	61	8	630	258	755	223	1682	2009-02-28 00:00:00	12	23
1907	12	85	164	28	45	103	445	132	21	562	302	747	279	1940	2009-03-31 00:00:00	12	36
1908	12	102	172	32	28	99	430	66	7	563	286	716	280	1820	2009-04-30 00:00:00	12	42
1909	12	78	182	30	53	120	464	68	8	565	279	743	281	2138	2009-05-31 00:00:00	12	32
1910	12	75	177	15	40	104	413	53	9	559	257	670	284	1904	2009-06-30 00:00:00	12	23
1911	12	105	170	22	36	108	404	79	13	504	236	640	260	1894	2009-07-31 00:00:00	12	30
1912	12	82	181	20	40	85	430	53	15	569	300	730	263	1958	2009-08-31 00:00:00	12	29
1913	12	95	207	20	37	104	454	81	8	571	279	732	233	2102	2009-09-30 00:00:00	12	30
1915	12	68	198	33	35	90	397	57	1	546	255	652	256	1814	2009-11-30 00:00:00	12	26
1916	12	110	185	17	32	83	406	48	9	497	268	669	237	2063	2009-12-31 00:00:00	12	31
1917	12	87	222	12	38	82	430	58	1	578	218	648	223	1786	2010-01-31 00:00:00	12	37
1919	12	82	198	22	29	76	437	59	8	537	297	734	273	2152	2010-03-31 00:00:00	12	32
775	5	200	300	24	235	666	1504	175	16	2014	783	1752	2766	8951	2005-11-30 00:00:00	5	195
776	5	179	265	20	222	608	1364	165	10	1784	656	1574	2604	7680	2005-12-31 00:00:00	5	181
786	5	174	308	13	189	705	1665	175	11	2140	537	1870	2671	9650	2006-10-31 00:00:00	5	143
1920	12	76	210	28	18	46	396	87	7	499	285	681	234	1820	2010-04-30 00:00:00	12	29
1921	12	77	209	18	29	83	421	78	10	538	317	738	241	1813	2010-05-31 00:00:00	12	17
1922	12	81	212	27	33	93	394	75	11	511	237	631	284	1962	2010-06-30 00:00:00	12	24
1923	12	95	206	12	26	56	393	64	9	491	226	619	302	1634	2010-07-31 00:00:00	12	27
787	5	194	310	23	190	605	1650	161	27	1996	649	1805	2570	8745	2006-11-30 00:00:00	5	178
788	5	202	207	18	173	529	1437	87	17	1892	637	1652	2269	8323	2006-12-31 00:00:00	5	145
798	5	248	423	25	178	554	1629	176	13	2232	765	1895	2390	8934	2007-10-31 00:00:00	5	132
799	5	232	415	31	164	606	1593	165	6	2193	959	1972	2087	8020	2007-11-30 00:00:00	5	129
837	5	113	423	20	115	435	1641	166	19	2032	683	2004	2580	7433	2011-01-31 00:00:00	5	95
849	5	130	735	13	117	402	2207	190	8	2485	562	1974	3126	8627	2012-01-31 00:00:00	5	92
861	5	99	663	50	117	395	2408	200	79	2711	549	2224	3296	10390	2013-01-31 00:00:00	5	109
873	5	233	508	41	108	445	2332	310	31	2853	654	2643	3648	9855	2014-01-31 00:00:00	5	104
897	5	948	644	13	117	313	2499	370	27	3014	822	2772	2911	7656	2016-01-31 00:00:00	5	59
911	6	96	84	12	248	553	928	116	19	1177	285	1298	1946	4181	2002-01-31 00:00:00	6	298
913	6	120	84	15	239	614	931	95	20	1199	296	1277	1873	3989	2002-03-31 00:00:00	6	365
914	6	102	96	11	243	663	975	109	24	1297	454	1513	2114	4748	2002-04-30 00:00:00	6	305
915	6	112	105	11	266	708	955	123	26	1222	423	1431	1931	4535	2002-05-31 00:00:00	6	323
916	6	126	117	61	236	546	860	120	21	1131	380	1357	1841	4069	2002-06-30 00:00:00	6	282
923	6	121	114	39	215	612	916	111	21	1288	427	1528	1717	4729	2003-01-31 00:00:00	6	273
925	6	116	131	47	264	584	1006	135	10	1327	377	1499	1805	5115	2003-03-31 00:00:00	6	277
926	6	100	118	36	289	801	1043	160	11	1515	385	1694	1857	5135	2003-04-30 00:00:00	6	314
927	6	122	123	46	245	646	1045	193	15	1540	546	1870	1899	6275	2003-05-31 00:00:00	6	309
928	6	108	116	41	224	544	1039	206	8	1459	511	1765	1653	5626	2003-06-30 00:00:00	6	278
935	6	106	141	31	230	561	915	141	19	1259	356	1408	1560	4591	2004-01-31 00:00:00	6	220
937	6	91	141	35	211	601	943	203	12	1365	444	1631	1607	5370	2004-03-31 00:00:00	6	207
938	6	99	139	33	187	518	887	254	15	1234	417	1440	1661	4603	2004-04-30 00:00:00	6	230
939	6	97	130	36	225	533	940	203	30	1256	424	1479	1756	4869	2004-05-31 00:00:00	6	210
940	6	97	150	38	192	516	850	222	46	1154	416	1416	1637	4876	2004-06-30 00:00:00	6	230
947	6	80	152	47	181	435	846	161	21	1161	360	1346	1453	4363	2005-01-31 00:00:00	6	185
949	6	75	159	25	211	503	934	210	25	1276	424	1509	1592	5049	2005-03-31 00:00:00	6	182
950	6	84	181	41	151	435	909	190	28	1211	394	1420	1570	4759	2005-04-30 00:00:00	6	189
951	6	89	159	43	159	459	922	209	19	1225	438	1468	1420	4617	2005-05-31 00:00:00	6	168
959	6	87	183	37	128	356	779	146	17	1113	448	1337	1168	4116	2006-01-31 00:00:00	6	159
961	6	117	211	48	149	412	919	143	11	1283	488	1468	1375	4853	2006-03-31 00:00:00	6	159
962	6	114	236	45	150	415	843	205	22	1167	470	1454	1369	3935	2006-04-30 00:00:00	6	137
963	6	99	223	38	158	543	798	149	7	1198	499	1417	1237	4348	2006-05-31 00:00:00	6	235
1924	12	96	205	38	43	90	402	60	3	512	253	655	252	1819	2010-08-31 00:00:00	12	26
1925	12	98	217	20	30	65	393	51	9	471	297	690	250	1837	2010-09-30 00:00:00	12	25
1926	12	108	211	23	19	73	401	59	10	482	283	684	253	1673	2010-10-31 00:00:00	12	23
835	5	116	436	30	114	430	1703	186	30	2094	599	2038	2614	7916	2010-11-30 00:00:00	5	97
836	5	118	411	19	108	533	1624	164	12	2073	636	1981	2599	7928	2010-12-31 00:00:00	5	100
845	5	106	544	21	139	472	1883	161	10	2512	685	1913	3315	8846	2011-09-30 00:00:00	5	71
846	5	104	602	45	137	383	2076	122	21	2446	479	1955	3245	8356	2011-10-31 00:00:00	5	82
847	5	107	530	28	126	431	1669	180	12	2427	478	1785	3188	8389	2011-11-30 00:00:00	5	99
909	5	210	709	19	90	293	2635	364	3	3154	1288	2875	2652	8179	2017-01-31 00:00:00	5	58
1927	12	85	216	10	29	58	414	52	17	507	203	617	238	1886	2010-11-30 00:00:00	12	39
1928	12	123	217	16	32	71	377	57	3	504	222	599	248	1794	2010-12-31 00:00:00	12	30
1929	12	120	251	13	33	76	441	49	3	571	243	684	265	1779	2011-01-31 00:00:00	12	36
1930	12	102	201	20	42	85	392	33	0	489	253	645	284	1877	2011-02-28 00:00:00	12	31
1931	12	156	268	26	30	73	488	56	8	634	272	760	314	1988	2011-03-31 00:00:00	12	34
1932	12	134	204	26	27	82	441	66	16	540	231	672	292	1765	2011-04-30 00:00:00	12	26
1933	12	148	267	26	41	110	498	62	30	655	351	849	262	2069	2011-05-31 00:00:00	12	38
1934	12	100	217	20	34	88	410	45	13	514	275	685	281	1971	2011-06-30 00:00:00	12	33
1935	12	125	212	14	28	97	393	33	5	507	245	638	255	1887	2011-07-31 00:00:00	12	31
1936	12	138	242	15	33	113	452	47	14	566	342	795	271	2286	2011-08-31 00:00:00	12	46
1937	12	125	208	28	41	91	425	63	24	523	325	750	325	2031	2011-09-30 00:00:00	12	34
1938	12	136	218	30	27	70	473	53	18	573	332	805	266	1944	2011-10-31 00:00:00	12	37
1939	12	135	246	18	39	74	479	67	22	557	305	784	278	1967	2011-11-30 00:00:00	12	29
1940	12	142	197	17	39	90	417	60	18	489	249	665	306	1728	2011-12-31 00:00:00	12	36
1941	12	134	200	30	45	105	500	72	10	604	222	722	303	2030	2012-01-31 00:00:00	12	35
1943	12	129	229	28	43	94	466	77	24	573	353	819	343	2228	2012-03-31 00:00:00	12	37
1944	12	124	279	30	36	104	535	79	13	672	352	887	331	1830	2012-04-30 00:00:00	12	30
1946	12	123	249	30	39	102	439	77	14	566	295	734	280	2206	2012-06-30 00:00:00	12	38
1947	12	99	310	17	47	120	524	92	11	643	295	821	355	2104	2012-07-31 00:00:00	12	30
1948	12	158	314	22	46	101	535	106	12	714	297	832	312	2276	2012-08-31 00:00:00	12	31
1950	12	116	292	31	37	93	507	88	13	592	275	782	295	2267	2012-10-31 00:00:00	12	34
1951	12	137	264	17	38	84	439	70	10	511	285	724	277	1854	2012-11-30 00:00:00	12	27
1952	12	101	264	29	41	69	531	87	8	611	230	761	342	2112	2012-12-31 00:00:00	12	55
1953	12	114	387	30	51	96	636	104	21	713	242	878	336	2384	2013-01-31 00:00:00	12	35
1954	12	138	296	19	43	92	609	96	7	750	240	849	341	2263	2013-02-28 00:00:00	12	42
2011	11	80	53	7	60	74	171	16	3	215	147	203	55	1080	2002-09-30 00:00:00	11	8
2012	11	65	63	3	55	76	176	4	8	224	137	212	37	1255	2002-10-31 00:00:00	11	17
2013	11	67	39	2	58	85	180	9	7	215	184	212	58	1116	2002-11-30 00:00:00	11	13
2014	11	57	32	11	61	73	198	8	16	248	184	224	67	1001	2002-12-31 00:00:00	11	13
2015	11	70	35	6	36	78	187	7	7	243	158	205	48	960	2003-01-31 00:00:00	11	13
2017	11	61	38	2	75	95	184	12	7	237	210	215	68	1082	2003-03-31 00:00:00	11	8
2019	11	69	47	1	64	87	215	16	6	273	200	226	66	1085	2003-05-31 00:00:00	11	9
2020	11	56	35	4	51	91	208	13	11	284	182	231	70	1110	2003-06-30 00:00:00	11	10
2021	11	62	52	5	55	83	214	15	11	271	187	234	68	1090	2003-07-31 00:00:00	11	6
2023	11	62	46	2	57	83	205	15	5	267	214	223	76	1166	2003-09-30 00:00:00	11	6
917	6	106	120	41	236	648	901	102	15	1211	424	1471	1851	4458	2002-07-31 00:00:00	6	281
2024	11	85	42	2	63	95	204	14	2	263	184	225	98	1168	2003-10-31 00:00:00	11	5
2025	11	77	39	11	56	87	189	12	9	239	204	205	75	1044	2003-11-30 00:00:00	11	8
2026	11	53	42	5	53	79	167	14	11	225	139	172	63	880	2003-12-31 00:00:00	11	7
918	6	137	126	34	251	687	955	110	23	1223	401	1470	1829	4669	2002-08-31 00:00:00	6	264
2027	11	65	47	2	48	68	173	14	11	211	110	184	73	858	2004-01-31 00:00:00	11	10
2029	11	65	40	5	41	81	203	13	8	267	193	222	97	1161	2004-03-31 00:00:00	11	3
919	6	109	119	35	248	668	879	110	19	1160	422	1439	1742	4530	2002-09-30 00:00:00	6	263
920	6	97	117	61	229	616	873	150	20	1142	296	1280	1850	5178	2002-10-31 00:00:00	6	272
1955	12	125	311	23	50	90	593	107	28	692	279	872	307	2326	2013-03-31 00:00:00	12	42
1956	12	154	288	35	47	110	549	111	18	641	275	825	297	2206	2013-04-30 00:00:00	12	42
1957	12	123	269	31	57	99	605	76	12	683	264	869	315	2165	2013-05-31 00:00:00	12	24
1958	12	104	307	39	39	118	573	102	19	674	284	857	282	2020	2013-06-30 00:00:00	12	26
1959	12	131	300	27	35	112	552	83	22	628	256	808	297	2134	2013-07-31 00:00:00	12	21
1965	12	93	251	17	58	163	599	165	16	690	307	906	339	2252	2014-01-31 00:00:00	12	36
1967	12	99	215	7	38	88	522	142	11	594	236	760	281	2076	2014-03-31 00:00:00	12	34
1968	12	101	240	25	57	94	442	126	17	491	290	732	337	1866	2014-04-30 00:00:00	12	40
1969	12	143	247	29	52	115	504	205	30	564	265	769	373	2073	2014-05-31 00:00:00	12	30
1970	12	139	250	10	47	95	541	67	19	647	269	810	394	2037	2014-06-30 00:00:00	12	34
1971	12	145	224	12	46	90	464	159	33	544	275	739	309	1820	2014-07-31 00:00:00	12	33
1973	12	170	273	23	48	110	502	182	44	580	322	824	269	1938	2014-09-30 00:00:00	12	29
1974	12	168	301	18	43	70	521	200	28	585	257	778	305	2117	2014-10-31 00:00:00	12	28
1975	12	143	250	22	46	82	486	178	31	563	331	815	291	1888	2014-11-30 00:00:00	12	30
1976	12	158	259	16	57	101	497	123	34	559	226	724	329	1869	2014-12-31 00:00:00	12	27
1977	12	142	339	17	53	89	561	180	14	656	271	832	263	2019	2015-01-31 00:00:00	12	32
1979	12	165	295	17	51	94	533	180	35	629	285	818	302	2139	2015-03-31 00:00:00	12	37
1980	12	140	289	21	46	111	489	212	24	556	307	787	287	1902	2015-04-30 00:00:00	12	42
1981	12	119	342	12	62	104	532	188	32	610	311	843	335	1844	2015-05-31 00:00:00	12	28
1982	12	146	318	11	44	84	523	174	35	618	323	846	259	1815	2015-06-30 00:00:00	12	22
1983	12	135	307	8	47	108	557	157	29	628	359	916	250	2167	2015-07-31 00:00:00	12	23
1984	12	152	299	20	50	113	495	180	32	558	364	859	268	2077	2015-08-31 00:00:00	12	34
1985	12	153	270	23	51	103	508	166	11	596	320	828	248	2050	2015-09-30 00:00:00	12	28
1986	12	134	252	12	76	122	495	144	21	591	311	806	261	1897	2015-10-31 00:00:00	12	27
1987	12	132	268	25	47	79	491	195	37	562	307	798	272	2015	2015-11-30 00:00:00	12	43
1988	12	129	229	13	60	91	494	138	18	553	227	722	266	1957	2015-12-31 00:00:00	12	36
1989	12	147	277	27	58	101	537	144	22	639	260	798	255	1994	2016-01-31 00:00:00	12	41
1991	12	161	266	31	51	94	500	130	37	600	319	819	280	2308	2016-03-31 00:00:00	12	36
1992	12	148	239	16	61	105	514	144	27	582	276	790	239	2148	2016-04-30 00:00:00	12	41
1993	12	137	267	12	59	106	564	111	33	643	314	878	262	2237	2016-05-31 00:00:00	12	33
1994	12	133	250	17	59	105	514	137	28	605	324	838	298	2234	2016-06-30 00:00:00	12	31
1995	12	126	284	5	50	87	488	146	35	559	310	798	230	1908	2016-07-31 00:00:00	12	23
1996	12	152	264	16	44	80	552	135	44	631	306	858	279	2444	2016-08-31 00:00:00	12	34
1997	12	133	236	10	61	90	500	149	30	607	291	792	276	2263	2016-09-30 00:00:00	12	40
1998	12	133	226	19	56	151	538	105	31	606	281	819	284	2071	2016-10-31 00:00:00	12	46
1999	12	87	256	8	43	86	522	129	36	596	288	810	259	1975	2016-11-30 00:00:00	12	34
2000	12	101	225	5	44	81	440	107	17	518	255	695	293	1985	2016-12-31 00:00:00	12	40
2001	12	155	292	5	46	109	575	130	24	670	254	829	287	2057	2017-01-31 00:00:00	12	30
2030	11	70	49	3	52	80	167	24	8	204	190	173	114	1022	2004-04-30 00:00:00	11	5
2031	11	54	38	4	45	57	172	9	23	227	214	188	120	1038	2004-05-31 00:00:00	11	13
2032	11	78	51	4	50	67	176	8	12	243	187	196	115	1074	2004-06-30 00:00:00	11	2
2033	11	60	42	2	38	54	158	7	7	211	116	188	76	934	2004-07-31 00:00:00	11	7
2034	11	78	57	5	52	60	202	7	11	251	153	221	101	1003	2004-08-31 00:00:00	11	10
2035	11	41	38	2	54	75	153	6	4	199	72	169	85	930	2004-09-30 00:00:00	11	9
2036	11	45	49	3	55	54	173	3	8	222	125	186	82	1103	2004-10-31 00:00:00	11	8
2037	11	72	36	4	35	78	177	6	8	225	173	216	63	984	2004-11-30 00:00:00	11	10
2038	11	53	45	2	42	46	163	7	12	221	143	180	106	953	2004-12-31 00:00:00	11	9
2039	11	47	57	2	55	62	202	11	1	248	139	220	121	781	2005-01-31 00:00:00	11	9
2040	11	58	68	3	47	85	193	5	19	264	152	215	92	959	2005-02-28 00:00:00	11	11
2041	11	67	49	15	52	74	194	4	16	232	238	254	71	1103	2005-03-31 00:00:00	11	7
2042	11	63	51	6	40	50	175	6	7	225	186	201	64	969	2005-04-30 00:00:00	11	9
2043	11	60	52	1	52	65	187	9	7	242	219	211	70	1053	2005-05-31 00:00:00	11	2
2044	11	53	54	4	29	51	188	13	22	244	291	231	85	1101	2005-06-30 00:00:00	11	9
2045	11	47	45	1	44	76	166	6	5	197	250	194	78	786	2005-07-31 00:00:00	11	10
2046	11	60	54	4	43	93	185	3	19	219	265	221	68	1100	2005-08-31 00:00:00	11	5
2047	11	64	32	8	39	44	134	8	9	191	231	174	60	895	2005-09-30 00:00:00	11	5
2048	11	71	60	0	42	46	186	15	8	245	173	210	82	921	2005-10-31 00:00:00	11	9
2049	11	96	46	1	47	41	167	18	9	218	158	193	104	833	2005-11-30 00:00:00	11	9
2050	11	65	51	4	48	69	173	12	20	228	182	187	109	1018	2005-12-31 00:00:00	11	5
2051	11	66	53	1	36	58	166	12	10	223	170	199	87	786	2006-01-31 00:00:00	11	6
2052	11	85	56	5	41	54	152	10	6	210	251	176	76	931	2006-02-28 00:00:00	11	6
2053	11	88	53	4	41	53	190	14	13	243	289	235	55	1129	2006-03-31 00:00:00	11	11
2054	11	73	54	4	55	59	180	15	10	243	227	206	79	910	2006-04-30 00:00:00	11	10
2055	11	74	52	4	30	43	159	16	9	212	235	184	62	1033	2006-05-31 00:00:00	11	9
2056	11	61	53	1	49	80	171	22	14	233	259	190	76	1001	2006-06-30 00:00:00	11	8
2057	11	62	58	1	47	66	156	4	2	201	237	195	66	823	2006-07-31 00:00:00	11	5
2058	11	67	50	0	35	50	158	12	5	193	283	185	59	1029	2006-08-31 00:00:00	11	9
2059	11	47	33	5	27	43	152	6	2	196	173	177	51	905	2006-09-30 00:00:00	11	8
2060	11	51	59	3	43	77	246	12	2	311	207	272	102	1153	2006-10-31 00:00:00	11	6
2061	11	40	60	2	42	78	224	10	7	279	246	255	86	1065	2006-11-30 00:00:00	11	12
2062	11	55	54	8	34	68	172	16	4	212	163	199	57	969	2006-12-31 00:00:00	11	10
2063	11	57	60	6	42	51	181	14	4	246	170	216	110	957	2007-01-31 00:00:00	11	9
2064	11	60	54	13	30	50	202	5	9	252	233	230	89	1115	2007-02-28 00:00:00	11	10
2065	11	61	78	4	39	49	209	11	8	272	277	225	94	1026	2007-03-31 00:00:00	11	6
2066	11	64	85	6	45	65	187	12	5	231	227	219	101	1126	2007-04-30 00:00:00	11	8
2067	11	77	92	9	28	59	176	15	9	221	271	213	72	1065	2007-05-31 00:00:00	11	6
2068	11	71	86	5	29	64	166	17	7	217	291	194	71	1014	2007-06-30 00:00:00	11	8
2069	11	58	81	3	32	89	193	9	13	245	206	219	49	1016	2007-07-31 00:00:00	11	5
2070	11	65	96	6	29	66	204	8	17	265	256	239	44	1103	2007-08-31 00:00:00	11	6
2071	11	82	74	7	28	48	205	16	5	247	282	244	57	998	2007-09-30 00:00:00	11	8
2072	11	67	82	3	40	70	204	15	17	249	244	256	51	1013	2007-10-31 00:00:00	11	8
2073	11	76	85	7	36	35	171	2	11	216	301	231	53	1013	2007-11-30 00:00:00	11	9
2074	11	64	54	5	27	48	182	18	7	223	165	227	50	840	2007-12-31 00:00:00	11	4
976	6	93	272	36	128	365	978	135	32	1311	618	1688	1156	4799	2007-06-30 00:00:00	6	117
2075	11	79	52	5	32	45	174	18	13	218	178	207	64	903	2008-01-31 00:00:00	11	3
2077	11	78	92	5	40	56	231	11	9	319	291	288	80	1049	2008-03-31 00:00:00	11	5
2078	11	57	75	6	37	73	182	20	10	231	273	219	82	1095	2008-04-30 00:00:00	11	7
2079	11	82	88	2	41	49	188	11	13	245	286	238	74	1044	2008-05-31 00:00:00	11	4
2080	11	110	88	4	47	76	185	12	13	258	247	229	66	1111	2008-06-30 00:00:00	11	4
2081	11	84	67	12	34	67	185	13	10	225	258	216	57	1062	2008-07-31 00:00:00	11	4
2082	11	77	85	0	41	54	211	6	12	275	202	237	53	1146	2008-08-31 00:00:00	11	6
2083	11	59	60	4	23	42	143	17	7	170	160	162	66	783	2008-09-30 00:00:00	11	7
2084	11	75	59	4	11	29	171	13	9	218	93	198	76	623	2008-10-31 00:00:00	11	5
2085	11	72	62	8	33	64	180	18	7	212	213	217	84	962	2008-11-30 00:00:00	11	7
1046	6	105	585	33	74	238	1449	347	35	1960	641	2253	1653	6684	2013-04-30 00:00:00	6	92
1047	6	127	522	39	68	255	1474	292	25	1866	769	2475	1481	6436	2013-05-31 00:00:00	6	71
1048	6	86	484	23	69	229	1415	256	23	1885	591	2205	1682	6256	2013-06-30 00:00:00	6	89
1049	6	59	442	23	71	214	1315	258	23	1649	648	2114	1768	5722	2013-07-31 00:00:00	6	86
1050	6	79	474	15	88	246	1400	240	27	1824	680	2257	1966	6642	2013-08-31 00:00:00	6	114
1051	6	88	374	22	94	240	1288	195	32	1742	649	2109	1751	5573	2013-09-30 00:00:00	6	119
1052	6	96	418	28	59	220	1346	258	38	1727	592	2132	1715	6063	2013-10-31 00:00:00	6	99
1053	6	104	449	18	62	262	1399	272	36	1838	832	2436	1879	5805	2013-11-30 00:00:00	6	83
1054	6	83	359	25	83	240	1351	217	32	1719	424	1899	1846	4996	2013-12-31 00:00:00	6	106
1057	6	87	348	19	110	277	1357	238	29	1658	556	1989	1807	5628	2014-03-31 00:00:00	6	97
547	4	183	103	9	131	275	535	80	9	686	172	713	797	1938	2002-01-31 00:00:00	4	64
549	4	161	109	5	107	226	410	84	12	576	244	617	660	1686	2002-03-31 00:00:00	4	67
550	4	152	83	8	93	201	437	88	15	571	238	673	761	1955	2002-04-30 00:00:00	4	84
551	4	173	79	5	106	246	408	71	4	597	310	704	738	1854	2002-05-31 00:00:00	4	63
552	4	128	89	6	102	189	334	78	0	423	258	596	592	1647	2002-06-30 00:00:00	4	62
553	4	141	82	6	80	223	373	57	3	493	216	596	631	1844	2002-07-31 00:00:00	4	51
555	4	160	69	8	99	190	273	29	10	367	293	547	677	1823	2002-09-30 00:00:00	4	59
556	4	162	88	6	105	255	320	41	3	425	203	518	721	2124	2002-10-31 00:00:00	4	82
557	4	169	101	12	104	250	372	57	2	501	193	556	698	1782	2002-11-30 00:00:00	4	63
558	4	139	78	14	98	211	321	38	2	437	247	563	734	1696	2002-12-31 00:00:00	4	68
559	4	164	89	11	90	236	344	35	40	511	214	556	786	1784	2003-01-31 00:00:00	4	66
561	4	261	110	9	115	242	399	64	48	551	221	542	756	1811	2003-03-31 00:00:00	4	90
562	4	183	113	5	108	220	388	49	10	558	190	575	659	2079	2003-04-30 00:00:00	4	84
563	4	183	104	2	118	264	369	78	3	519	227	562	787	2016	2003-05-31 00:00:00	4	64
564	4	184	106	5	92	209	367	58	10	528	234	592	654	1900	2003-06-30 00:00:00	4	78
565	4	207	98	6	103	244	363	66	36	475	257	605	646	1913	2003-07-31 00:00:00	4	53
566	4	163	127	10	97	223	364	64	16	521	228	585	740	1979	2003-08-31 00:00:00	4	58
567	4	179	106	7	110	262	400	59	13	534	250	630	811	2051	2003-09-30 00:00:00	4	66
568	4	166	148	4	98	247	430	64	9	604	282	682	766	2034	2003-10-31 00:00:00	4	76
569	4	152	91	6	86	188	344	43	13	444	177	518	716	1985	2003-11-30 00:00:00	4	73
570	4	127	104	1	93	230	359	47	15	494	153	512	721	1836	2003-12-31 00:00:00	4	70
571	4	139	129	6	96	250	421	57	15	602	172	595	720	1729	2004-01-31 00:00:00	4	62
573	4	159	98	4	94	252	441	57	23	621	270	712	720	2105	2004-03-31 00:00:00	4	67
574	4	179	93	2	118	273	420	61	12	571	247	663	738	1952	2004-04-30 00:00:00	4	49
575	4	151	108	2	74	197	403	32	41	530	178	615	736	1999	2004-05-31 00:00:00	4	77
576	4	161	104	4	85	195	392	70	9	523	247	623	722	2117	2004-06-30 00:00:00	4	56
577	4	137	111	3	67	192	381	63	12	518	235	611	770	1925	2004-07-31 00:00:00	4	42
578	4	185	141	1	98	219	429	63	18	581	179	598	794	2054	2004-08-31 00:00:00	4	54
579	4	136	91	3	68	177	367	42	35	502	173	534	705	1885	2004-09-30 00:00:00	4	60
580	4	175	121	6	81	178	403	54	14	532	160	562	811	1747	2004-10-31 00:00:00	4	64
1090	6	215	418	36	50	207	1433	340	26	1836	677	2226	1620	5188	2016-12-31 00:00:00	6	81
581	4	141	127	1	78	155	423	56	20	568	183	598	601	2013	2004-11-30 00:00:00	4	47
582	4	140	132	2	79	164	393	72	9	543	228	621	624	1992	2004-12-31 00:00:00	4	62
583	4	147	128	2	69	173	406	55	6	539	177	580	628	1803	2005-01-31 00:00:00	4	44
585	4	152	130	6	86	221	438	79	17	615	210	642	703	2048	2005-03-31 00:00:00	4	53
586	4	174	169	1	84	193	426	53	10	596	186	612	636	1868	2005-04-30 00:00:00	4	32
587	4	170	109	4	77	194	441	74	8	615	207	649	676	1952	2005-05-31 00:00:00	4	47
588	4	167	137	6	72	172	418	53	5	575	198	611	696	1945	2005-06-30 00:00:00	4	47
589	4	131	123	3	71	157	340	55	6	503	221	590	660	1917	2005-07-31 00:00:00	4	33
590	4	202	125	2	69	186	395	67	14	554	265	646	793	1988	2005-08-31 00:00:00	4	34
591	4	174	122	4	65	200	403	54	18	540	224	606	721	1756	2005-09-30 00:00:00	4	38
592	4	151	141	2	79	219	441	72	18	575	225	655	655	1580	2005-10-31 00:00:00	4	31
1185	7	246	213	21	48	162	474	60	19	593	351	770	362	1984	2009-09-30 00:00:00	7	27
1186	7	313	216	28	47	133	519	73	20	655	397	837	404	1883	2009-10-31 00:00:00	7	26
1187	7	296	206	24	38	131	504	60	18	638	342	771	390	1902	2009-11-30 00:00:00	7	26
1188	7	293	223	28	38	110	494	57	16	611	276	715	361	1931	2009-12-31 00:00:00	7	23
1197	7	380	237	31	39	102	468	82	18	545	209	671	356	2083	2010-09-30 00:00:00	7	17
1198	7	361	244	16	26	77	443	53	15	561	230	665	399	1952	2010-10-31 00:00:00	7	32
1199	7	336	235	17	43	90	412	70	11	519	290	658	432	1798	2010-11-30 00:00:00	7	27
1200	7	342	208	14	47	115	447	85	13	546	262	687	425	2093	2010-12-31 00:00:00	7	27
1209	7	334	246	45	42	122	480	113	17	624	310	837	630	2161	2011-09-30 00:00:00	7	17
1210	7	326	244	25	37	102	513	87	15	642	280	836	514	2140	2011-10-31 00:00:00	7	26
1211	7	342	304	28	41	103	487	95	21	601	272	802	528	2279	2011-11-30 00:00:00	7	23
1212	7	372	264	23	40	112	473	65	14	570	259	765	485	2114	2011-12-31 00:00:00	7	0
1221	7	394	314	29	43	91	520	69	27	657	369	879	460	2274	2012-09-30 00:00:00	7	25
1222	7	413	354	50	43	118	582	96	29	689	328	908	529	2489	2012-10-31 00:00:00	7	27
1223	7	370	352	38	50	104	581	94	37	703	365	981	477	2566	2012-11-30 00:00:00	7	30
1224	7	398	373	38	42	104	553	84	15	686	267	879	642	2291	2012-12-31 00:00:00	7	37
1233	7	448	379	28	48	90	630	117	29	759	266	936	615	2481	2013-09-30 00:00:00	7	25
1234	7	355	397	26	53	114	700	131	29	844	325	1063	651	2503	2013-10-31 00:00:00	7	32
1235	7	431	407	37	42	122	727	127	32	764	396	1087	585	2440	2013-11-30 00:00:00	7	39
1236	7	353	380	19	54	128	668	146	22	787	279	975	656	2374	2013-12-31 00:00:00	7	28
1246	7	284	400	33	46	100	615	129	28	754	290	934	555	2548	2014-10-31 00:00:00	7	27
1247	7	278	440	19	43	104	670	130	40	799	467	1164	544	2373	2014-11-30 00:00:00	7	18
1248	7	269	416	33	45	115	699	118	30	831	366	1105	571	2324	2014-12-31 00:00:00	7	29
593	4	190	128	1	72	268	358	80	16	483	240	595	635	1635	2005-11-30 00:00:00	4	31
594	4	171	117	7	62	166	361	57	14	467	194	554	596	1523	2005-12-31 00:00:00	4	35
595	4	191	108	7	67	193	365	60	19	486	230	589	637	1636	2006-01-31 00:00:00	4	23
597	4	149	133	9	92	192	466	67	30	597	292	732	764	1913	2006-03-31 00:00:00	4	36
598	4	193	126	2	61	150	405	48	18	544	240	633	685	1757	2006-04-30 00:00:00	4	34
599	4	146	133	0	71	187	415	74	17	588	233	642	676	1743	2006-05-31 00:00:00	4	47
1268	7	260	371	28	34	96	620	114	68	738	444	1113	488	2648	2016-08-31 00:00:00	7	22
1269	7	254	344	22	41	113	597	91	71	727	382	1019	546	2719	2016-09-30 00:00:00	7	23
1270	7	228	350	26	43	90	648	144	81	762	401	1096	484	2587	2016-10-31 00:00:00	7	28
1271	7	227	402	29	28	77	663	133	50	795	439	1125	531	2590	2016-11-30 00:00:00	7	27
600	4	125	109	5	55	148	385	60	22	492	229	608	632	1536	2006-06-30 00:00:00	4	34
2086	11	66	69	4	34	81	193	8	12	234	246	234	81	1164	2008-12-31 00:00:00	11	8
601	4	162	126	4	63	167	409	66	20	583	197	605	620	1574	2006-07-31 00:00:00	4	27
2087	11	63	72	2	41	52	199	11	16	260	259	235	106	945	2009-01-31 00:00:00	11	5
602	4	176	139	0	64	155	452	64	19	621	293	722	635	2845	2006-08-31 00:00:00	4	28
2088	11	96	112	21	42	44	246	24	3	308	235	295	85	1140	2009-02-28 00:00:00	11	10
603	4	165	141	0	55	128	369	71	15	470	187	557	578	1912	2006-09-30 00:00:00	4	27
2089	11	78	82	17	31	84	214	10	11	263	246	265	116	1280	2009-03-31 00:00:00	11	6
604	4	156	112	8	56	162	449	80	14	589	206	657	652	2098	2006-10-31 00:00:00	4	36
2091	11	88	91	13	36	48	217	19	11	266	236	278	98	1172	2009-05-31 00:00:00	11	10
605	4	172	115	8	48	135	370	72	11	455	248	613	565	1917	2006-11-30 00:00:00	4	24
2092	11	68	94	4	20	47	223	20	13	285	324	279	118	1319	2009-06-30 00:00:00	11	10
606	4	181	120	4	62	140	413	54	1	537	203	601	565	1830	2006-12-31 00:00:00	4	37
607	4	208	141	15	53	134	452	59	8	583	238	674	558	2018	2007-01-31 00:00:00	4	22
609	4	195	120	7	72	173	493	65	1	674	359	841	560	2369	2007-03-31 00:00:00	4	36
610	4	164	131	4	58	159	443	54	22	565	259	692	572	2182	2007-04-30 00:00:00	4	37
611	4	177	157	13	56	165	489	43	4	651	263	764	566	2611	2007-05-31 00:00:00	4	36
612	4	159	192	15	83	179	519	76	27	641	313	797	536	2537	2007-06-30 00:00:00	4	27
2093	11	96	104	2	26	42	218	22	15	291	260	257	135	1076	2009-07-31 00:00:00	11	9
2095	11	83	82	2	29	45	222	13	13	282	272	274	99	1249	2009-09-30 00:00:00	11	3
2096	11	111	94	3	28	45	213	18	7	274	350	287	78	1213	2009-10-31 00:00:00	11	9
2097	11	81	107	8	41	49	217	10	15	276	228	260	81	1230	2009-11-30 00:00:00	11	10
2098	11	88	95	3	30	43	216	8	11	276	217	258	102	1151	2009-12-31 00:00:00	11	10
2099	11	67	116	2	37	58	238	15	12	305	228	288	87	1128	2010-01-31 00:00:00	11	8
2100	11	76	130	5	31	44	272	21	8	340	239	351	103	1293	2010-02-28 00:00:00	11	10
2101	11	54	102	3	43	74	249	16	9	301	204	295	147	1272	2010-03-31 00:00:00	11	11
2102	11	54	99	4	22	34	210	15	6	266	276	247	114	1121	2010-04-30 00:00:00	11	5
2103	11	81	96	4	36	52	215	13	8	275	254	263	100	1304	2010-05-31 00:00:00	11	6
2104	11	89	93	3	27	32	196	3	3	241	175	242	126	1220	2010-06-30 00:00:00	11	4
2105	11	80	92	2	28	46	171	14	14	213	204	218	118	1125	2010-07-31 00:00:00	11	6
2106	11	87	125	4	23	52	222	20	5	282	238	289	88	1408	2010-08-31 00:00:00	11	9
2107	11	91	126	2	43	88	241	8	10	276	159	286	91	1220	2010-09-30 00:00:00	11	5
2108	11	99	123	8	25	42	208	18	5	272	177	273	88	1157	2010-10-31 00:00:00	11	12
2109	11	97	113	4	32	39	219	19	11	279	201	274	99	1089	2010-11-30 00:00:00	11	9
2110	11	94	116	3	34	39	229	15	15	286	181	309	74	1137	2010-12-31 00:00:00	11	16
2111	11	79	106	4	22	44	217	35	0	285	207	286	71	1037	2011-01-31 00:00:00	11	4
2112	11	89	128	6	29	68	246	28	7	310	229	304	88	1200	2011-02-28 00:00:00	11	5
2113	11	100	165	1	40	51	267	29	13	358	207	323	87	1275	2011-03-31 00:00:00	11	9
2114	11	102	120	4	58	68	245	29	1	336	241	328	88	1288	2011-04-30 00:00:00	11	10
2115	11	131	167	2	47	90	294	32	15	370	251	338	138	1404	2011-05-31 00:00:00	11	7
2116	11	91	170	6	27	35	267	34	14	333	221	337	97	1372	2011-06-30 00:00:00	11	4
2117	11	86	118	2	39	54	190	31	21	249	200	234	105	1160	2011-07-31 00:00:00	11	12
2118	11	115	139	4	32	46	270	35	14	330	257	369	109	1351	2011-08-31 00:00:00	11	8
2119	11	104	139	9	34	38	244	43	11	283	195	365	106	1406	2011-09-30 00:00:00	11	6
2120	11	103	127	4	32	39	224	43	6	301	228	350	126	1156	2011-10-31 00:00:00	11	7
2121	11	108	143	6	35	51	295	26	6	334	172	374	148	1223	2011-11-30 00:00:00	11	5
2122	11	102	112	6	31	33	232	16	9	277	173	335	190	1222	2011-12-31 00:00:00	11	10
2123	11	143	167	5	29	51	267	52	8	323	215	388	179	1273	2012-01-31 00:00:00	11	10
2125	11	125	147	3	29	50	283	43	22	335	198	405	136	1493	2012-03-31 00:00:00	11	9
2126	11	107	136	9	33	56	277	39	11	355	193	395	162	1565	2012-04-30 00:00:00	11	12
2127	11	137	196	11	36	65	333	43	23	417	259	473	186	1585	2012-05-31 00:00:00	11	6
2128	11	151	183	10	25	32	265	49	16	320	204	385	188	1432	2012-06-30 00:00:00	11	11
2129	11	99	195	9	33	70	282	46	10	354	208	413	129	1428	2012-07-31 00:00:00	11	7
2130	11	140	186	8	25	30	297	73	11	391	256	467	130	1565	2012-08-31 00:00:00	11	12
2131	11	134	182	4	26	34	280	36	16	357	228	424	122	1384	2012-09-30 00:00:00	11	10
2132	11	145	160	5	41	56	309	37	11	359	226	462	147	1541	2012-10-31 00:00:00	11	4
2133	11	116	171	2	35	42	261	22	11	320	183	379	192	1337	2012-11-30 00:00:00	11	5
2134	11	117	151	5	38	66	301	35	8	351	229	457	151	1329	2012-12-31 00:00:00	11	8
2135	11	114	192	7	22	34	334	46	14	418	190	458	147	1419	2013-01-31 00:00:00	11	11
2136	11	168	231	5	31	52	380	50	16	453	217	515	138	1363	2013-02-28 00:00:00	11	11
2137	11	156	203	12	29	41	377	60	9	454	208	502	180	1628	2013-03-31 00:00:00	11	8
2138	11	162	215	7	34	53	356	64	13	445	265	511	171	1713	2013-04-30 00:00:00	11	8
2139	11	142	239	9	31	48	342	73	10	419	300	533	149	1714	2013-05-31 00:00:00	11	3
2140	11	143	195	13	21	50	357	48	21	440	272	551	138	1654	2013-06-30 00:00:00	11	15
2141	11	83	166	8	35	99	302	48	13	355	214	440	159	1386	2013-07-31 00:00:00	11	6
2142	11	129	214	8	32	72	327	53	10	395	219	484	179	1634	2013-08-31 00:00:00	11	12
2143	11	138	170	5	21	38	260	38	11	289	215	440	166	1398	2013-09-30 00:00:00	11	11
2144	11	98	176	3	20	33	298	58	8	356	240	472	158	1468	2013-10-31 00:00:00	11	11
2145	11	103	162	8	28	46	326	57	13	402	241	523	171	1577	2013-11-30 00:00:00	11	11
2146	11	101	164	10	45	85	284	56	7	344	200	451	207	1260	2013-12-31 00:00:00	11	13
2147	11	102	150	6	28	42	266	56	5	328	176	418	169	1438	2014-01-31 00:00:00	11	6
2148	11	149	177	6	28	52	302	56	18	391	173	442	122	1459	2014-02-28 00:00:00	11	4
2149	11	144	207	5	45	58	329	72	17	400	264	530	144	1448	2014-03-31 00:00:00	11	7
2150	11	107	207	5	31	71	324	53	11	432	222	511	136	1602	2014-04-30 00:00:00	11	10
2151	11	103	204	12	24	53	295	85	17	365	220	463	110	1407	2014-05-31 00:00:00	11	5
2152	11	136	216	6	28	92	298	59	22	368	264	514	110	1415	2014-06-30 00:00:00	11	7
2153	11	154	227	6	28	46	284	91	17	368	311	522	126	1440	2014-07-31 00:00:00	11	3
2154	11	124	220	7	25	39	315	70	14	396	248	534	124	1498	2014-08-31 00:00:00	11	11
2155	11	127	229	7	27	45	293	86	9	344	274	537	126	1490	2014-09-30 00:00:00	11	10
2156	11	135	223	4	26	47	284	56	22	375	257	496	140	1680	2014-10-31 00:00:00	11	9
2157	11	125	175	5	26	57	302	60	14	364	311	560	93	1632	2014-11-30 00:00:00	11	11
2158	11	109	173	2	19	41	291	57	18	340	191	451	107	1441	2014-12-31 00:00:00	11	12
2160	11	147	201	5	25	52	287	75	18	357	303	537	95	1602	2015-02-28 00:00:00	11	6
2162	11	118	220	5	38	67	290	75	41	356	315	540	122	1503	2015-04-30 00:00:00	11	5
2171	11	87	191	1	42	66	289	55	16	361	189	462	116	1223	2016-01-31 00:00:00	11	5
2173	11	127	185	8	33	61	315	68	58	387	322	588	179	1603	2016-03-31 00:00:00	11	12
2174	11	117	177	11	25	47	290	62	26	356	259	511	137	1548	2016-04-30 00:00:00	11	6
2175	11	96	200	7	22	43	295	61	24	355	337	615	133	1515	2016-05-31 00:00:00	11	6
2176	11	126	203	6	26	53	298	73	33	391	376	589	145	1641	2016-06-30 00:00:00	11	11
2182	11	80	128	5	26	57	266	30	22	320	246	482	139	1323	2016-12-31 00:00:00	11	7
2183	11	104	159	5	16	30	272	31	24	324	270	521	145	1263	2017-01-31 00:00:00	11	12
2184	11	124	182	5	39	60	284	35	44	361	292	551	127	1369	2017-02-28 00:00:00	11	8
2302	13	140	261	19	37	103	506	79	21	609	302	789	197	1935	2011-10-31 00:00:00	13	22
2303	13	185	259	14	46	101	522	77	15	636	307	808	177	1923	2011-11-30 00:00:00	13	22
2304	13	182	211	6	30	97	466	68	10	534	269	691	170	1681	2011-12-31 00:00:00	13	31
2305	13	191	283	16	48	116	550	66	13	675	272	795	207	1956	2012-01-31 00:00:00	13	17
2307	13	193	284	40	47	103	595	87	17	718	315	904	224	2580	2012-03-31 00:00:00	13	37
2308	13	175	262	34	50	114	610	77	23	729	319	902	220	2346	2012-04-30 00:00:00	13	30
2309	13	205	362	24	60	125	623	100	22	745	425	972	277	2373	2012-05-31 00:00:00	13	16
2310	13	160	277	15	39	96	571	74	20	694	318	862	199	2229	2012-06-30 00:00:00	13	22
2311	13	160	273	19	35	90	556	81	19	690	334	833	216	2039	2012-07-31 00:00:00	13	22
2317	13	218	355	36	43	102	731	80	11	868	275	995	218	2262	2013-01-31 00:00:00	13	22
2318	13	205	344	20	36	103	749	57	11	889	363	1054	231	2411	2013-02-28 00:00:00	13	26
2319	13	225	333	21	43	190	727	56	23	856	281	999	240	2500	2013-03-31 00:00:00	13	18
2320	13	229	348	17	53	114	825	59	18	939	342	1133	311	2856	2013-04-30 00:00:00	13	21
2321	13	197	345	14	52	129	729	55	31	838	472	1117	235	2625	2013-05-31 00:00:00	13	25
2322	13	180	337	11	40	89	767	55	12	895	373	1081	215	2311	2013-06-30 00:00:00	13	18
2323	13	139	310	12	32	89	677	84	20	798	276	943	269	2107	2013-07-31 00:00:00	13	16
2328	13	153	268	12	34	75	644	49	14	723	270	868	204	2002	2013-12-31 00:00:00	13	15
2329	13	191	304	27	39	110	698	46	14	792	288	929	295	2247	2014-01-31 00:00:00	13	20
2330	13	206	332	21	32	79	701	78	31	839	336	1007	296	2444	2014-02-28 00:00:00	13	22
2331	13	186	315	10	37	90	762	90	31	875	289	1052	281	2468	2014-03-31 00:00:00	13	33
2332	13	174	340	10	44	100	731	62	38	850	374	1044	289	2369	2014-04-30 00:00:00	13	37
2333	13	183	285	10	28	79	667	64	42	802	315	978	260	2275	2014-05-31 00:00:00	13	20
2334	13	154	221	20	36	81	699	59	49	795	350	1033	241	2212	2014-06-30 00:00:00	13	13
2335	13	149	282	24	30	102	705	91	25	791	398	1064	220	2306	2014-07-31 00:00:00	13	21
2336	13	200	326	20	30	78	701	87	38	833	385	1084	227	2311	2014-08-31 00:00:00	13	17
2337	13	216	324	18	36	117	718	78	47	810	461	1151	249	2326	2014-09-30 00:00:00	13	28
2338	13	189	327	17	38	112	670	91	38	799	320	1026	230	2483	2014-10-31 00:00:00	13	19
2339	13	201	276	21	31	112	650	71	39	767	359	1024	239	2184	2014-11-30 00:00:00	13	22
2340	13	159	254	13	38	177	639	72	43	700	296	916	206	1992	2014-12-31 00:00:00	13	28
2342	13	245	341	25	48	100	705	52	34	813	485	1150	217	2253	2015-02-28 00:00:00	13	19
2347	13	222	380	27	48	121	736	96	42	851	442	1205	239	2287	2015-07-31 00:00:00	13	17
2353	13	232	331	27	39	100	697	114	28	832	387	1089	225	1902	2016-01-31 00:00:00	13	17
2355	13	225	320	39	54	127	733	101	63	873	525	1254	239	2611	2016-03-31 00:00:00	13	9
2356	13	202	360	32	37	82	709	88	49	859	453	1191	229	2495	2016-04-30 00:00:00	13	19
2357	13	200	317	25	44	119	688	91	26	807	664	1378	239	2264	2016-05-31 00:00:00	13	18
2359	13	146	317	24	35	119	626	106	59	779	617	1259	242	2127	2016-07-31 00:00:00	13	21
2360	13	192	295	31	38	100	645	84	48	765	715	1349	226	2350	2016-08-31 00:00:00	13	18
2361	13	197	296	19	40	90	687	96	46	811	764	1442	196	2434	2016-09-30 00:00:00	13	14
2362	13	191	276	16	32	88	708	85	65	824	768	1433	238	2403	2016-10-31 00:00:00	13	20
2363	13	202	366	21	27	101	665	102	37	802	641	1285	230	2210	2016-11-30 00:00:00	13	25
2364	13	171	279	20	32	93	666	97	25	804	586	1283	212	2164	2016-12-31 00:00:00	13	17
1639	10	270	86	28	71	180	496	114	17	545	146	591	287	1722	2002-01-31 00:00:00	10	68
1641	10	197	69	30	81	164	287	106	12	356	162	432	196	1330	2002-03-31 00:00:00	10	95
1642	10	174	106	14	100	210	351	97	4	417	187	538	226	1650	2002-04-30 00:00:00	10	68
1643	10	168	74	19	104	188	289	64	7	345	183	453	209	1649	2002-05-31 00:00:00	10	77
1644	10	152	81	13	87	180	245	63	6	314	170	401	231	1537	2002-06-30 00:00:00	10	58
1645	10	174	85	15	86	148	247	45	14	293	168	407	183	1609	2002-07-31 00:00:00	10	64
1651	10	292	133	25	89	189	376	127	13	443	212	557	320	1842	2003-01-31 00:00:00	10	57
1653	10	200	76	24	83	171	361	102	7	435	182	508	283	1600	2003-03-31 00:00:00	10	61
1654	10	219	122	10	73	155	340	68	31	409	209	516	241	1884	2003-04-30 00:00:00	10	68
1655	10	204	85	9	95	223	332	101	20	433	199	501	255	1852	2003-05-31 00:00:00	10	46
1656	10	163	100	13	89	167	291	69	12	369	168	429	272	1824	2003-06-30 00:00:00	10	43
1663	10	218	99	23	72	180	454	80	7	552	205	635	282	1650	2004-01-31 00:00:00	10	37
1665	10	121	49	22	60	168	286	76	29	348	185	445	182	1566	2004-03-31 00:00:00	10	44
1666	10	141	76	15	61	152	339	39	16	389	218	522	255	1368	2004-04-30 00:00:00	10	24
1668	10	209	98	19	72	155	362	33	30	413	250	546	229	1594	2004-06-30 00:00:00	10	29
1669	10	165	73	19	62	125	333	40	32	389	210	512	193	1508	2004-07-31 00:00:00	10	32
1670	10	183	105	12	75	180	345	25	9	392	191	489	180	1540	2004-08-31 00:00:00	10	31
1672	10	195	122	19	91	172	388	39	20	490	151	507	218	1674	2004-10-31 00:00:00	10	27
1673	10	159	107	12	68	128	374	36	29	476	222	564	226	1483	2004-11-30 00:00:00	10	36
1674	10	198	90	13	67	138	345	37	10	444	238	554	217	1599	2004-12-31 00:00:00	10	30
1675	10	259	90	17	74	184	417	44	28	511	251	641	289	1594	2005-01-31 00:00:00	10	35
613	4	153	152	18	38	125	432	57	11	557	196	628	497	2239	2007-07-31 00:00:00	4	31
1677	10	136	80	14	44	116	306	45	8	360	202	460	263	1524	2005-03-31 00:00:00	10	33
1678	10	120	82	20	58	162	350	46	24	435	194	526	248	1507	2005-04-30 00:00:00	10	33
614	4	141	190	5	63	153	570	99	7	662	323	844	507	2769	2007-08-31 00:00:00	4	27
1679	10	163	86	19	55	123	323	46	32	388	212	521	217	1525	2005-05-31 00:00:00	10	26
616	4	189	196	6	55	150	490	83	4	625	253	723	535	2794	2007-10-31 00:00:00	4	27
1680	10	141	93	17	50	162	286	36	33	354	249	514	233	1527	2005-06-30 00:00:00	10	24
1681	10	137	57	11	56	131	314	36	48	391	286	551	283	1329	2005-07-31 00:00:00	10	24
617	4	249	240	13	53	138	556	85	31	725	461	1011	534	2213	2007-11-30 00:00:00	4	36
1682	10	188	91	11	57	129	384	56	14	484	225	582	233	1503	2005-08-31 00:00:00	10	35
1683	10	174	86	26	73	154	331	47	40	430	235	539	198	1459	2005-09-30 00:00:00	10	10
618	4	172	209	11	40	134	463	82	22	611	306	751	444	2034	2007-12-31 00:00:00	4	32
1684	10	164	100	29	56	146	339	37	27	430	180	505	218	1211	2005-10-31 00:00:00	10	13
1685	10	166	96	14	46	127	366	42	21	451	224	575	260	1261	2005-11-30 00:00:00	10	28
619	4	156	191	5	50	127	460	77	6	612	240	737	519	1963	2008-01-31 00:00:00	4	24
621	4	207	196	16	50	128	477	101	7	661	281	822	520	1996	2008-03-31 00:00:00	4	25
1686	10	187	115	28	41	98	344	51	17	406	190	516	258	1182	2005-12-31 00:00:00	10	28
1687	10	321	127	47	51	143	393	86	17	489	268	638	302	1457	2006-01-31 00:00:00	10	22
1689	10	183	104	21	65	134	345	34	21	431	284	602	239	1381	2006-03-31 00:00:00	10	14
1690	10	165	115	25	45	125	334	46	20	434	243	554	237	1165	2006-04-30 00:00:00	10	12
1646	10	224	103	17	89	165	301	55	18	380	234	516	174	1677	2002-08-31 00:00:00	10	46
623	4	189	193	9	50	114	487	49	6	629	270	751	533	1860	2008-05-31 00:00:00	4	26
1647	10	213	103	13	82	169	288	58	11	338	181	470	179	1597	2002-09-30 00:00:00	10	74
1648	10	222	112	15	98	182	319	79	25	350	151	466	200	1750	2002-10-31 00:00:00	10	59
624	4	197	228	6	37	118	518	100	12	699	314	822	503	2066	2008-06-30 00:00:00	4	33
1649	10	201	108	8	80	129	307	91	14	369	187	473	175	1568	2002-11-30 00:00:00	10	74
1650	10	228	81	23	71	119	293	80	9	346	155	455	247	1614	2002-12-31 00:00:00	10	77
625	4	179	174	1	31	108	489	44	12	608	267	744	481	2024	2008-07-31 00:00:00	4	30
1657	10	167	109	18	67	205	307	86	15	396	196	474	275	1868	2003-07-31 00:00:00	10	48
1658	10	163	116	6	80	193	335	74	20	419	215	517	235	1701	2003-08-31 00:00:00	10	36
626	4	183	212	8	34	294	464	69	9	602	279	744	553	1935	2008-08-31 00:00:00	4	15
1659	10	159	97	6	81	197	292	97	18	356	199	475	220	1959	2003-09-30 00:00:00	10	55
1660	10	179	116	6	95	194	367	74	19	461	266	602	322	1800	2003-10-31 00:00:00	10	37
627	4	159	158	5	39	117	437	71	18	576	211	646	464	1995	2008-09-30 00:00:00	4	24
628	4	165	129	13	38	131	422	37	4	556	191	615	513	1822	2008-10-31 00:00:00	4	41
1661	10	105	68	7	46	145	299	87	12	379	226	498	199	1677	2003-11-30 00:00:00	10	44
1662	10	171	72	12	57	155	305	95	8	389	192	480	255	1458	2003-12-31 00:00:00	10	51
629	4	169	153	17	27	97	413	49	16	552	278	683	566	1712	2008-11-30 00:00:00	4	39
630	4	169	141	2	44	160	496	65	13	630	328	835	545	1973	2008-12-31 00:00:00	4	29
1093	7	165	61	18	108	219	425	32	4	528	197	589	405	1557	2002-01-31 00:00:00	7	38
1095	7	140	67	18	92	192	400	38	5	513	297	628	372	1721	2002-03-31 00:00:00	7	53
1096	7	140	86	13	102	218	413	49	9	521	328	616	370	1844	2002-04-30 00:00:00	7	61
1097	7	146	80	8	126	222	426	25	11	563	326	623	383	1824	2002-05-31 00:00:00	7	49
1098	7	135	53	15	86	184	339	51	6	444	238	485	381	1600	2002-06-30 00:00:00	7	52
1099	7	132	44	9	84	191	343	30	6	439	311	502	307	1515	2002-07-31 00:00:00	7	51
631	4	173	209	17	48	140	616	54	5	782	320	956	667	1835	2009-01-31 00:00:00	4	26
1100	7	193	76	18	106	221	354	42	8	461	295	575	349	1780	2002-08-31 00:00:00	7	39
1101	7	156	72	13	84	170	334	35	9	417	298	486	329	1672	2002-09-30 00:00:00	7	46
1102	7	145	84	12	94	207	376	31	9	499	225	509	366	1812	2002-10-31 00:00:00	7	63
1103	7	157	70	10	96	215	360	27	8	488	302	560	329	1720	2002-11-30 00:00:00	7	47
633	4	193	225	12	54	160	607	79	9	801	353	966	815	2478	2009-03-31 00:00:00	4	31
1104	7	164	67	8	96	193	381	20	5	500	233	519	393	1708	2002-12-31 00:00:00	7	52
1105	7	159	83	11	88	172	414	24	10	529	226	528	311	1616	2003-01-31 00:00:00	7	37
1107	7	190	93	20	120	211	377	30	21	513	219	530	337	1891	2003-03-31 00:00:00	7	59
1109	7	202	93	23	111	233	420	34	17	574	294	603	372	2054	2003-05-31 00:00:00	7	38
1110	7	155	71	17	101	206	419	22	14	572	252	608	388	1897	2003-06-30 00:00:00	7	28
634	4	143	175	12	38	127	560	61	12	735	253	819	700	2219	2009-04-30 00:00:00	4	37
1111	7	196	84	9	87	198	349	25	32	442	290	493	366	1944	2003-07-31 00:00:00	7	33
1113	7	201	79	11	96	207	359	66	21	474	297	580	376	2143	2003-09-30 00:00:00	7	54
1114	7	208	101	14	91	200	363	45	17	492	300	578	340	1945	2003-10-31 00:00:00	7	40
1115	7	181	70	14	81	186	358	37	16	499	243	558	339	1666	2003-11-30 00:00:00	7	38
1116	7	196	81	6	91	202	357	38	13	482	274	548	337	1784	2003-12-31 00:00:00	7	56
635	4	171	169	6	52	146	539	67	16	729	283	905	695	2324	2009-05-31 00:00:00	4	29
1117	7	155	76	6	102	176	371	27	5	495	187	484	309	1662	2004-01-31 00:00:00	7	48
1119	7	183	113	13	90	237	404	21	18	541	300	581	371	2093	2004-03-31 00:00:00	7	42
1120	7	215	85	11	80	167	378	35	12	535	288	543	341	1945	2004-04-30 00:00:00	7	47
1121	7	167	87	22	84	161	384	36	18	510	311	577	380	1761	2004-05-31 00:00:00	7	51
1122	7	182	95	16	74	186	399	33	16	557	299	605	369	1843	2004-06-30 00:00:00	7	45
636	4	163	209	5	50	138	559	82	9	725	285	829	640	2123	2009-06-30 00:00:00	4	26
1123	7	171	87	23	66	145	313	15	13	392	227	449	350	1494	2004-07-31 00:00:00	7	41
1124	7	186	97	14	70	156	385	49	27	493	211	504	442	1864	2004-08-31 00:00:00	7	47
1125	7	175	85	20	84	220	361	34	12	509	178	469	431	1632	2004-09-30 00:00:00	7	45
1126	7	177	87	15	67	184	391	33	16	526	232	506	434	1713	2004-10-31 00:00:00	7	37
637	4	153	245	4	49	123	551	83	13	713	281	815	718	2053	2009-07-31 00:00:00	4	29
1127	7	151	93	20	55	195	363	34	18	479	194	454	399	1725	2004-11-30 00:00:00	7	38
1128	7	177	79	23	61	222	339	45	23	459	226	510	387	1662	2004-12-31 00:00:00	7	35
1129	7	172	86	14	80	177	404	38	13	521	227	519	457	1526	2005-01-31 00:00:00	7	43
1131	7	204	114	24	95	218	442	49	7	577	265	575	401	1769	2005-03-31 00:00:00	7	38
638	4	159	232	17	39	141	569	81	14	749	299	865	679	2368	2009-08-31 00:00:00	4	37
1132	7	182	103	7	72	161	406	29	10	535	281	569	401	1646	2005-04-30 00:00:00	7	32
1133	7	161	138	21	88	183	406	36	20	533	311	584	463	1781	2005-05-31 00:00:00	7	31
1134	7	214	116	14	70	178	375	30	20	488	327	558	392	1819	2005-06-30 00:00:00	7	35
1135	7	158	116	14	67	142	386	15	39	467	299	517	374	1429	2005-07-31 00:00:00	7	31
1136	7	242	157	36	89	168	457	29	21	604	286	592	417	1906	2005-08-31 00:00:00	7	36
639	4	187	244	10	36	158	557	118	4	743	376	914	609	2092	2009-09-30 00:00:00	4	31
1137	7	196	141	24	81	170	379	34	14	498	332	567	342	1847	2005-09-30 00:00:00	7	39
1138	7	212	108	18	82	204	388	30	7	527	290	566	353	1588	2005-10-31 00:00:00	7	39
1139	7	188	115	43	64	144	369	48	4	473	300	567	368	1611	2005-11-30 00:00:00	7	31
1140	7	181	137	21	69	194	362	48	14	481	251	525	358	1482	2005-12-31 00:00:00	7	37
1141	7	210	107	23	76	152	332	21	7	430	303	514	339	1376	2006-01-31 00:00:00	7	33
640	4	199	274	4	36	110	610	95	7	774	487	1068	617	2175	2009-10-31 00:00:00	4	34
1143	7	185	132	17	62	179	419	55	10	549	297	585	380	1887	2006-03-31 00:00:00	7	23
1144	7	202	131	18	70	152	403	36	7	560	302	610	360	1500	2006-04-30 00:00:00	7	23
1145	7	230	96	25	56	163	339	41	16	467	253	535	332	1688	2006-05-31 00:00:00	7	38
1146	7	186	129	19	60	109	345	40	9	458	283	524	349	1591	2006-06-30 00:00:00	7	36
1147	7	220	140	18	60	133	339	47	9	451	307	522	366	1470	2006-07-31 00:00:00	7	26
1148	7	215	160	23	66	164	431	70	24	588	366	651	440	1871	2006-08-31 00:00:00	7	21
1149	7	209	137	26	48	124	368	62	20	465	261	540	381	1611	2006-09-30 00:00:00	7	26
1821	12	132	85	56	76	179	423	34	0	491	157	519	167	1610	2002-01-31 00:00:00	12	39
1823	12	128	68	33	77	166	374	30	3	501	200	543	195	1850	2002-03-31 00:00:00	12	46
1824	12	89	82	57	67	154	356	21	5	459	219	536	193	1979	2002-04-30 00:00:00	12	53
641	4	139	224	10	35	126	528	86	9	668	198	737	530	2126	2009-11-30 00:00:00	4	28
642	4	154	211	8	28	132	499	65	4	658	239	746	574	2135	2009-12-31 00:00:00	4	25
643	4	183	251	9	34	135	539	69	9	699	218	762	607	2064	2010-01-31 00:00:00	4	26
645	4	175	240	18	38	116	609	92	8	812	329	929	699	2252	2010-03-31 00:00:00	4	33
646	4	126	259	14	42	145	569	75	10	751	314	885	577	2177	2010-04-30 00:00:00	4	38
647	4	137	229	15	36	131	563	103	8	703	341	888	605	2126	2010-05-31 00:00:00	4	40
648	4	129	216	23	35	110	489	72	9	635	275	766	551	1963	2010-06-30 00:00:00	4	25
649	4	130	224	11	28	90	500	88	12	647	258	756	598	1960	2010-07-31 00:00:00	4	31
650	4	174	241	13	41	117	529	81	12	686	324	851	572	2162	2010-08-31 00:00:00	4	28
651	4	149	240	29	31	97	464	84	7	540	228	710	548	2047	2010-09-30 00:00:00	4	29
652	4	145	251	10	37	132	525	84	5	684	261	797	521	2051	2010-10-31 00:00:00	4	27
653	4	147	249	17	30	122	548	89	12	682	238	798	557	2173	2010-11-30 00:00:00	4	29
654	4	179	247	31	35	119	523	87	40	663	223	768	559	2000	2010-12-31 00:00:00	4	25
655	4	219	272	13	45	107	557	96	12	690	293	848	549	1977	2011-01-31 00:00:00	4	18
657	4	230	266	39	43	136	548	84	15	711	308	865	611	2352	2011-03-31 00:00:00	4	20
658	4	235	274	34	27	86	521	88	10	637	264	812	583	2098	2011-04-30 00:00:00	4	24
659	4	210	292	38	44	125	578	97	13	732	336	899	616	2400	2011-05-31 00:00:00	4	19
660	4	160	259	29	48	159	591	71	21	718	312	912	620	2296	2011-06-30 00:00:00	4	19
661	4	168	295	31	32	122	573	95	18	746	282	858	496	2192	2011-07-31 00:00:00	4	34
662	4	164	304	35	57	163	688	105	21	798	366	1016	563	2494	2011-08-31 00:00:00	4	26
663	4	227	283	33	43	132	607	86	33	783	381	1008	590	2250	2011-09-30 00:00:00	4	37
664	4	222	259	24	33	99	592	94	26	715	325	911	584	2120	2011-10-31 00:00:00	4	35
665	4	165	265	33	33	109	561	89	14	677	237	805	528	1980	2011-11-30 00:00:00	4	37
666	4	248	319	22	36	116	585	95	11	751	323	925	489	2129	2011-12-31 00:00:00	4	28
667	4	249	316	32	39	116	643	90	7	806	280	924	490	2239	2012-01-31 00:00:00	4	31
669	4	249	340	46	37	119	628	89	19	797	315	932	654	2534	2012-03-31 00:00:00	4	40
670	4	221	305	21	56	140	638	79	20	787	342	1000	626	2379	2012-04-30 00:00:00	4	26
671	4	228	339	22	37	97	658	129	22	829	398	1062	732	2589	2012-05-31 00:00:00	4	18
672	4	205	326	33	38	110	614	104	36	766	444	1051	553	2417	2012-06-30 00:00:00	4	22
673	4	170	259	19	37	83	511	74	23	653	283	796	564	2236	2012-07-31 00:00:00	4	19
674	4	241	290	35	43	101	638	92	37	805	385	1059	636	2837	2012-08-31 00:00:00	4	39
675	4	216	298	29	39	118	679	83	24	867	376	1069	629	2758	2012-09-30 00:00:00	4	32
676	4	217	288	33	44	134	635	97	21	788	273	923	648	2678	2012-10-31 00:00:00	4	27
677	4	199	315	44	55	126	621	111	13	794	367	1002	671	2400	2012-11-30 00:00:00	4	25
678	4	216	282	31	36	95	642	59	21	776	316	966	643	2467	2012-12-31 00:00:00	4	44
679	4	260	316	51	53	124	707	93	17	860	227	948	729	2403	2013-01-31 00:00:00	4	34
681	4	304	321	40	48	120	737	119	31	918	259	1006	677	2496	2013-03-31 00:00:00	4	30
682	4	300	369	35	59	192	803	123	15	1022	293	1113	639	2614	2013-04-30 00:00:00	4	23
683	4	242	342	45	51	133	742	102	18	937	415	1175	676	2494	2013-05-31 00:00:00	4	26
684	4	229	335	31	45	113	712	113	22	866	306	1042	678	2652	2013-06-30 00:00:00	4	22
685	4	204	287	31	39	113	600	109	21	731	241	851	682	2214	2013-07-31 00:00:00	4	27
686	4	227	320	42	52	119	653	120	32	805	359	1027	670	2601	2013-08-31 00:00:00	4	32
688	4	221	291	27	50	123	647	132	23	837	266	936	652	2603	2013-10-31 00:00:00	4	26
689	4	200	313	29	37	140	699	107	30	867	320	1026	593	2376	2013-11-30 00:00:00	4	21
690	4	164	243	24	52	140	684	107	12	831	272	970	529	2355	2013-12-31 00:00:00	4	43
691	4	170	250	20	44	102	691	96	12	827	279	957	723	2763	2014-01-31 00:00:00	4	50
693	4	220	323	31	39	102	717	106	17	865	248	977	640	2739	2014-03-31 00:00:00	4	29
695	4	194	331	32	48	129	746	111	23	892	444	1197	700	2450	2014-05-31 00:00:00	4	30
696	4	159	328	27	51	110	776	103	19	910	363	1131	617	2781	2014-06-30 00:00:00	4	21
697	4	202	367	27	47	135	748	108	26	924	390	1129	602	2748	2014-07-31 00:00:00	4	25
698	4	253	361	34	37	124	709	106	30	818	372	1045	598	2627	2014-08-31 00:00:00	4	14
699	4	212	360	32	47	121	718	96	22	889	368	1101	565	2740	2014-09-30 00:00:00	4	24
700	4	200	355	43	39	128	696	131	34	847	307	1027	521	2840	2014-10-31 00:00:00	4	35
1832	12	108	66	25	77	156	371	43	6	454	226	542	216	2076	2002-12-31 00:00:00	12	62
701	4	207	281	39	41	113	667	104	21	788	367	1055	514	2656	2014-11-30 00:00:00	4	35
702	4	161	300	32	40	115	659	101	15	796	262	923	498	2556	2014-12-31 00:00:00	4	33
717	4	247	364	40	52	113	819	130	38	988	402	1240	604	2759	2016-03-31 00:00:00	4	22
718	4	225	309	51	46	122	743	128	47	931	347	1100	506	2504	2016-04-30 00:00:00	4	20
719	4	213	315	46	49	130	727	126	47	882	356	1091	458	2409	2016-05-31 00:00:00	4	19
720	4	226	359	38	53	141	707	152	54	848	362	1097	517	2871	2016-06-30 00:00:00	4	13
721	4	179	294	56	49	121	669	96	47	808	345	1030	462	2202	2016-07-31 00:00:00	4	23
722	4	211	321	35	31	71	726	119	42	887	407	1154	496	2761	2016-08-31 00:00:00	4	25
723	4	178	274	41	36	94	670	109	29	813	317	1006	520	2599	2016-09-30 00:00:00	4	14
726	4	191	302	43	45	123	729	136	22	877	304	1002	478	2923	2016-12-31 00:00:00	4	28
727	4	187	331	29	39	110	679	105	24	835	359	1039	521	2423	2017-01-31 00:00:00	4	31
1457	9	282	132	5	127	233	535	61	3	628	226	553	157	2004	2002-01-31 00:00:00	9	39
1459	9	260	123	4	151	218	476	81	15	652	359	489	171	2240	2002-03-31 00:00:00	9	49
1460	9	259	122	17	184	253	448	82	15	589	400	462	177	2428	2002-04-30 00:00:00	9	52
1461	9	222	150	7	151	240	463	65	22	605	376	483	164	2419	2002-05-31 00:00:00	9	35
1462	9	243	111	6	122	186	399	57	8	520	333	407	162	2285	2002-06-30 00:00:00	9	45
1463	9	271	148	5	152	236	457	74	14	589	334	471	179	2201	2002-07-31 00:00:00	9	43
1465	9	256	130	10	139	205	388	73	13	499	398	398	172	2224	2002-09-30 00:00:00	9	30
1466	9	248	124	7	118	309	383	69	15	493	305	387	225	2435	2002-10-31 00:00:00	9	39
1467	9	258	111	5	133	208	385	56	14	512	358	393	183	2095	2002-11-30 00:00:00	9	30
1468	9	230	96	9	130	184	371	62	10	500	311	377	198	2347	2002-12-31 00:00:00	9	40
1469	9	253	111	23	146	245	423	80	2	564	270	437	193	1992	2003-01-31 00:00:00	9	36
1471	9	251	127	7	148	241	466	67	12	642	399	476	192	2462	2003-03-31 00:00:00	9	42
1472	9	272	124	4	146	239	445	92	17	552	432	449	185	2405	2003-04-30 00:00:00	9	41
1473	9	235	149	6	128	235	457	67	11	612	431	473	202	2444	2003-05-31 00:00:00	9	39
1474	9	250	130	6	164	224	444	57	7	578	345	456	195	2558	2003-06-30 00:00:00	9	18
1475	9	253	142	9	145	210	376	70	20	503	369	390	196	2460	2003-07-31 00:00:00	9	17
1476	9	297	145	6	122	199	444	69	9	585	402	459	204	2521	2003-08-31 00:00:00	9	28
1477	9	267	148	11	138	284	456	70	17	598	448	469	226	2630	2003-09-30 00:00:00	9	21
1478	9	294	175	5	140	467	434	82	13	571	377	440	196	2563	2003-10-31 00:00:00	9	26
1479	9	320	158	8	113	225	412	88	10	525	307	422	205	2361	2003-11-30 00:00:00	9	35
1480	9	265	110	5	152	235	418	106	16	540	268	441	240	2131	2003-12-31 00:00:00	9	25
1481	9	246	132	6	122	224	480	127	8	624	262	494	208	1848	2004-01-31 00:00:00	9	25
1483	9	295	103	7	128	228	462	204	11	601	385	468	256	2396	2004-03-31 00:00:00	9	29
1484	9	305	122	8	108	229	450	219	18	593	364	473	217	2269	2004-04-30 00:00:00	9	29
1485	9	266	142	10	121	235	468	292	16	648	390	474	250	2446	2004-05-31 00:00:00	9	24
1486	9	265	110	11	109	198	440	294	20	598	331	446	219	2236	2004-06-30 00:00:00	9	19
1487	9	264	130	11	109	171	409	217	6	527	254	413	227	1917	2004-07-31 00:00:00	9	31
1488	9	299	140	7	123	190	468	259	5	631	233	475	221	1917	2004-08-31 00:00:00	9	34
1489	9	283	121	6	123	213	431	280	5	567	209	466	238	1914	2004-09-30 00:00:00	9	35
1490	9	272	129	14	108	199	451	258	5	590	232	458	243	2197	2004-10-31 00:00:00	9	35
1491	9	298	122	2	96	193	423	228	9	536	321	434	225	2009	2004-11-30 00:00:00	9	17
1492	9	222	95	9	94	169	411	210	3	514	298	421	258	2265	2004-12-31 00:00:00	9	32
1493	9	246	132	5	84	163	462	218	15	605	246	519	208	1849	2005-01-31 00:00:00	9	38
1495	9	288	172	14	100	195	494	226	8	639	385	516	253	2321	2005-03-31 00:00:00	9	38
1496	9	245	139	12	99	195	477	208	13	607	316	498	256	2283	2005-04-30 00:00:00	9	29
1497	9	265	163	18	77	162	431	272	5	554	388	442	227	2092	2005-05-31 00:00:00	9	19
1498	9	309	158	21	81	167	442	264	6	596	387	463	249	2276	2005-06-30 00:00:00	9	24
1499	9	256	139	10	83	174	411	197	8	511	375	423	227	2059	2005-07-31 00:00:00	9	28
1500	9	296	156	12	69	179	491	300	15	633	404	512	241	2221	2005-08-31 00:00:00	9	28
1501	9	332	173	24	82	162	481	366	13	627	377	491	240	2012	2005-09-30 00:00:00	9	24
1502	9	287	150	25	73	135	441	320	19	571	314	457	262	1838	2005-10-31 00:00:00	9	32
1503	9	296	148	24	86	182	478	314	8	613	400	511	262	1945	2005-11-30 00:00:00	9	26
1504	9	288	146	22	79	185	467	246	10	607	322	479	288	1899	2005-12-31 00:00:00	9	32
1505	9	308	166	22	80	162	479	206	16	633	370	497	284	1774	2006-01-31 00:00:00	9	21
1150	7	200	133	30	58	148	429	40	20	558	270	601	377	1942	2006-10-31 00:00:00	7	25
1151	7	194	129	34	68	130	434	42	15	558	287	653	331	1729	2006-11-30 00:00:00	7	30
1152	7	193	134	25	57	144	443	44	9	542	260	621	280	1826	2006-12-31 00:00:00	7	30
1153	7	222	144	26	65	138	406	49	8	509	329	627	301	1659	2007-01-31 00:00:00	7	17
1154	7	303	137	36	51	154	408	43	16	521	312	620	317	1843	2007-02-28 00:00:00	7	24
1155	7	265	172	33	55	137	450	53	25	620	419	729	366	1939	2007-03-31 00:00:00	7	25
1156	7	237	164	30	55	150	433	86	21	560	329	626	376	1783	2007-04-30 00:00:00	7	20
1157	7	248	178	32	56	157	440	83	19	563	351	681	426	2009	2007-05-31 00:00:00	7	28
1158	7	233	155	57	42	164	416	73	13	488	421	677	363	1729	2007-06-30 00:00:00	7	26
1159	7	212	142	40	47	117	391	52	11	515	339	621	348	1781	2007-07-31 00:00:00	7	21
1890	12	99	148	38	42	101	389	91	16	535	286	675	185	1744	2007-10-31 00:00:00	12	28
1891	12	92	142	33	49	90	375	80	9	460	335	710	193	1706	2007-11-30 00:00:00	12	22
1892	12	84	128	14	36	78	376	80	8	493	234	610	180	1787	2007-12-31 00:00:00	12	24
1902	12	70	105	37	24	72	344	53	2	414	164	508	174	1250	2008-10-31 00:00:00	12	29
1903	12	74	152	34	38	70	393	48	2	534	206	599	237	1558	2008-11-30 00:00:00	12	28
1904	12	86	130	27	32	85	392	46	7	500	200	592	248	1695	2008-12-31 00:00:00	12	23
1914	12	120	231	26	28	73	429	94	8	551	377	807	195	1952	2009-10-31 00:00:00	12	36
1507	9	322	173	13	83	162	487	299	7	670	424	500	300	2044	2006-03-31 00:00:00	9	15
1508	9	334	128	20	92	150	470	281	14	577	361	477	305	1792	2006-04-30 00:00:00	9	25
1509	9	358	167	17	77	187	443	292	5	634	415	448	287	1846	2006-05-31 00:00:00	9	39
1510	9	271	141	5	59	141	430	205	9	569	374	437	228	1831	2006-06-30 00:00:00	9	21
1511	9	341	153	18	66	137	424	201	11	604	325	435	251	1731	2006-07-31 00:00:00	9	23
1512	9	338	202	11	81	275	510	229	13	674	417	526	247	2173	2006-08-31 00:00:00	9	21
1513	9	360	160	7	66	148	484	230	9	603	288	488	225	1768	2006-09-30 00:00:00	9	23
1514	9	342	163	11	69	164	506	280	15	652	305	508	257	2549	2006-10-31 00:00:00	9	21
1515	9	291	158	11	67	188	540	260	11	696	402	559	242	2245	2006-11-30 00:00:00	9	19
1516	9	371	152	13	56	135	473	198	6	639	464	504	238	2136	2006-12-31 00:00:00	9	26
1517	9	404	195	17	59	142	601	240	11	767	407	611	260	2106	2007-01-31 00:00:00	9	22
1519	9	475	215	19	71	173	614	285	19	767	691	621	253	2276	2007-03-31 00:00:00	9	18
1520	9	443	186	13	58	142	500	267	6	630	420	507	259	2271	2007-04-30 00:00:00	9	22
1521	9	348	220	15	61	161	555	224	12	705	412	564	244	2187	2007-05-31 00:00:00	9	29
1522	9	391	241	10	68	179	518	262	14	694	592	528	238	2187	2007-06-30 00:00:00	9	15
1523	9	355	195	14	50	112	499	234	10	623	379	504	219	2096	2007-07-31 00:00:00	9	17
1524	9	421	228	8	58	112	498	317	11	622	486	508	246	2406	2007-08-31 00:00:00	9	6
1526	9	372	263	9	68	172	583	315	8	778	394	596	222	2281	2007-10-31 00:00:00	9	20
1527	9	337	231	11	70	142	550	284	22	678	663	564	172	2272	2007-11-30 00:00:00	9	17
1528	9	377	217	15	54	104	521	258	10	660	318	531	176	2080	2007-12-31 00:00:00	9	21
1529	9	419	228	12	51	106	503	209	6	651	341	516	200	2033	2008-01-31 00:00:00	9	11
1531	9	440	260	15	45	131	560	172	13	736	577	566	190	2427	2008-03-31 00:00:00	9	20
1533	9	388	255	19	42	150	504	155	4	666	325	518	226	2122	2008-05-31 00:00:00	9	17
1534	9	457	256	23	53	103	520	128	4	674	405	536	182	2274	2008-06-30 00:00:00	9	12
1535	9	435	274	15	48	89	574	137	90	748	390	585	184	2412	2008-07-31 00:00:00	9	9
1536	9	403	257	6	46	118	526	132	11	626	376	534	178	2173	2008-08-31 00:00:00	9	18
1537	9	267	182	15	29	93	386	103	7	475	275	399	174	1678	2008-09-30 00:00:00	9	16
1538	9	175	132	7	30	100	371	54	6	465	196	384	170	1175	2008-10-31 00:00:00	9	28
1539	9	275	185	16	40	111	412	97	9	539	257	423	224	1680	2008-11-30 00:00:00	9	18
1540	9	370	226	14	53	152	485	106	14	613	372	495	219	2221	2008-12-31 00:00:00	9	27
1541	9	391	239	19	48	128	553	121	9	679	527	587	272	2052	2009-01-31 00:00:00	9	20
1543	9	397	266	19	47	136	586	163	27	739	456	601	217	2446	2009-03-31 00:00:00	9	19
1544	9	464	263	21	45	135	534	157	10	710	407	577	251	2394	2009-04-30 00:00:00	9	19
1545	9	418	280	10	39	142	578	184	16	730	428	630	244	2521	2009-05-31 00:00:00	9	24
1546	9	390	252	13	55	125	546	135	10	680	416	579	213	2501	2009-06-30 00:00:00	9	20
1547	9	367	241	19	55	144	527	115	11	647	389	580	296	2168	2009-07-31 00:00:00	9	23
1548	9	408	302	13	32	104	566	117	9	717	566	662	276	2576	2009-08-31 00:00:00	9	18
1549	9	464	303	5	46	112	550	169	19	679	420	613	242	2651	2009-09-30 00:00:00	9	18
1550	9	439	322	3	58	122	626	149	11	775	609	704	276	2578	2009-10-31 00:00:00	9	18
1551	9	414	293	19	46	114	536	150	5	663	379	575	215	2564	2009-11-30 00:00:00	9	19
1160	7	252	158	25	62	157	483	61	19	599	353	693	368	1993	2007-08-31 00:00:00	7	20
1161	7	249	152	32	49	121	395	65	11	507	361	661	295	1983	2007-09-30 00:00:00	7	24
1960	12	170	351	29	48	107	582	109	26	690	251	833	319	2337	2013-08-31 00:00:00	12	30
1162	7	259	159	30	40	120	443	69	11	578	366	694	325	1900	2007-10-31 00:00:00	7	17
1163	7	275	172	25	58	149	423	62	15	555	405	730	275	1714	2007-11-30 00:00:00	7	24
1164	7	260	130	25	44	107	373	34	2	496	281	577	281	1692	2007-12-31 00:00:00	7	32
1961	12	150	285	32	41	125	534	72	6	614	274	808	310	1992	2013-09-30 00:00:00	12	26
1165	7	234	166	22	40	107	451	62	21	577	325	694	278	1888	2008-01-31 00:00:00	7	19
1167	7	259	190	31	48	154	464	68	16	588	445	772	300	1835	2008-03-31 00:00:00	7	18
1168	7	275	194	30	46	122	434	58	12	577	340	647	243	1748	2008-04-30 00:00:00	7	16
1169	7	267	171	33	38	111	456	54	15	612	437	763	316	1778	2008-05-31 00:00:00	7	20
1962	12	166	270	17	44	93	568	69	17	637	295	863	354	2212	2013-10-31 00:00:00	12	33
1170	7	246	187	30	34	94	412	65	18	518	337	656	289	1854	2008-06-30 00:00:00	7	20
1171	7	249	167	30	30	98	433	35	20	547	319	690	290	1869	2008-07-31 00:00:00	7	21
1172	7	245	141	29	31	108	422	29	24	529	260	623	309	1706	2008-08-31 00:00:00	7	20
1173	7	201	140	44	28	85	377	32	17	488	170	500	271	1378	2008-09-30 00:00:00	7	14
1963	12	126	243	9	35	84	513	83	30	578	274	787	307	2060	2013-11-30 00:00:00	12	27
1174	7	181	95	30	35	114	339	28	13	448	193	488	269	1260	2008-10-31 00:00:00	7	22
1175	7	212	134	39	35	112	348	24	11	457	323	628	310	1533	2008-11-30 00:00:00	7	22
1176	7	240	166	36	37	147	412	58	24	518	238	591	361	1862	2008-12-31 00:00:00	7	24
1964	12	120	193	15	46	82	506	97	27	563	237	743	396	1748	2013-12-31 00:00:00	12	36
1972	12	163	230	26	47	118	484	187	29	541	305	789	301	1887	2014-08-31 00:00:00	12	33
1177	7	280	163	34	45	113	446	46	19	566	329	711	381	1678	2009-01-31 00:00:00	7	23
1178	7	295	172	29	31	102	474	66	18	635	280	720	383	1875	2009-02-28 00:00:00	7	20
1179	7	304	150	45	50	145	484	65	18	612	313	737	425	1972	2009-03-31 00:00:00	7	21
1181	7	294	175	33	42	125	480	49	17	591	378	840	429	2026	2009-05-31 00:00:00	7	27
1182	7	289	187	20	36	115	451	56	12	552	371	736	409	1850	2009-06-30 00:00:00	7	24
1183	7	274	205	24	26	120	477	40	14	586	342	801	386	1809	2009-07-31 00:00:00	7	20
1189	7	325	226	22	38	100	520	48	21	682	339	801	412	1744	2010-01-31 00:00:00	7	16
1191	7	283	227	23	37	123	547	74	17	666	378	853	445	2027	2010-03-31 00:00:00	7	20
1192	7	267	229	16	41	124	484	67	14	631	322	796	458	2045	2010-04-30 00:00:00	7	22
1193	7	289	238	22	56	124	508	91	22	609	373	860	440	1987	2010-05-31 00:00:00	7	27
1194	7	254	222	20	41	86	439	60	10	552	228	626	416	1778	2010-06-30 00:00:00	7	23
1195	7	287	259	9	34	99	467	69	13	594	310	729	416	2084	2010-07-31 00:00:00	7	15
1196	7	314	249	16	42	112	480	83	13	623	253	687	418	2258	2010-08-31 00:00:00	7	35
1201	7	302	261	19	42	97	492	76	23	636	429	924	470	1872	2011-01-31 00:00:00	7	35
1202	7	338	280	44	43	91	515	85	12	641	287	738	473	1987	2011-02-28 00:00:00	7	28
1203	7	453	308	18	49	97	571	115	22	707	328	850	506	2211	2011-03-31 00:00:00	7	31
1204	7	400	290	18	46	116	576	99	18	689	321	891	445	2097	2011-04-30 00:00:00	7	25
1205	7	386	296	24	50	153	501	88	29	626	446	927	504	2109	2011-05-31 00:00:00	7	29
1206	7	327	296	27	38	79	505	91	26	608	324	849	431	2038	2011-06-30 00:00:00	7	27
1207	7	291	261	38	34	83	476	98	5	570	241	729	531	1888	2011-07-31 00:00:00	7	29
1552	9	393	254	16	52	164	551	123	12	707	501	600	307	2392	2009-12-31 00:00:00	9	27
1553	9	388	265	11	45	115	556	111	11	697	384	598	254	2112	2010-01-31 00:00:00	9	28
1555	9	407	284	10	42	118	596	142	19	715	427	653	251	2625	2010-03-31 00:00:00	9	21
1556	9	330	292	9	47	88	561	120	4	718	459	659	222	2535	2010-04-30 00:00:00	9	16
1557	9	354	266	13	36	79	527	140	16	682	627	627	293	2698	2010-05-31 00:00:00	9	18
1558	9	359	304	5	49	126	604	122	10	755	421	662	224	2552	2010-06-30 00:00:00	9	21
1559	9	385	290	14	31	109	550	109	14	679	300	584	260	2327	2010-07-31 00:00:00	9	18
1560	9	478	370	15	35	164	641	156	14	811	426	746	264	2608	2010-08-31 00:00:00	9	23
1561	9	420	380	13	43	119	566	166	21	701	505	668	291	2632	2010-09-30 00:00:00	9	23
1562	9	388	357	4	48	113	571	160	20	689	321	631	286	2471	2010-10-31 00:00:00	9	27
1563	9	450	298	14	51	139	573	152	8	731	408	645	261	2486	2010-11-30 00:00:00	9	16
1564	9	484	344	20	25	93	547	97	15	671	441	605	312	2533	2010-12-31 00:00:00	9	25
1565	9	461	339	14	44	120	580	123	15	706	377	670	340	2142	2011-01-31 00:00:00	9	22
1567	9	532	421	13	37	105	663	139	14	822	400	770	356	2598	2011-03-31 00:00:00	9	13
1568	9	459	345	14	44	101	578	186	19	699	376	839	291	2472	2011-04-30 00:00:00	9	20
1569	9	463	396	24	50	145	664	201	32	816	453	1021	305	2611	2011-05-31 00:00:00	9	16
1208	7	335	295	40	43	122	545	116	24	713	341	930	524	2301	2011-08-31 00:00:00	7	24
1213	7	371	326	20	47	106	518	79	14	660	244	824	532	2027	2012-01-31 00:00:00	7	22
1215	7	396	338	26	43	121	581	116	16	704	291	910	649	2538	2012-03-31 00:00:00	7	21
1216	7	429	328	35	57	132	616	109	28	764	376	1012	563	2355	2012-04-30 00:00:00	7	25
1217	7	440	393	27	52	108	595	95	44	742	434	1071	623	2310	2012-05-31 00:00:00	7	22
1218	7	387	353	39	43	102	542	104	28	678	322	890	528	2470	2012-06-30 00:00:00	7	24
1219	7	374	338	21	38	101	522	88	35	612	397	940	557	2297	2012-07-31 00:00:00	7	22
1220	7	427	347	40	56	128	605	102	27	770	428	1093	557	2474	2012-08-31 00:00:00	7	26
1225	7	455	391	50	48	97	667	100	18	815	312	1033	573	2440	2013-01-31 00:00:00	7	32
1226	7	524	483	50	41	106	764	148	26	890	340	1136	533	2640	2013-02-28 00:00:00	7	23
1227	7	418	424	35	51	132	779	134	26	938	345	1176	578	2684	2013-03-31 00:00:00	7	40
1228	7	467	423	40	56	132	722	92	31	855	284	1050	620	2764	2013-04-30 00:00:00	7	33
1229	7	394	462	51	48	117	731	96	27	907	384	1178	620	2478	2013-05-31 00:00:00	7	25
1230	7	412	382	39	39	104	683	134	26	817	370	1123	645	2667	2013-06-30 00:00:00	7	32
1231	7	358	374	44	39	111	582	112	20	719	234	858	600	2381	2013-07-31 00:00:00	7	34
1232	7	401	395	25	54	120	679	128	45	809	390	1113	601	2608	2013-08-31 00:00:00	7	33
1237	7	324	341	15	48	139	694	107	15	832	235	982	605	2536	2014-01-31 00:00:00	7	34
1238	7	349	380	29	45	109	698	109	42	854	413	1162	544	2430	2014-02-28 00:00:00	7	21
1239	7	320	398	16	35	119	727	119	22	878	261	1036	661	2361	2014-03-31 00:00:00	7	31
1240	7	300	331	38	48	108	632	110	43	756	396	1049	569	2520	2014-04-30 00:00:00	7	24
1241	7	316	452	26	38	124	729	144	37	891	416	1210	613	2308	2014-05-31 00:00:00	7	21
1242	7	290	427	30	55	127	703	134	58	851	358	1098	576	2527	2014-06-30 00:00:00	7	19
1243	7	293	411	21	42	115	648	132	52	794	339	1025	521	2412	2014-07-31 00:00:00	7	23
1244	7	346	479	28	33	106	614	136	62	728	347	1001	570	2408	2014-08-31 00:00:00	7	24
1249	7	248	400	20	44	118	652	130	33	796	282	967	630	2373	2015-01-31 00:00:00	7	33
1250	7	262	424	37	45	129	648	140	27	780	371	1050	540	2418	2015-02-28 00:00:00	7	18
1251	7	266	464	33	37	122	716	119	66	863	456	1220	562	2471	2015-03-31 00:00:00	7	24
1252	7	249	391	26	40	125	615	165	54	721	466	1126	574	2405	2015-04-30 00:00:00	7	24
1253	7	230	409	23	31	93	684	145	42	820	488	1251	630	2403	2015-05-31 00:00:00	7	21
1261	7	256	396	30	32	84	645	159	45	768	340	1014	603	2063	2016-01-31 00:00:00	7	28
1273	7	289	432	28	37	99	670	142	45	797	368	1082	558	2404	2017-01-31 00:00:00	7	18
1274	7	228	428	25	44	85	683	114	65	800	384	1074	529	2290	2017-02-28 00:00:00	7	12
1570	9	405	357	26	43	99	552	200	20	683	413	867	306	2863	2011-06-30 00:00:00	9	20
1571	9	418	309	25	27	113	541	156	27	667	397	833	314	2487	2011-07-31 00:00:00	9	15
183	2	71	18	10	50	61	141	8	3	164	70	181	31	516	2002-01-31 00:00:00	2	13
185	2	62	31	10	55	73	89	5	8	105	136	195	33	570	2002-03-31 00:00:00	2	11
186	2	73	23	4	62	70	91	6	2	110	112	211	27	696	2002-04-30 00:00:00	2	9
187	2	66	28	3	63	92	96	6	1	130	154	252	31	666	2002-05-31 00:00:00	2	10
188	2	65	23	8	52	69	82	5	1	104	138	230	24	502	2002-06-30 00:00:00	2	7
189	2	71	34	9	62	74	78	1	8	107	90	170	34	505	2002-07-31 00:00:00	2	9
190	2	65	41	12	60	75	92	8	7	129	147	234	33	719	2002-08-31 00:00:00	2	1
191	2	47	13	12	50	55	69	4	3	92	110	164	17	499	2002-09-30 00:00:00	2	10
192	2	76	43	13	57	71	101	6	3	142	89	191	25	642	2002-10-31 00:00:00	2	13
1572	9	591	393	43	47	111	663	215	38	785	658	1196	386	3041	2011-08-31 00:00:00	9	19
193	2	64	42	8	50	69	105	2	2	137	99	208	23	651	2002-11-30 00:00:00	2	8
194	2	61	27	5	36	64	80	7	6	102	64	149	38	572	2002-12-31 00:00:00	2	9
195	2	70	32	6	43	56	85	3	0	108	67	158	27	522	2003-01-31 00:00:00	2	7
197	2	89	44	8	71	96	116	6	2	149	110	225	20	640	2003-03-31 00:00:00	2	13
198	2	85	42	0	57	83	112	5	4	143	139	257	30	670	2003-04-30 00:00:00	2	9
1573	9	477	411	44	47	93	626	175	36	790	381	934	354	2856	2011-09-30 00:00:00	9	24
199	2	75	53	4	71	80	107	5	16	147	122	228	30	697	2003-05-31 00:00:00	2	3
201	2	81	50	4	46	72	104	3	9	138	84	192	16	611	2003-07-31 00:00:00	2	10
203	2	70	53	8	52	77	101	13	3	138	83	190	20	709	2003-09-30 00:00:00	2	4
204	2	65	55	12	45	65	113	6	6	147	152	268	20	696	2003-10-31 00:00:00	2	5
205	2	63	40	6	55	67	84	8	9	117	106	173	20	606	2003-11-30 00:00:00	2	12
206	2	71	39	5	48	77	93	9	4	133	90	194	23	605	2003-12-31 00:00:00	2	8
207	2	74	25	11	37	57	123	9	0	168	76	214	24	503	2004-01-31 00:00:00	2	3
209	2	57	47	5	34	74	121	15	6	163	117	224	30	708	2004-03-31 00:00:00	2	4
210	2	48	24	1	35	59	103	8	3	130	114	216	36	657	2004-04-30 00:00:00	2	13
211	2	55	33	8	36	99	104	17	5	139	97	199	24	608	2004-05-31 00:00:00	2	10
212	2	50	35	4	39	54	105	5	6	126	106	214	18	538	2004-06-30 00:00:00	2	8
213	2	47	43	4	45	65	108	8	2	130	65	173	18	539	2004-07-31 00:00:00	2	11
214	2	59	41	5	47	56	109	2	3	145	72	184	32	579	2004-08-31 00:00:00	2	11
215	2	51	31	4	33	73	124	12	1	162	64	191	23	484	2004-09-30 00:00:00	2	14
216	2	61	40	7	35	54	105	9	5	134	65	168	18	633	2004-10-31 00:00:00	2	6
217	2	74	38	5	34	51	96	15	3	123	70	158	21	574	2004-11-30 00:00:00	2	8
218	2	51	29	7	35	47	98	9	2	134	82	179	22	538	2004-12-31 00:00:00	2	14
219	2	38	41	8	40	48	115	9	7	150	129	244	27	494	2005-01-31 00:00:00	2	19
221	2	58	38	6	53	52	106	5	5	140	109	216	30	662	2005-03-31 00:00:00	2	15
222	2	57	44	11	36	64	103	10	5	127	99	205	24	488	2005-04-30 00:00:00	2	7
223	2	39	36	6	28	66	114	11	7	164	102	220	22	575	2005-05-31 00:00:00	2	15
224	2	54	30	6	33	47	82	8	6	101	116	190	26	591	2005-06-30 00:00:00	2	6
225	2	69	43	14	43	51	99	3	10	131	105	203	20	494	2005-07-31 00:00:00	2	14
226	2	58	34	11	41	76	106	10	9	125	154	256	33	654	2005-08-31 00:00:00	2	4
227	2	63	37	21	33	55	99	19	8	133	125	228	34	579	2005-09-30 00:00:00	2	6
228	2	60	34	7	42	58	98	12	9	129	90	191	28	555	2005-10-31 00:00:00	2	12
229	2	51	33	7	40	78	96	10	9	131	100	192	35	592	2005-11-30 00:00:00	2	12
230	2	63	32	2	36	55	105	6	4	140	101	220	30	515	2005-12-31 00:00:00	2	13
231	2	58	44	8	32	49	107	7	3	134	85	190	25	532	2006-01-31 00:00:00	2	10
233	2	60	35	10	42	63	127	16	4	155	150	280	30	737	2006-03-31 00:00:00	2	15
234	2	76	34	15	49	66	101	3	5	125	118	223	29	540	2006-04-30 00:00:00	2	10
235	2	49	43	10	34	72	121	14	4	156	126	257	16	668	2006-05-31 00:00:00	2	7
236	2	52	36	7	27	39	102	7	2	122	106	205	23	527	2006-06-30 00:00:00	2	4
237	2	50	31	11	28	29	83	6	0	105	110	203	21	488	2006-07-31 00:00:00	2	9
238	2	74	53	7	30	60	131	12	5	169	145	282	18	670	2006-08-31 00:00:00	2	8
2185	13	166	55	15	103	194	417	18	10	528	209	617	201	1427	2002-01-31 00:00:00	13	33
239	2	49	54	4	41	50	140	13	3	172	80	218	20	629	2006-09-30 00:00:00	2	11
240	2	52	39	11	34	39	150	43	4	187	105	258	28	742	2006-10-31 00:00:00	2	10
241	2	50	34	20	43	63	151	13	12	169	129	283	27	714	2006-11-30 00:00:00	2	9
242	2	58	33	7	33	54	112	10	11	159	114	232	30	627	2006-12-31 00:00:00	2	13
243	2	72	36	10	32	49	124	7	3	162	114	242	24	648	2007-01-31 00:00:00	2	7
245	2	58	48	9	39	66	140	18	6	177	166	303	39	778	2007-03-31 00:00:00	2	4
246	2	79	48	8	28	50	132	4	10	159	104	237	32	676	2007-04-30 00:00:00	2	11
247	2	66	54	10	31	51	117	9	5	150	158	278	24	793	2007-05-31 00:00:00	2	4
248	2	62	41	15	31	60	137	2	8	177	144	276	21	614	2007-06-30 00:00:00	2	5
249	2	51	49	9	27	63	122	15	10	154	99	221	20	644	2007-07-31 00:00:00	2	1
250	2	91	44	20	31	45	138	10	23	167	135	275	32	793	2007-08-31 00:00:00	2	7
251	2	86	60	20	28	59	148	17	4	190	136	293	18	627	2007-09-30 00:00:00	2	8
252	2	77	51	17	22	43	126	10	11	169	132	253	37	630	2007-10-31 00:00:00	2	6
253	2	79	50	32	28	65	149	11	1	171	133	283	37	684	2007-11-30 00:00:00	2	7
254	2	65	35	6	20	28	118	2	4	152	95	217	18	563	2007-12-31 00:00:00	2	8
255	2	68	51	9	26	44	138	7	5	151	91	225	30	635	2008-01-31 00:00:00	2	3
257	2	67	43	14	30	48	127	12	8	150	118	246	27	654	2008-03-31 00:00:00	2	3
258	2	75	41	15	26	45	114	13	12	137	111	227	32	713	2008-04-30 00:00:00	2	7
259	2	87	56	12	20	48	135	11	6	176	133	273	26	610	2008-05-31 00:00:00	2	6
260	2	70	67	16	36	34	139	15	2	180	120	253	23	789	2008-06-30 00:00:00	2	4
261	2	84	50	11	13	29	117	15	3	160	133	243	19	642	2008-07-31 00:00:00	2	9
262	2	66	52	21	24	41	130	5	2	163	120	251	19	727	2008-08-31 00:00:00	2	4
263	2	45	48	11	14	52	108	15	5	130	87	190	30	588	2008-09-30 00:00:00	2	5
264	2	34	35	4	15	38	100	14	2	126	58	163	26	515	2008-10-31 00:00:00	2	5
265	2	77	44	12	18	32	114	25	22	135	124	243	22	579	2008-11-30 00:00:00	2	6
266	2	75	51	7	26	51	140	13	1	171	112	261	42	624	2008-12-31 00:00:00	2	8
1574	9	491	375	36	60	127	628	218	38	790	344	892	385	2607	2011-10-31 00:00:00	9	22
1575	9	435	375	54	48	119	605	201	33	738	543	1026	331	2531	2011-11-30 00:00:00	9	26
267	2	76	49	5	26	46	141	10	1	172	151	298	30	619	2009-01-31 00:00:00	2	4
269	2	82	76	16	34	42	190	12	3	235	136	328	39	906	2009-03-31 00:00:00	2	1
271	2	70	55	9	27	42	159	18	3	197	135	281	56	829	2009-05-31 00:00:00	2	6
1576	9	546	306	29	60	109	598	133	17	788	242	788	398	2440	2011-12-31 00:00:00	9	22
1577	9	472	414	40	48	112	655	214	21	814	314	879	387	2479	2012-01-31 00:00:00	9	33
272	2	41	63	13	26	50	149	27	11	193	141	278	38	689	2009-06-30 00:00:00	2	8
273	2	56	46	8	24	40	132	13	1	163	121	255	46	656	2009-07-31 00:00:00	2	4
275	2	50	50	3	19	31	134	16	5	165	135	270	34	740	2009-09-30 00:00:00	2	3
276	2	55	78	7	23	42	143	39	28	182	183	330	55	758	2009-10-31 00:00:00	2	4
1579	9	515	453	47	52	116	727	222	24	893	441	1068	376	3117	2012-03-31 00:00:00	9	22
1580	9	516	438	48	53	119	661	237	34	820	461	994	394	2924	2012-04-30 00:00:00	9	20
277	2	63	53	11	21	42	146	24	16	172	121	275	58	795	2009-11-30 00:00:00	2	4
278	2	49	53	9	21	31	145	8	6	181	104	249	46	734	2009-12-31 00:00:00	2	7
279	2	38	49	4	18	40	136	21	8	178	121	264	53	566	2010-01-31 00:00:00	2	6
1581	9	476	460	50	55	127	717	203	45	875	506	1094	455	3187	2012-05-31 00:00:00	9	14
1582	9	502	412	51	54	143	684	208	28	831	595	1132	417	3059	2012-06-30 00:00:00	9	21
281	2	32	45	14	18	28	143	17	6	188	149	294	42	863	2010-03-31 00:00:00	2	8
282	2	41	59	6	11	27	123	17	3	149	115	239	49	676	2010-04-30 00:00:00	2	7
283	2	33	35	10	21	34	106	20	14	138	132	239	38	711	2010-05-31 00:00:00	2	5
284	2	30	45	3	21	31	124	13	9	151	108	233	34	726	2010-06-30 00:00:00	2	7
1583	9	419	361	45	60	151	620	175	30	733	364	909	438	2744	2012-07-31 00:00:00	9	24
1584	9	518	424	57	44	115	669	269	36	814	474	1034	431	3156	2012-08-31 00:00:00	9	32
285	2	37	58	16	14	38	140	21	5	169	122	265	53	729	2010-07-31 00:00:00	2	7
286	2	62	68	8	19	34	140	13	8	177	152	300	54	748	2010-08-31 00:00:00	2	6
287	2	72	78	10	12	22	147	12	7	172	79	228	25	744	2010-09-30 00:00:00	2	7
2187	13	137	67	30	101	212	389	19	2	499	245	582	195	1554	2002-03-31 00:00:00	13	44
2188	13	155	85	13	115	218	398	25	5	522	276	636	195	1868	2002-04-30 00:00:00	13	41
2189	13	146	56	24	122	230	376	16	10	510	315	637	220	1816	2002-05-31 00:00:00	13	26
2190	13	131	68	17	97	192	329	9	4	440	244	525	179	1588	2002-06-30 00:00:00	13	32
2191	13	143	67	17	88	163	327	20	7	432	237	519	180	1523	2002-07-31 00:00:00	13	31
288	2	62	83	3	25	41	155	19	4	183	74	238	49	728	2010-10-31 00:00:00	2	9
289	2	57	88	3	14	31	128	22	3	162	79	210	43	660	2010-11-30 00:00:00	2	10
290	2	61	62	4	9	33	132	20	5	159	102	237	34	666	2010-12-31 00:00:00	2	9
291	2	65	94	3	14	41	160	15	6	200	95	257	46	745	2011-01-31 00:00:00	2	11
293	2	69	86	23	17	34	147	19	7	173	117	266	56	905	2011-03-31 00:00:00	2	14
294	2	48	76	4	21	38	141	15	5	163	113	254	50	970	2011-04-30 00:00:00	2	5
295	2	62	73	8	12	30	137	10	8	166	110	249	60	880	2011-05-31 00:00:00	2	3
1585	9	470	393	51	48	133	645	232	20	752	356	919	422	2726	2012-09-30 00:00:00	9	29
296	2	64	71	6	19	30	134	15	11	160	127	260	43	1011	2011-06-30 00:00:00	2	6
297	2	66	97	11	20	45	148	12	12	175	115	267	44	796	2011-07-31 00:00:00	2	4
298	2	90	72	8	23	41	164	18	13	214	113	290	68	1039	2011-08-31 00:00:00	2	4
299	2	63	85	3	24	39	161	24	6	197	112	276	49	985	2011-09-30 00:00:00	2	8
300	2	90	72	15	18	32	142	20	6	193	122	280	47	800	2011-10-31 00:00:00	2	5
301	2	80	84	12	22	57	168	34	5	206	91	262	37	889	2011-11-30 00:00:00	2	4
302	2	87	71	2	15	29	141	23	8	185	114	256	45	774	2011-12-31 00:00:00	2	6
303	2	95	93	7	12	21	155	26	4	186	92	246	44	619	2012-01-31 00:00:00	2	3
305	2	97	100	19	27	114	209	33	11	249	122	333	45	1052	2012-03-31 00:00:00	2	8
306	2	97	90	8	14	32	153	26	11	183	100	254	51	952	2012-04-30 00:00:00	2	3
307	2	95	93	10	22	34	193	28	7	226	130	326	39	964	2012-05-31 00:00:00	2	6
308	2	105	93	9	19	58	184	25	5	212	87	271	43	959	2012-06-30 00:00:00	2	5
309	2	82	79	9	18	56	140	36	7	168	113	253	32	800	2012-07-31 00:00:00	2	3
310	2	88	102	6	19	38	172	22	6	207	129	305	43	1011	2012-08-31 00:00:00	2	6
311	2	68	72	13	16	45	157	13	5	190	106	253	48	934	2012-09-30 00:00:00	2	3
312	2	74	79	5	13	37	154	17	12	184	129	286	45	961	2012-10-31 00:00:00	2	8
313	2	94	64	9	18	45	139	21	8	168	116	258	32	990	2012-11-30 00:00:00	2	4
314	2	85	93	2	11	29	215	18	4	262	85	300	39	820	2012-12-31 00:00:00	2	7
315	2	102	84	3	21	51	238	23	1	277	69	314	56	934	2013-01-31 00:00:00	2	6
317	2	73	81	5	19	19	250	29	9	297	118	370	45	978	2013-03-31 00:00:00	2	6
318	2	83	95	8	16	33	223	35	6	279	112	336	41	951	2013-04-30 00:00:00	2	7
319	2	93	107	6	20	32	240	36	4	288	110	351	44	925	2013-05-31 00:00:00	2	4
320	2	93	66	5	9	22	210	23	7	240	126	335	31	828	2013-06-30 00:00:00	2	5
321	2	82	92	3	18	24	190	23	9	213	111	305	39	755	2013-07-31 00:00:00	2	2
322	2	88	88	5	18	15	157	30	6	187	96	254	52	894	2013-08-31 00:00:00	2	7
323	2	90	89	1	18	18	198	19	14	230	92	290	47	812	2013-09-30 00:00:00	2	1
324	2	88	71	10	10	31	203	24	7	234	106	309	65	932	2013-10-31 00:00:00	2	10
325	2	70	94	5	11	33	196	19	9	230	111	308	49	892	2013-11-30 00:00:00	2	10
326	2	51	50	4	16	18	138	16	7	155	61	199	75	693	2013-12-31 00:00:00	2	8
327	2	72	70	4	12	23	199	22	1	231	76	275	66	770	2014-01-31 00:00:00	2	7
329	2	64	88	7	22	29	219	25	10	245	114	332	45	906	2014-03-31 00:00:00	2	5
330	2	43	79	6	20	27	212	31	9	251	122	333	40	950	2014-04-30 00:00:00	2	7
331	2	43	72	9	10	23	175	24	11	205	136	311	62	839	2014-05-31 00:00:00	2	6
332	2	58	97	6	19	48	217	36	6	262	118	335	51	833	2014-06-30 00:00:00	2	7
333	2	69	108	5	18	28	210	37	16	240	125	334	39	906	2014-07-31 00:00:00	2	11
334	2	81	95	8	21	34	208	38	19	246	118	326	40	828	2014-08-31 00:00:00	2	3
336	2	65	92	11	13	27	184	25	11	227	128	312	54	898	2014-10-31 00:00:00	2	10
337	2	46	80	16	15	34	197	25	14	243	122	321	49	794	2014-11-30 00:00:00	2	7
338	2	70	57	10	15	53	170	24	9	185	99	269	37	735	2014-12-31 00:00:00	2	8
339	2	64	75	10	21	45	185	27	6	224	107	291	47	697	2015-01-31 00:00:00	2	10
341	2	57	67	6	17	37	165	26	13	189	115	280	105	839	2015-03-31 00:00:00	2	4
342	2	59	86	11	17	40	174	43	11	204	120	298	73	821	2015-04-30 00:00:00	2	3
343	2	62	91	15	16	27	172	32	12	209	151	327	49	849	2015-05-31 00:00:00	2	5
344	2	63	103	5	15	39	183	20	15	222	164	334	57	837	2015-06-30 00:00:00	2	3
345	2	63	111	12	14	29	180	24	16	210	148	328	41	758	2015-07-31 00:00:00	2	8
346	2	75	108	4	20	42	213	36	11	256	149	363	51	840	2015-08-31 00:00:00	2	8
347	2	83	95	8	23	38	183	37	22	218	138	321	42	835	2015-09-30 00:00:00	2	8
348	2	58	106	3	9	26	238	28	6	279	133	373	34	802	2015-10-31 00:00:00	2	14
349	2	77	122	7	15	34	213	33	10	275	136	349	48	816	2015-11-30 00:00:00	2	3
2196	13	139	64	20	121	202	404	11	1	511	316	635	188	1728	2002-12-31 00:00:00	13	48
350	2	67	105	15	14	32	204	38	15	246	138	342	38	767	2015-12-31 00:00:00	2	10
351	2	71	132	5	17	28	226	48	2	269	114	340	44	748	2016-01-31 00:00:00	2	10
353	2	83	116	18	16	36	247	41	30	278	164	411	42	877	2016-03-31 00:00:00	2	11
354	2	92	130	38	12	33	208	45	15	244	158	366	39	779	2016-04-30 00:00:00	2	11
355	2	66	124	9	27	33	224	42	16	248	137	361	30	844	2016-05-31 00:00:00	2	5
356	2	74	127	25	16	40	224	38	14	264	138	362	47	892	2016-06-30 00:00:00	2	6
357	2	58	113	9	8	28	220	31	12	262	136	356	51	790	2016-07-31 00:00:00	2	8
358	2	57	106	16	17	46	208	35	13	248	184	392	39	774	2016-08-31 00:00:00	2	3
359	2	57	126	19	12	28	215	34	15	272	155	370	25	811	2016-09-30 00:00:00	2	4
360	2	46	127	7	13	33	221	35	8	279	166	387	58	857	2016-10-31 00:00:00	2	10
361	2	74	137	5	11	25	216	40	7	246	140	356	51	768	2016-11-30 00:00:00	2	10
362	2	63	96	8	8	31	177	27	7	208	121	298	49	787	2016-12-31 00:00:00	2	6
363	2	55	143	15	21	37	238	35	4	271	116	354	34	812	2017-01-31 00:00:00	2	3
2	1	1846	959	205	1515	3191	5661	685	114	7370	2339	7266	7381	23865	2002-02-28 00:00:00	1	980
38	1	1624	1309	168	1108	2633	5363	815	149	7236	2968	7244	6588	24045	2005-02-28 00:00:00	1	758
50	1	1986	1551	238	887	2022	5137	971	153	7031	3322	7177	5837	24169	2006-02-28 00:00:00	1	521
62	1	2047	1721	289	782	2045	5872	866	169	7601	3611	8182	5138	27699	2007-02-28 00:00:00	1	450
86	1	2202	2188	308	671	1751	6704	866	134	8611	3719	9472	6186	27196	2009-02-28 00:00:00	1	402
98	1	1912	2438	237	539	1578	6322	837	143	8330	3752	8948	5626	28259	2010-02-28 00:00:00	1	415
1586	9	519	447	61	51	122	708	270	28	862	339	974	421	3155	2012-10-31 00:00:00	9	55
1587	9	498	375	29	41	105	578	206	24	699	366	865	391	2814	2012-11-30 00:00:00	9	31
1588	9	497	409	35	50	120	688	193	17	793	584	1151	464	2733	2012-12-31 00:00:00	9	31
1589	9	598	497	53	51	107	822	256	26	981	334	1104	529	3001	2013-01-31 00:00:00	9	28
1591	9	646	480	48	63	131	1115	296	52	1302	577	1544	406	3651	2013-03-31 00:00:00	9	24
1592	9	607	489	55	71	142	1022	319	52	1173	357	1286	416	3445	2013-04-30 00:00:00	9	22
184	2	93	35	13	52	67	112	3	0	162	93	189	26	599	2002-02-28 00:00:00	2	8
196	2	82	33	7	48	89	108	1	3	141	89	198	26	684	2003-02-28 00:00:00	2	11
220	2	40	54	2	52	66	148	17	9	185	107	253	33	593	2005-02-28 00:00:00	2	16
1593	9	618	498	49	58	152	1113	279	31	1303	585	1560	427	3321	2013-05-31 00:00:00	9	21
232	2	49	40	13	45	64	116	6	7	147	77	198	27	472	2006-02-28 00:00:00	2	7
244	2	72	43	9	32	40	127	16	5	164	101	236	23	598	2007-02-28 00:00:00	2	6
1594	9	560	443	70	56	157	1009	263	66	1149	507	1413	499	3468	2013-06-30 00:00:00	9	23
268	2	78	63	2	33	48	167	16	6	201	99	264	32	719	2009-02-28 00:00:00	2	8
280	2	51	43	4	20	39	131	17	8	158	112	234	43	722	2010-02-28 00:00:00	2	13
1595	9	565	398	61	44	129	980	193	42	1157	364	1273	411	3245	2013-07-31 00:00:00	9	23
292	2	71	89	17	16	19	134	7	6	166	113	246	42	897	2011-02-28 00:00:00	2	5
316	2	82	85	13	19	38	218	17	9	255	99	317	38	897	2013-02-28 00:00:00	2	3
1596	9	625	448	67	52	180	1010	226	60	1124	401	1330	441	3341	2013-08-31 00:00:00	9	25
328	2	63	89	8	16	23	196	28	11	219	109	311	64	823	2014-02-28 00:00:00	2	7
340	2	68	85	7	19	38	182	25	5	229	101	287	52	729	2015-02-28 00:00:00	2	5
364	2	56	128	17	19	41	206	38	3	245	125	331	41	811	2017-02-28 00:00:00	2	5
1598	9	617	400	36	51	135	884	305	49	1021	337	1140	494	3179	2013-10-31 00:00:00	9	23
110	1	2074	2812	336	490	1515	6690	966	156	8345	4214	9721	6359	31678	2011-02-28 00:00:00	1	352
1599	9	614	383	41	52	113	891	227	42	1019	504	1309	435	3197	2013-11-30 00:00:00	9	23
2312	13	218	293	31	59	110	606	75	18	707	420	956	227	2400	2012-08-31 00:00:00	13	30
134	1	2821	4015	373	575	1440	9811	1407	269	11732	3782	12920	7237	35244	2013-02-28 00:00:00	1	391
146	1	2278	3207	297	540	1454	8713	1596	301	10607	3677	12044	8273	35605	2014-02-28 00:00:00	1	357
2313	13	198	270	16	32	102	521	65	20	602	356	788	181	2155	2012-09-30 00:00:00	13	23
2314	13	212	282	19	49	110	560	69	35	683	284	847	227	2421	2012-10-31 00:00:00	13	20
2315	13	198	284	29	46	84	539	74	13	639	322	863	236	2140	2012-11-30 00:00:00	13	31
2316	13	161	233	17	40	77	569	65	18	641	350	865	228	2267	2012-12-31 00:00:00	13	31
2324	13	237	328	21	28	86	690	60	19	791	293	924	231	2356	2013-08-31 00:00:00	13	29
2325	13	249	333	19	50	123	649	71	22	772	318	960	264	2468	2013-09-30 00:00:00	13	25
2326	13	229	287	20	41	105	684	50	16	798	342	969	264	2502	2013-10-31 00:00:00	13	24
2327	13	186	279	20	44	143	696	55	27	799	420	1011	240	2276	2013-11-30 00:00:00	13	13
912	6	109	85	8	231	610	879	142	17	1181	232	1221	1760	3999	2002-02-28 00:00:00	6	299
924	6	123	130	37	203	548	975	150	12	1376	434	1987	1676	4914	2003-02-28 00:00:00	6	291
948	6	88	153	44	193	486	886	176	23	1239	328	1338	1462	4217	2005-02-28 00:00:00	6	230
960	6	108	211	42	137	417	862	161	22	1323	439	1437	1235	3860	2006-02-28 00:00:00	6	144
972	6	99	230	51	128	374	920	190	17	1243	421	1503	1030	4660	2007-02-28 00:00:00	6	133
996	6	102	295	44	101	302	974	188	22	1354	557	1643	1362	5158	2009-02-28 00:00:00	6	111
1020	6	103	409	72	64	265	1035	236	25	1326	661	1774	1323	5621	2011-02-28 00:00:00	6	97
1044	6	88	538	24	89	220	1517	276	21	1907	542	2160	1370	5887	2013-02-28 00:00:00	6	108
1056	6	72	363	24	79	263	1305	292	25	1674	568	1974	1825	6050	2014-02-28 00:00:00	6	96
1068	6	119	427	50	67	198	1324	234	42	1714	705	2171	1560	5370	2015-02-28 00:00:00	6	68
1092	6	192	547	39	44	189	1532	295	46	1893	876	2564	1373	5118	2017-02-28 00:00:00	6	76
548	4	172	104	8	116	238	466	75	9	641	166	652	648	1755	2002-02-28 00:00:00	4	63
1600	9	501	357	41	64	120	960	225	32	1105	365	1244	450	2840	2013-12-31 00:00:00	9	22
1094	7	196	60	15	107	205	432	45	14	554	232	577	413	1738	2002-02-28 00:00:00	7	32
730	5	231	194	19	328	972	1671	199	32	2090	468	1924	3684	6491	2002-02-28 00:00:00	5	396
560	4	156	95	1	96	207	342	60	11	493	235	550	756	1777	2003-02-28 00:00:00	4	62
742	5	264	249	17	323	963	1579	105	89	2151	613	1912	3239	7453	2003-02-28 00:00:00	5	424
584	4	163	117	1	82	161	388	46	14	508	170	558	567	1757	2005-02-28 00:00:00	4	44
1106	7	187	64	8	100	204	331	23	17	424	238	451	310	1703	2003-02-28 00:00:00	7	41
766	5	211	284	16	263	843	1574	154	27	2101	714	1798	3016	7106	2005-02-28 00:00:00	5	275
1601	9	538	411	31	56	112	887	250	24	1052	282	1123	581	2966	2014-01-31 00:00:00	9	19
778	5	215	311	15	197	511	1350	185	29	1849	665	1549	2574	7763	2006-02-28 00:00:00	5	183
596	4	189	118	5	63	157	388	57	21	528	197	599	623	1745	2006-02-28 00:00:00	4	34
608	4	174	141	10	52	130	458	49	5	595	241	696	535	2095	2007-02-28 00:00:00	4	31
632	4	146	183	12	44	124	533	90	8	672	320	822	654	2004	2009-02-28 00:00:00	4	28
644	4	162	213	25	35	124	518	64	14	668	223	737	594	1974	2010-02-28 00:00:00	4	19
656	4	169	256	25	27	116	535	81	11	685	324	847	543	2196	2011-02-28 00:00:00	4	21
680	4	259	341	41	52	116	759	94	28	925	295	1089	624	2655	2013-02-28 00:00:00	4	30
692	4	196	257	24	45	136	626	100	10	752	223	857	660	2518	2014-02-28 00:00:00	4	28
704	4	190	329	47	41	103	721	135	27	908	350	1087	570	2483	2015-02-28 00:00:00	4	25
1602	9	471	432	41	53	132	949	230	45	1093	345	1218	442	3315	2014-02-28 00:00:00	9	24
1603	9	577	540	29	67	150	1036	312	42	1180	317	1290	455	3243	2014-03-31 00:00:00	9	21
1605	9	489	458	47	43	114	932	244	57	1091	470	1301	535	3259	2014-05-31 00:00:00	9	24
1606	9	541	495	43	79	155	989	275	76	1183	407	1313	505	3430	2014-06-30 00:00:00	9	16
1607	9	532	488	45	62	139	859	257	87	1026	526	1259	458	3308	2014-07-31 00:00:00	9	19
1608	9	502	468	40	52	116	951	242	59	1108	519	1375	451	3279	2014-08-31 00:00:00	9	30
1609	9	499	485	50	45	143	912	231	46	1063	447	1265	450	3377	2014-09-30 00:00:00	9	18
1610	9	473	526	54	62	129	918	254	45	1082	374	1234	447	3442	2014-10-31 00:00:00	9	26
1611	9	442	466	49	46	105	901	237	56	1023	491	1320	470	3051	2014-11-30 00:00:00	9	20
1612	9	457	428	48	53	133	870	178	29	990	595	1369	431	3064	2014-12-31 00:00:00	9	17
1614	9	422	484	33	54	104	859	203	58	1006	623	1389	442	3003	2015-02-28 00:00:00	9	29
1615	9	394	481	35	60	148	903	258	56	1067	519	1325	499	3219	2015-03-31 00:00:00	9	26
1616	9	394	497	46	49	135	895	234	70	1046	514	1314	445	3088	2015-04-30 00:00:00	9	18
1130	7	182	95	9	84	197	390	39	12	539	253	532	413	1524	2005-02-28 00:00:00	7	35
1142	7	228	136	21	66	162	382	53	14	497	281	537	316	1606	2006-02-28 00:00:00	7	25
1822	12	156	64	55	78	161	398	25	5	538	163	582	141	1525	2002-02-28 00:00:00	12	22
1834	12	133	90	17	70	141	411	37	9	508	212	620	169	2124	2003-02-28 00:00:00	12	46
1858	12	141	94	19	60	113	314	65	14	435	193	517	224	1436	2005-02-28 00:00:00	12	33
486	3	207	222	56	30	85	424	85	23	492	312	734	148	1718	2012-02-28 00:00:00	3	9
1640	10	185	98	34	90	201	320	81	5	364	140	412	226	1406	2002-02-28 00:00:00	10	71
1652	10	205	120	10	68	147	317	59	17	405	174	473	201	1812	2003-02-28 00:00:00	10	58
1276	8	46	18	4	45	55	65	0	0	93	89	76	16	554	2002-02-28 00:00:00	8	4
1870	12	118	135	22	46	101	378	67	9	486	167	539	225	1541	2006-02-28 00:00:00	12	26
1288	8	72	17	7	52	64	74	9	6	91	103	119	15	675	2003-02-28 00:00:00	8	8
1312	8	67	27	14	33	80	91	16	3	121	97	150	20	597	2005-02-28 00:00:00	8	6
1324	8	89	27	9	29	43	97	5	7	130	102	159	25	564	2006-02-28 00:00:00	8	8
1336	8	69	36	23	32	49	131	3	15	164	135	215	16	739	2007-02-28 00:00:00	8	9
1360	8	124	44	20	22	42	149	12	8	193	117	212	25	670	2009-02-28 00:00:00	8	4
1676	10	183	94	16	41	120	339	43	6	416	230	543	257	1320	2005-02-28 00:00:00	10	22
1688	10	196	130	28	53	113	313	48	15	408	262	547	236	1224	2006-02-28 00:00:00	10	23
1458	9	276	142	11	171	244	495	88	12	680	240	502	153	2085	2002-02-28 00:00:00	9	30
1691	10	199	108	20	54	142	361	44	17	475	194	528	206	1414	2006-05-31 00:00:00	10	69
1692	10	127	100	26	39	129	309	37	11	385	214	497	203	1221	2006-06-30 00:00:00	10	20
716	4	223	326	37	37	98	744	126	56	933	368	1133	497	2540	2016-02-29 00:00:00	4	23
304	2	93	81	14	19	29	171	28	3	213	110	283	47	826	2012-02-28 00:00:00	2	4
122	1	2453	3360	336	556	1588	7706	1257	193	9281	3716	10904	7207	33281	2012-02-28 00:00:00	1	348
1693	10	155	93	28	54	142	399	47	5	660	265	661	374	1348	2006-07-31 00:00:00	10	38
1694	10	147	109	27	40	126	325	35	10	497	470	745	264	1283	2006-08-31 00:00:00	10	25
1372	8	102	54	13	13	29	141	10	8	170	189	231	30	832	2010-02-28 00:00:00	8	6
1384	8	102	64	7	5	34	154	21	10	201	137	242	29	822	2011-02-28 00:00:00	8	6
1470	9	229	136	6	157	220	408	101	12	535	386	414	181	2334	2003-02-28 00:00:00	9	45
1695	10	151	98	15	39	219	303	47	9	518	291	559	241	1212	2006-09-30 00:00:00	10	27
1494	9	254	151	6	99	168	463	197	9	610	306	477	234	1927	2005-02-28 00:00:00	9	24
1506	9	368	182	17	78	154	478	299	7	628	345	490	242	1816	2006-02-28 00:00:00	9	19
1518	9	386	194	13	50	129	547	230	13	685	368	559	207	2062	2007-02-28 00:00:00	9	24
1542	9	477	297	11	55	145	601	140	3	740	366	611	262	2277	2009-02-28 00:00:00	9	34
1554	9	446	322	26	62	124	580	148	8	716	494	633	215	2381	2010-02-28 00:00:00	9	25
1566	9	398	385	15	41	120	636	120	12	787	595	810	335	2517	2011-02-28 00:00:00	9	12
1590	9	637	540	42	63	141	991	220	27	1149	461	1345	448	3194	2013-02-28 00:00:00	9	21
1696	10	124	110	25	45	130	380	38	12	576	224	570	251	1536	2006-10-31 00:00:00	10	31
1697	10	115	104	27	50	140	375	57	4	466	209	551	203	1309	2006-11-30 00:00:00	10	19
1698	10	195	80	24	32	102	343	48	13	408	200	512	229	1376	2006-12-31 00:00:00	10	27
1699	10	242	143	31	45	99	414	59	31	489	233	610	260	1649	2007-01-31 00:00:00	10	25
1700	10	202	129	25	54	135	376	58	31	482	238	595	224	1385	2007-02-28 00:00:00	10	14
1408	8	127	75	5	18	46	270	22	5	315	121	365	39	1028	2013-02-28 00:00:00	8	4
1420	8	115	64	9	10	24	202	25	11	232	130	306	39	950	2014-02-28 00:00:00	8	2
1432	8	114	88	22	10	30	190	33	10	230	178	310	39	1012	2015-02-28 00:00:00	8	7
1456	8	95	119	10	19	41	200	37	23	248	277	451	41	928	2017-02-28 00:00:00	8	6
1385	8	170	71	7	5	22	133	24	11	173	166	243	31	873	2011-03-31 00:00:00	8	4
1386	8	115	66	6	25	36	156	22	15	192	157	276	31	824	2011-04-30 00:00:00	8	12
1396	8	134	98	13	21	42	206	33	3	258	133	320	14	858	2012-02-28 00:00:00	8	6
63	1	2247	2032	309	839	2177	6528	1059	174	8452	5330	9831	6216	30483	2007-03-31 00:00:00	1	431
99	1	1718	2510	234	584	1720	6970	893	185	8984	4283	10015	6552	31439	2010-03-31 00:00:00	1	433
1108	7	181	77	8	125	226	370	28	17	474	263	527	389	1938	2003-04-30 00:00:00	7	41
1180	7	269	220	48	39	134	500	49	21	627	407	890	405	2033	2009-04-30 00:00:00	7	18
1214	7	433	279	36	41	87	532	112	24	615	252	808	493	2115	2012-02-28 00:00:00	7	27
270	2	53	51	12	35	56	157	27	13	207	142	331	53	768	2009-04-30 00:00:00	2	2
1032	6	112	420	39	95	294	1154	221	28	1391	587	1891	1560	5797	2012-02-28 00:00:00	6	81
1966	12	139	249	16	59	126	536	191	14	605	268	804	281	2195	2014-02-28 00:00:00	12	28
1978	12	179	293	16	50	103	522	192	26	604	266	788	294	1877	2015-02-28 00:00:00	12	36
2002	12	138	236	5	41	88	466	133	44	532	266	732	220	1887	2017-02-28 00:00:00	12	28
622	4	181	213	8	46	141	519	83	3	695	376	882	434	1956	2008-04-30 00:00:00	4	16
694	4	169	251	36	35	120	665	101	12	811	280	942	676	2695	2014-04-30 00:00:00	4	26
1080	6	424	460	45	85	300	1590	338	51	1981	639	2458	1567	5532	2016-02-29 00:00:00	6	49
1701	10	201	136	23	30	113	382	57	21	465	287	616	214	1558	2007-03-31 00:00:00	10	27
1702	10	193	134	32	45	119	413	55	20	511	230	609	224	1514	2007-04-30 00:00:00	10	10
1703	10	170	127	21	26	98	383	61	15	497	205	570	214	1600	2007-05-31 00:00:00	10	24
1532	9	348	226	22	47	127	512	140	11	688	395	529	221	2212	2008-04-30 00:00:00	9	18
1578	9	550	418	46	46	136	668	165	26	819	501	1042	330	2939	2012-02-28 00:00:00	9	27
828	5	112	440	28	147	548	1744	185	33	2332	714	2115	2533	7964	2010-04-30 00:00:00	5	109
1617	9	387	487	26	60	118	866	260	65	1030	543	1298	449	3217	2015-05-31 00:00:00	9	19
1618	9	397	444	30	52	124	842	226	55	1018	556	1322	423	3137	2015-06-30 00:00:00	9	20
900	5	519	792	26	98	380	3177	349	4	3803	1055	3464	2582	8900	2016-04-30 00:00:00	5	92
1619	9	358	476	40	70	154	867	171	56	1011	618	1364	465	2908	2015-07-31 00:00:00	9	20
1620	9	428	495	37	46	130	878	254	64	1004	570	1350	448	3086	2015-08-31 00:00:00	9	23
1621	9	381	503	32	64	139	874	239	47	1043	540	1334	428	3243	2015-09-30 00:00:00	9	21
475	3	214	198	48	29	70	388	63	13	504	368	620	145	1734	2011-03-31 00:00:00	3	11
476	3	220	163	63	45	108	338	61	14	414	296	601	110	1448	2011-04-30 00:00:00	3	11
2004	11	78	32	6	65	51	166	5	6	203	136	192	49	1032	2002-02-28 00:00:00	11	6
2016	11	87	70	1	59	74	197	12	28	238	158	227	74	1073	2003-02-28 00:00:00	11	7
1704	10	140	129	30	52	154	338	54	17	432	231	549	202	1339	2007-06-30 00:00:00	10	25
1705	10	137	117	17	46	127	312	39	13	400	189	464	196	1236	2007-07-31 00:00:00	10	9
1706	10	186	124	23	41	98	355	55	25	456	236	566	248	1400	2007-08-31 00:00:00	10	20
1707	10	174	135	28	45	126	384	70	23	493	213	579	231	1366	2007-09-30 00:00:00	10	17
1708	10	174	142	31	37	105	387	65	21	508	251	628	211	1479	2007-10-31 00:00:00	10	21
1709	10	157	112	22	32	95	368	38	30	493	206	535	205	1330	2007-11-30 00:00:00	10	24
1710	10	162	132	18	31	87	334	41	15	409	184	503	192	1344	2007-12-31 00:00:00	10	25
1711	10	304	183	28	46	85	419	60	16	498	255	650	249	1548	2008-01-31 00:00:00	10	30
1713	10	160	135	18	33	94	345	39	13	458	275	611	213	1286	2008-03-31 00:00:00	10	16
1714	10	115	146	17	26	81	353	44	15	452	230	561	221	1324	2008-04-30 00:00:00	10	19
1319	8	61	32	31	15	37	108	9	11	139	133	179	18	688	2005-09-30 00:00:00	8	3
967	6	102	247	36	119	308	803	174	11	1145	448	1365	1149	3970	2006-09-30 00:00:00	6	154
1391	8	135	87	22	24	53	164	32	10	200	155	304	34	858	2011-09-30 00:00:00	8	2
1035	6	116	415	38	98	266	1281	233	31	1590	638	2104	1727	7232	2012-05-31 00:00:00	6	85
200	2	71	35	3	51	73	101	11	4	129	110	212	23	582	2003-06-30 00:00:00	2	10
1039	6	105	500	65	86	209	1232	221	25	1565	612	1992	1584	6004	2012-09-30 00:00:00	6	94
202	2	87	54	8	52	95	98	1	4	126	137	238	14	654	2003-08-31 00:00:00	2	6
1877	12	65	137	11	40	101	368	77	4	481	155	522	266	1523	2006-09-30 00:00:00	12	16
274	2	49	54	4	23	53	131	15	13	149	160	288	59	756	2009-08-31 00:00:00	2	6
1667	10	191	87	23	89	186	367	81	12	493	210	558	227	1578	2004-05-31 00:00:00	10	38
1808	10	229	184	26	26	81	549	139	32	632	359	907	314	1585	2016-02-29 00:00:00	10	17
2172	11	108	180	4	36	66	294	61	25	361	293	538	125	1695	2016-02-29 00:00:00	11	7
757	5	261	310	10	302	842	1640	184	16	2166	1062	2106	3235	8362	2004-05-31 00:00:00	5	311
761	5	251	291	13	321	920	1614	146	9	2076	867	1877	3091	8217	2004-09-30 00:00:00	5	286
1942	12	121	231	30	42	86	444	64	6	570	214	658	344	2031	2012-02-28 00:00:00	12	45
1945	12	111	256	25	45	100	529	89	18	642	361	890	291	2380	2012-05-31 00:00:00	12	26
1949	12	119	312	28	38	84	471	100	10	552	226	697	253	2254	2012-09-30 00:00:00	12	33
832	5	130	530	20	122	507	1894	223	26	2461	874	2357	2449	8317	2010-08-31 00:00:00	5	87
554	4	167	86	9	124	217	345	52	2	474	242	579	672	1815	2002-08-31 00:00:00	4	67
615	4	207	146	8	49	153	479	86	9	628	256	733	420	2507	2007-09-30 00:00:00	4	25
687	4	179	281	31	47	123	627	88	20	783	273	909	608	2515	2013-09-30 00:00:00	4	31
1464	9	296	127	12	124	217	428	61	9	547	408	432	189	2388	2002-08-31 00:00:00	9	35
1525	9	380	215	9	67	135	516	360	9	621	397	523	190	2218	2007-09-30 00:00:00	9	21
1597	9	603	413	53	51	189	916	232	44	1054	410	1239	450	3245	2013-09-30 00:00:00	9	24
1604	9	471	433	35	61	120	922	248	37	1056	375	1230	541	3267	2014-04-30 00:00:00	9	25
1622	9	361	438	41	58	129	810	197	43	933	487	1191	474	2916	2015-10-31 00:00:00	9	23
409	3	164	95	25	40	93	247	19	10	303	256	402	106	1232	2005-09-30 00:00:00	3	15
481	3	206	175	41	33	95	351	54	18	436	333	650	149	1888	2011-09-30 00:00:00	3	13
2018	11	88	34	4	50	73	224	10	9	276	205	252	49	1110	2003-04-30 00:00:00	11	2
2022	11	59	45	3	57	95	219	23	15	276	216	244	85	1278	2003-08-31 00:00:00	11	6
2090	11	95	103	23	33	59	255	31	21	328	191	289	108	1310	2009-04-30 00:00:00	11	10
2094	11	83	95	3	26	48	201	14	10	269	303	252	155	1363	2009-08-31 00:00:00	11	8
2124	11	113	156	3	32	44	272	39	14	359	208	386	124	1327	2012-02-28 00:00:00	11	5
1671	10	182	72	13	57	126	332	29	5	383	145	451	232	1481	2004-09-30 00:00:00	10	42
1715	10	114	139	28	25	76	313	44	17	373	288	597	231	1135	2008-05-31 00:00:00	10	13
1716	10	168	142	24	17	74	344	46	13	407	202	538	169	1362	2008-06-30 00:00:00	10	16
1717	10	163	156	53	41	93	364	47	20	444	240	597	186	1334	2008-07-31 00:00:00	10	24
1718	10	132	142	30	26	94	333	49	26	405	194	515	214	1394	2008-08-31 00:00:00	10	23
1719	10	53	97	18	27	82	301	29	3	361	122	421	158	1025	2008-09-30 00:00:00	10	19
1720	10	83	78	20	22	66	267	32	6	331	123	374	182	848	2008-10-31 00:00:00	10	22
2229	13	153	120	57	92	168	355	49	3	461	322	558	203	1669	2005-09-30 00:00:00	13	27
2296	13	168	221	26	50	111	536	64	21	640	343	820	169	1847	2011-04-30 00:00:00	13	25
2301	13	172	246	14	59	118	520	70	14	606	426	753	217	2105	2011-09-30 00:00:00	13	17
1112	7	195	100	8	94	215	370	33	10	514	315	572	354	2001	2003-08-31 00:00:00	7	48
1184	7	247	222	26	43	96	465	39	24	609	366	779	362	2118	2009-08-31 00:00:00	7	18
1245	7	326	465	47	52	129	669	142	50	800	494	1201	512	2429	2014-09-30 00:00:00	7	26
335	2	73	104	9	17	47	211	31	15	247	127	336	42	773	2014-09-30 00:00:00	2	3
68	1	2008	2044	277	756	1999	6212	1034	158	7968	4332	9017	5773	30692	2007-08-31 00:00:00	1	428
100	1	1478	2435	209	539	1651	6315	848	157	8239	4242	9478	5970	29720	2010-04-30 00:00:00	1	406
130	1	2464	3507	412	600	1720	7956	1286	250	9777	3619	11114	7468	38561	2012-10-31 00:00:00	1	569
936	6	86	135	43	182	502	915	204	8	1299	336	1383	1575	4176	2004-02-28 00:00:00	6	183
984	6	119	335	58	114	364	1069	101	27	1502	511	1722	1155	5173	2008-02-28 00:00:00	6	122
1846	12	127	94	14	83	174	379	56	5	502	153	533	209	1741	2004-02-28 00:00:00	12	43
1894	12	92	179	24	35	80	421	83	8	584	212	633	164	1785	2008-02-28 00:00:00	12	27
572	4	170	100	2	80	248	392	62	12	556	222	638	692	1734	2004-02-28 00:00:00	4	38
620	4	204	227	13	56	137	554	111	43	718	279	832	488	2121	2008-02-28 00:00:00	4	31
668	4	223	300	32	42	121	635	90	19	812	349	1001	580	2312	2012-02-28 00:00:00	4	27
170	1	3261	3958	342	575	1466	9705	1931	494	11593	4763	14052	6910	33297	2016-02-29 00:00:00	1	287
2354	13	218	391	21	58	112	698	105	46	811	442	1142	229	2316	2016-02-29 00:00:00	13	16
850	5	110	658	17	132	440	2122	195	6	2463	472	2178	3052	9658	2012-02-28 00:00:00	5	83
1482	9	316	122	10	131	254	463	237	10	610	256	478	175	2256	2004-02-28 00:00:00	9	23
1530	9	476	284	15	57	183	590	175	4	809	372	605	191	2241	2008-02-28 00:00:00	9	19
1623	9	356	390	48	43	127	818	206	80	975	466	1199	462	2997	2015-11-30 00:00:00	9	20
754	5	229	331	15	313	826	1505	106	8	2075	788	1860	2948	7108	2004-02-28 00:00:00	5	315
802	5	190	466	23	171	503	1639	176	17	2136	759	1944	2098	7788	2008-02-28 00:00:00	5	123
1624	9	418	440	50	52	128	856	191	39	1000	465	1255	451	2942	2015-12-31 00:00:00	9	18
1625	9	357	456	62	50	103	818	183	47	964	418	1168	489	2585	2016-01-31 00:00:00	9	24
1627	9	482	464	70	51	117	885	243	65	1035	550	1409	432	3112	2016-03-31 00:00:00	9	26
1628	9	445	493	48	60	111	916	228	61	1057	528	1416	423	3053	2016-04-30 00:00:00	9	24
1629	9	421	564	54	66	159	908	254	59	1067	623	1510	468	2969	2016-05-31 00:00:00	9	17
1630	9	435	569	65	63	132	910	214	70	1080	616	1506	466	3270	2016-06-30 00:00:00	9	19
1631	9	366	471	57	55	104	819	165	77	970	595	1393	423	2815	2016-07-31 00:00:00	9	20
1632	9	369	450	62	38	109	855	196	96	992	684	1504	448	3191	2016-08-31 00:00:00	9	27
1633	9	385	475	56	47	89	847	219	84	1023	529	1374	448	3156	2016-09-30 00:00:00	9	22
1634	9	419	456	62	48	119	861	190	60	1036	604	1442	394	3008	2016-10-31 00:00:00	9	24
390	3	148	74	25	62	164	291	23	15	395	209	389	89	1203	2004-02-28 00:00:00	3	21
438	3	159	121	34	28	77	275	22	20	336	286	406	70	1387	2008-02-28 00:00:00	3	12
2028	11	64	50	11	64	80	186	14	10	240	117	203	82	1095	2004-02-28 00:00:00	11	9
2076	11	73	76	3	49	45	200	16	17	248	244	251	66	1096	2008-02-28 00:00:00	11	7
1664	10	198	97	19	62	168	366	67	14	443	143	489	239	1461	2004-02-28 00:00:00	10	33
1712	10	199	182	36	35	73	409	71	15	495	210	610	181	1437	2008-02-28 00:00:00	10	18
2210	13	145	98	25	102	183	347	24	3	485	271	507	189	1582	2004-02-28 00:00:00	13	39
2258	13	138	169	19	53	132	407	44	17	537	378	734	140	1741	2008-02-28 00:00:00	13	19
2306	13	183	299	17	33	133	600	99	11	710	298	852	227	2011	2012-02-28 00:00:00	13	17
1300	8	66	22	10	42	59	83	11	9	119	92	136	21	544	2004-02-28 00:00:00	8	8
1348	8	101	41	25	27	34	119	3	3	167	99	170	16	755	2008-02-28 00:00:00	8	8
208	2	63	42	4	41	74	127	6	6	171	75	209	18	559	2004-02-28 00:00:00	2	7
256	2	66	69	15	32	46	165	15	5	201	122	287	23	693	2008-02-28 00:00:00	2	5
1118	7	231	99	13	110	208	376	39	10	518	210	523	321	1803	2004-02-28 00:00:00	7	47
1166	7	289	153	25	40	126	428	57	10	525	356	647	288	1801	2008-02-28 00:00:00	7	22
26	1	1843	1264	191	1272	2940	5430	849	110	7413	2872	7348	6558	25262	2004-02-28 00:00:00	1	766
157	1	1893	3441	340	522	1453	8836	1442	267	10751	3721	12356	8597	32744	2015-01-31 00:00:00	1	392
158	1	2280	3560	349	521	1381	8564	1538	323	10360	4513	12689	7465	32127	2015-02-28 00:00:00	1	339
703	4	178	344	43	53	124	756	108	22	918	289	1059	608	2461	2015-01-31 00:00:00	4	20
705	4	183	296	39	66	132	755	116	33	922	427	1203	565	2694	2015-03-31 00:00:00	4	22
706	4	182	322	31	46	106	753	98	29	880	356	1118	530	2562	2015-04-30 00:00:00	4	27
708	4	196	342	40	56	104	766	101	43	928	380	1162	530	3063	2015-06-30 00:00:00	4	29
709	4	179	360	47	49	108	714	130	52	869	346	1091	515	2719	2015-07-31 00:00:00	4	18
710	4	242	326	44	42	110	785	100	40	964	421	1215	489	2757	2015-08-31 00:00:00	4	20
1726	10	147	138	12	29	102	412	59	15	551	235	621	225	1313	2009-04-30 00:00:00	10	39
1727	10	132	125	22	27	94	382	45	21	466	170	550	317	1438	2009-05-31 00:00:00	10	20
1728	10	139	181	33	37	127	397	95	43	507	247	632	271	1393	2009-06-30 00:00:00	10	23
711	4	213	273	46	60	151	714	56	25	846	376	1091	480	2447	2015-09-30 00:00:00	4	16
534	3	162	249	48	35	82	496	111	36	587	324	820	150	1885	2016-02-29 00:00:00	3	14
885	5	155	431	33	94	413	2223	245	27	2675	626	2528	3405	8323	2015-01-31 00:00:00	5	102
712	4	217	297	44	35	97	695	66	40	813	388	1085	551	2487	2015-10-31 00:00:00	4	26
713	4	212	301	37	46	159	680	115	33	821	344	1040	541	2472	2015-11-30 00:00:00	4	23
714	4	169	282	39	36	92	688	150	28	851	275	943	499	2591	2015-12-31 00:00:00	4	27
725	4	162	327	47	40	120	703	102	26	848	339	1059	508	2534	2016-11-30 00:00:00	4	16
728	4	187	259	58	39	124	667	90	31	824	331	967	476	2464	2017-02-28 00:00:00	4	26
1635	9	375	473	64	39	103	839	158	65	949	519	1324	444	2982	2016-11-30 00:00:00	9	11
1636	9	340	453	45	40	110	782	160	39	895	503	1267	478	2812	2016-12-31 00:00:00	9	38
1637	9	363	554	56	43	93	819	176	37	938	508	1294	449	2742	2017-01-31 00:00:00	9	26
1638	9	372	498	53	52	120	820	164	48	962	514	1294	387	2820	2017-02-28 00:00:00	9	16
521	3	196	239	57	31	72	455	105	21	540	244	694	201	1775	2015-01-31 00:00:00	3	10
538	3	204	233	47	36	83	451	101	60	530	415	862	180	1883	2016-06-30 00:00:00	3	10
543	3	164	246	51	30	83	483	119	51	595	385	861	225	1948	2016-11-30 00:00:00	3	7
544	3	164	211	43	33	78	448	87	34	524	347	794	231	1737	2016-12-31 00:00:00	3	10
1721	10	89	99	28	19	83	314	34	9	386	173	475	271	1123	2008-11-30 00:00:00	10	26
1722	10	134	118	42	27	111	343	32	23	433	251	580	320	1286	2008-12-31 00:00:00	10	16
1723	10	204	159	29	29	99	457	41	27	561	319	760	335	1509	2009-01-31 00:00:00	10	17
1724	10	131	146	36	34	115	403	56	9	512	235	635	292	1333	2009-02-28 00:00:00	10	29
1725	10	104	133	17	30	100	404	50	22	485	248	638	302	1482	2009-03-31 00:00:00	10	26
1729	10	82	153	25	22	89	367	103	31	454	195	542	259	1333	2009-07-31 00:00:00	10	34
1730	10	114	120	22	40	137	411	87	33	525	245	626	235	1551	2009-08-31 00:00:00	10	25
1731	10	103	116	21	31	80	346	70	19	417	247	573	186	1397	2009-09-30 00:00:00	10	25
1732	10	106	142	32	32	112	383	78	23	576	321	698	422	1389	2009-10-31 00:00:00	10	26
1733	10	113	135	20	23	103	379	136	16	487	197	573	229	1465	2009-11-30 00:00:00	10	27
1734	10	99	170	23	31	112	412	100	18	490	228	631	223	1374	2009-12-31 00:00:00	10	26
1735	10	155	189	27	30	78	448	50	21	530	277	720	279	1436	2010-01-31 00:00:00	10	26
1067	6	67	360	54	71	245	1281	222	37	1701	587	2085	1978	6001	2015-01-31 00:00:00	6	103
1069	6	163	483	67	79	237	1479	293	47	1893	743	2357	1628	6012	2015-03-31 00:00:00	6	73
1070	6	164	464	45	70	239	1427	267	40	1752	712	2250	1441	5599	2015-04-30 00:00:00	6	98
1071	6	219	537	55	89	219	1494	312	50	1881	717	2396	1675	5802	2015-05-31 00:00:00	6	78
1072	6	208	552	51	70	199	1566	304	77	1954	691	2420	1442	5854	2015-06-30 00:00:00	6	54
1073	6	207	506	53	53	196	1584	274	51	1954	791	2539	1526	5630	2015-07-31 00:00:00	6	74
1074	6	247	487	57	64	302	1628	256	40	2022	757	2535	1435	5589	2015-08-31 00:00:00	6	106
1075	6	251	488	48	71	219	1591	270	65	2010	746	2470	1440	5746	2015-09-30 00:00:00	6	71
1076	6	253	433	37	74	252	1587	255	57	2060	837	2629	1661	5993	2015-10-31 00:00:00	6	75
1077	6	270	434	28	61	215	1478	283	70	1947	724	2363	1729	5537	2015-11-30 00:00:00	6	79
1078	6	249	363	39	75	274	1426	244	32	1773	581	2171	1799	5305	2015-12-31 00:00:00	6	92
1089	6	285	466	40	60	227	1461	331	55	1834	906	2488	1667	5593	2016-11-30 00:00:00	6	58
707	4	197	324	48	47	142	764	134	43	922	419	1199	588	2819	2015-05-31 00:00:00	4	16
715	4	155	305	34	42	118	717	132	33	887	310	1052	572	2232	2016-01-31 00:00:00	4	16
904	5	350	721	17	110	441	2854	328	14	3490	1196	3126	2929	10044	2016-08-31 00:00:00	5	66
905	5	346	633	15	121	377	2764	413	8	3339	1125	2987	2668	8810	2016-09-30 00:00:00	5	70
906	5	269	702	21	139	402	2834	363	3	3357	1246	3099	2992	8576	2016-10-31 00:00:00	5	63
907	5	263	657	23	106	359	2761	348	51	3294	1101	2995	2570	8872	2016-11-30 00:00:00	5	75
908	5	217	592	30	98	341	2342	368	8	2851	1129	2579	2732	8387	2016-12-31 00:00:00	5	88
724	4	188	305	29	39	113	768	87	29	932	348	1153	539	2614	2016-10-31 00:00:00	4	25
522	3	187	235	42	30	73	462	101	35	558	300	759	183	1915	2015-02-28 00:00:00	3	8
523	3	211	273	59	44	90	520	129	72	614	384	899	189	2082	2015-03-31 00:00:00	3	12
903	5	442	721	16	146	411	2952	326	25	3468	1117	3218	2721	9127	2016-07-31 00:00:00	5	74
524	3	223	311	79	39	124	513	133	67	638	332	845	173	2346	2015-04-30 00:00:00	3	15
525	3	183	253	38	41	87	487	104	55	593	322	804	179	1916	2015-05-31 00:00:00	3	5
526	3	227	253	63	38	82	530	107	35	614	396	923	169	2199	2015-06-30 00:00:00	3	10
527	3	195	292	48	37	73	557	122	31	684	338	890	137	1940	2015-07-31 00:00:00	3	12
528	3	196	268	64	30	63	512	120	32	585	384	894	172	2200	2015-08-31 00:00:00	3	13
529	3	195	240	55	33	77	505	90	50	586	379	879	177	1996	2015-09-30 00:00:00	3	8
530	3	200	233	48	38	100	531	96	53	626	462	992	154	1913	2015-10-31 00:00:00	3	9
531	3	176	234	42	30	68	489	97	40	579	354	837	163	1929	2015-11-30 00:00:00	3	10
532	3	185	204	47	31	73	469	104	30	553	320	788	166	1901	2015-12-31 00:00:00	3	13
1737	10	77	128	17	25	85	375	37	12	484	203	569	308	1312	2010-03-31 00:00:00	10	35
1738	10	83	120	20	31	103	343	40	26	422	262	602	226	1417	2010-04-30 00:00:00	10	39
1739	10	84	128	28	25	93	356	51	22	443	211	560	264	1495	2010-05-31 00:00:00	10	20
1740	10	70	133	20	37	114	374	50	28	451	151	520	250	1328	2010-06-30 00:00:00	10	12
1741	10	84	136	17	21	65	319	60	25	408	220	533	265	1266	2010-07-31 00:00:00	10	11
1742	10	102	137	31	32	91	372	65	26	501	171	544	261	1404	2010-08-31 00:00:00	10	9
1743	10	129	150	23	25	80	355	73	27	417	204	552	302	1424	2010-09-30 00:00:00	10	14
1744	10	96	146	25	32	89	347	76	30	413	146	495	285	1373	2010-10-31 00:00:00	10	19
1745	10	90	126	15	25	117	369	68	36	466	210	577	274	1394	2010-11-30 00:00:00	10	35
1746	10	152	125	18	34	86	371	65	24	463	222	597	259	1318	2010-12-31 00:00:00	10	20
1747	10	266	194	25	33	93	488	72	24	565	263	746	288	1726	2011-01-31 00:00:00	10	28
1748	10	144	167	26	27	83	431	53	28	546	199	598	271	1761	2011-02-28 00:00:00	10	29
1749	10	131	162	20	24	92	436	52	27	510	213	641	271	1525	2011-03-31 00:00:00	10	26
1750	10	137	133	26	28	62	382	41	22	467	157	530	272	1470	2011-04-30 00:00:00	10	36
1751	10	134	184	20	39	139	408	67	16	479	272	669	287	1680	2011-05-31 00:00:00	10	25
1752	10	105	161	6	24	110	382	59	26	451	188	565	230	1430	2011-06-30 00:00:00	10	11
1753	10	94	173	21	33	74	351	76	36	428	232	579	256	1391	2011-07-31 00:00:00	10	20
1754	10	100	152	18	22	97	389	57	28	489	213	594	256	1470	2011-08-31 00:00:00	10	16
1755	10	143	174	18	34	92	399	58	25	503	261	658	231	1572	2011-09-30 00:00:00	10	14
1756	10	122	153	9	34	90	390	92	25	492	174	558	234	1527	2011-10-31 00:00:00	10	18
1757	10	157	158	28	25	72	449	71	20	502	267	705	230	1485	2011-11-30 00:00:00	10	24
1758	10	149	145	37	22	82	399	67	19	488	223	606	258	1401	2011-12-31 00:00:00	10	19
1759	10	327	210	37	33	111	558	90	20	648	233	763	318	1615	2012-01-31 00:00:00	10	30
1760	10	174	198	33	23	91	478	126	30	579	280	751	288	1689	2012-02-28 00:00:00	10	17
1761	10	137	181	23	28	95	475	94	21	577	146	615	313	1811	2012-03-31 00:00:00	10	19
1762	10	142	189	29	42	97	488	92	28	592	210	694	327	1741	2012-04-30 00:00:00	10	29
1763	10	151	173	29	44	95	433	121	32	553	209	638	256	1803	2012-05-31 00:00:00	10	25
1764	10	119	196	34	26	71	411	103	26	510	222	624	208	1665	2012-06-30 00:00:00	10	16
1765	10	111	198	46	30	84	431	84	45	542	234	649	217	1565	2012-07-31 00:00:00	10	20
1766	10	123	170	26	40	89	436	109	42	546	207	642	277	1728	2012-08-31 00:00:00	10	19
1767	10	137	188	28	38	79	420	109	11	508	170	587	282	1654	2012-09-30 00:00:00	10	24
1768	10	157	202	34	32	79	482	132	17	596	239	718	250	1801	2012-10-31 00:00:00	10	35
1431	8	117	105	17	14	24	233	32	6	279	139	346	42	988	2015-01-31 00:00:00	8	8
1433	8	95	108	11	23	65	232	49	26	271	179	369	30	1118	2015-03-31 00:00:00	8	3
1434	8	105	92	11	16	30	215	24	17	247	198	340	35	1080	2015-04-30 00:00:00	8	3
1435	8	108	129	15	25	38	246	39	27	296	199	425	49	1126	2015-05-31 00:00:00	8	7
1436	8	126	120	8	13	17	238	29	38	275	250	451	35	1034	2015-06-30 00:00:00	8	3
1437	8	117	113	8	20	35	217	35	41	265	271	453	42	969	2015-07-31 00:00:00	8	4
1438	8	126	119	29	19	32	251	39	24	289	268	491	46	1116	2015-08-31 00:00:00	8	1
1439	8	121	92	14	11	39	230	27	20	285	213	420	37	1035	2015-09-30 00:00:00	8	4
1613	9	372	468	48	48	103	878	159	45	1032	417	1227	477	2839	2015-01-31 00:00:00	9	26
1769	10	161	175	25	35	119	420	136	12	572	228	644	266	1541	2012-11-30 00:00:00	10	26
1770	10	156	164	28	24	82	432	79	26	540	167	598	319	1587	2012-12-31 00:00:00	10	30
1771	10	224	243	33	44	119	652	117	29	785	203	851	287	2066	2013-01-31 00:00:00	10	26
1772	10	164	184	29	34	93	569	119	31	690	203	767	284	1819	2013-02-28 00:00:00	10	24
1440	8	122	110	9	12	32	215	39	28	245	256	445	40	1000	2015-10-31 00:00:00	8	7
1441	8	159	111	11	15	32	228	34	19	272	226	431	38	1002	2015-11-30 00:00:00	8	8
1254	7	224	416	32	41	122	667	162	65	799	447	1174	488	2353	2015-06-30 00:00:00	7	22
1255	7	235	445	40	37	128	718	125	51	851	421	1209	612	2416	2015-07-31 00:00:00	7	18
1256	7	229	425	36	37	132	649	149	57	803	455	1177	547	2841	2015-08-31 00:00:00	7	23
1257	7	236	421	14	49	125	718	137	71	879	385	1207	497	2316	2015-09-30 00:00:00	7	17
1258	7	193	360	19	54	121	635	157	70	785	412	1104	571	2341	2015-10-31 00:00:00	7	23
1259	7	209	418	24	38	87	654	126	48	760	362	1078	499	2453	2015-11-30 00:00:00	7	15
1260	7	269	391	19	44	92	655	166	43	813	334	1042	573	2353	2015-12-31 00:00:00	7	15
1263	7	304	382	32	47	132	715	164	77	864	529	1284	561	2533	2016-03-31 00:00:00	7	16
1264	7	285	407	49	44	140	714	178	59	857	392	1162	536	2309	2016-04-30 00:00:00	7	25
1265	7	312	404	24	43	95	650	181	56	788	515	1234	516	2349	2016-05-31 00:00:00	7	26
1266	7	283	450	28	61	129	678	179	88	818	510	1230	556	2385	2016-06-30 00:00:00	7	15
1267	7	227	346	21	44	100	641	132	72	764	450	1139	486	2278	2016-07-31 00:00:00	7	15
1272	7	186	364	48	44	96	659	104	53	795	328	1024	594	2260	2016-12-31 00:00:00	7	18
2159	11	95	201	4	24	54	316	79	15	394	197	482	136	1414	2015-01-31 00:00:00	11	10
2161	11	121	219	3	32	49	346	76	41	445	321	601	134	1558	2015-03-31 00:00:00	11	8
2163	11	92	210	4	15	39	325	53	42	402	294	552	98	1684	2015-05-31 00:00:00	11	7
2164	11	102	236	7	25	54	305	93	29	368	350	591	135	1647	2015-06-30 00:00:00	11	4
2165	11	96	218	4	21	34	298	75	27	373	290	576	137	1533	2015-07-31 00:00:00	11	7
2166	11	152	226	6	36	69	314	98	43	376	350	660	132	1717	2015-08-31 00:00:00	11	5
2167	11	128	200	2	29	41	280	76	26	349	361	624	146	1738	2015-09-30 00:00:00	11	7
2168	11	83	189	3	26	73	300	54	26	376	285	576	83	1462	2015-10-31 00:00:00	11	9
2169	11	112	180	5	16	32	300	66	26	363	309	512	143	1419	2015-11-30 00:00:00	11	5
2170	11	88	180	4	21	39	285	69	29	350	279	476	135	1383	2015-12-31 00:00:00	11	5
2177	11	102	196	6	23	42	293	47	32	375	300	508	132	1624	2016-07-31 00:00:00	11	6
2178	11	121	194	5	32	55	285	83	39	349	370	611	124	1654	2016-08-31 00:00:00	11	10
2179	11	120	169	6	31	56	320	50	66	381	333	630	128	1475	2016-09-30 00:00:00	11	12
2180	11	104	161	9	32	39	282	70	34	340	327	584	120	1478	2016-10-31 00:00:00	11	15
2181	11	76	153	4	23	49	235	38	33	286	288	533	131	1441	2016-11-30 00:00:00	11	8
1773	10	108	133	38	34	61	460	95	33	569	207	665	312	1647	2013-03-31 00:00:00	10	19
1774	10	132	144	27	32	93	452	73	33	533	202	652	246	1863	2013-04-30 00:00:00	10	16
1775	10	133	185	18	46	96	503	79	33	573	246	748	256	1718	2013-05-31 00:00:00	10	24
1776	10	123	159	37	33	81	508	87	29	609	208	713	267	1792	2013-06-30 00:00:00	10	16
1777	10	106	176	30	26	78	446	73	13	528	155	600	349	1482	2013-07-31 00:00:00	10	20
1778	10	112	180	38	38	115	472	72	16	548	156	617	274	1732	2013-08-31 00:00:00	10	19
1779	10	129	142	33	42	106	448	66	28	523	247	847	267	1625	2013-09-30 00:00:00	10	28
1780	10	133	146	36	32	101	478	74	17	569	285	755	286	1551	2013-10-31 00:00:00	10	20
1781	10	106	161	26	36	129	442	92	28	515	183	749	288	1530	2013-11-30 00:00:00	10	21
1782	10	122	141	33	35	90	532	79	13	606	169	695	345	1385	2013-12-31 00:00:00	10	23
1783	10	179	162	30	33	98	593	97	27	732	178	762	367	1778	2014-01-31 00:00:00	10	24
1784	10	90	152	27	28	74	462	60	15	568	175	614	427	1572	2014-02-28 00:00:00	10	19
1785	10	78	158	28	39	106	526	93	13	640	206	725	404	1618	2014-03-31 00:00:00	10	24
1786	10	80	139	23	35	93	459	105	21	537	212	668	302	1621	2014-04-30 00:00:00	10	13
1787	10	74	156	34	43	91	433	116	31	525	182	614	390	1503	2014-05-31 00:00:00	10	22
1788	10	90	158	29	36	79	460	117	16	561	178	561	288	1490	2014-06-30 00:00:00	10	17
1789	10	108	188	32	26	80	473	131	35	642	256	735	277	1531	2014-07-31 00:00:00	10	18
1790	10	115	159	36	29	78	451	97	26	578	345	792	335	1709	2014-08-31 00:00:00	10	16
1791	10	113	195	39	33	90	449	135	14	567	311	747	349	1599	2014-09-30 00:00:00	10	12
2341	13	151	320	9	31	95	698	78	21	829	310	1024	239	2112	2015-01-31 00:00:00	13	15
2343	13	232	355	23	31	105	688	91	38	818	494	1193	261	2436	2015-03-31 00:00:00	13	24
2344	13	197	355	28	26	101	683	92	41	803	432	1121	275	2419	2015-04-30 00:00:00	13	16
2345	13	221	380	35	47	134	766	97	38	887	487	1259	275	2460	2015-05-31 00:00:00	13	23
2346	13	220	368	33	56	150	808	109	51	952	430	1298	261	2391	2015-06-30 00:00:00	13	19
2348	13	231	380	19	37	104	768	95	37	897	506	1293	219	2467	2015-08-31 00:00:00	13	21
2349	13	212	320	21	47	125	754	79	48	885	476	1254	235	2462	2015-09-30 00:00:00	13	23
2350	13	221	371	17	41	109	674	80	36	775	460	1156	275	2202	2015-10-31 00:00:00	13	19
2351	13	209	333	22	51	118	675	90	36	804	378	1059	224	2204	2015-11-30 00:00:00	13	14
2352	13	191	308	26	27	87	661	92	31	773	357	1041	272	2220	2015-12-31 00:00:00	13	12
1	1	1881	847	194	1499	3249	6208	719	100	7644	2268	7780	7753	24690	2002-01-31 00:00:00	1	1090
1008	6	72	323	19	90	302	945	155	18	1272	464	1506	1138	5028	2010-02-28 00:00:00	6	111
1918	12	90	169	18	24	61	422	71	1	528	264	686	227	1896	2010-02-28 00:00:00	12	34
1736	10	116	154	24	24	69	365	52	16	475	201	560	264	1243	2010-02-28 00:00:00	10	23
1792	10	101	186	31	28	75	509	103	26	585	235	758	364	1812	2014-10-31 00:00:00	10	21
1793	10	85	143	29	28	91	456	83	16	572	235	684	377	1228	2014-11-30 00:00:00	10	19
1794	10	74	130	21	23	97	436	73	12	511	182	613	415	1336	2014-12-31 00:00:00	10	14
1795	10	108	159	28	38	71	598	77	20	707	252	821	571	1742	2015-01-31 00:00:00	10	23
1796	10	106	147	14	23	88	507	79	7	570	245	733	285	1448	2015-02-28 00:00:00	10	20
1797	10	147	178	33	25	91	491	87	16	609	283	786	275	1376	2015-03-31 00:00:00	10	18
1798	10	103	138	17	39	90	502	90	16	590	297	796	287	1538	2015-04-30 00:00:00	10	12
352	2	59	144	1	14	30	209	46	21	241	152	361	53	870	2016-02-29 00:00:00	2	6
1262	7	251	430	30	45	91	670	195	62	811	389	1145	611	2374	2016-02-29 00:00:00	7	18
1444	8	139	101	11	11	22	206	38	40	253	207	395	52	991	2016-02-29 00:00:00	8	3
1626	9	423	461	63	63	138	796	195	66	931	446	1210	460	2797	2016-02-29 00:00:00	9	19
1990	12	151	281	17	59	93	560	138	25	663	259	818	265	2118	2016-02-29 00:00:00	12	29
898	5	874	751	39	106	353	2893	439	34	3389	885	3125	2587	8594	2016-02-29 00:00:00	5	86
1799	10	110	176	24	40	102	521	121	16	620	192	715	294	1526	2015-05-31 00:00:00	10	11
747	5	250	269	17	332	1033	1644	229	20	2222	922	2116	3217	8370	2003-07-31 00:00:00	5	367
1800	10	135	165	38	36	106	558	81	31	631	328	883	275	1685	2015-06-30 00:00:00	10	16
1190	7	377	249	23	42	97	478	85	21	623	270	723	434	1973	2010-02-28 00:00:00	7	13
2358	13	216	331	14	35	73	678	110	61	809	601	1273	229	2518	2016-06-30 00:00:00	13	15
1801	10	166	176	32	22	98	477	78	28	584	294	754	266	1597	2015-07-31 00:00:00	10	15
748	5	305	286	18	378	1069	1743	178	20	2457	705	2074	3503	7627	2003-08-31 00:00:00	5	413
749	5	280	286	16	353	1121	1777	153	23	2370	824	2237	3355	7926	2003-09-30 00:00:00	5	346
750	5	282	272	17	351	1064	1724	167	40	2397	803	2150	3485	8585	2003-10-31 00:00:00	5	348
751	5	279	271	14	326	1086	1547	120	16	2143	904	1939	3007	7725	2003-11-30 00:00:00	5	337
752	5	241	236	21	303	897	1570	76	14	2020	806	1941	2876	7932	2003-12-31 00:00:00	5	341
755	5	307	281	6	333	1084	1730	124	22	2347	920	2166	3232	8671	2004-03-31 00:00:00	5	317
756	5	344	305	16	361	953	1698	146	25	2271	822	2111	3227	7751	2004-04-30 00:00:00	5	322
758	5	264	293	25	280	891	1589	146	10	2065	956	2060	3168	8442	2004-06-30 00:00:00	5	330
1802	10	188	168	23	40	80	572	113	39	726	317	874	237	1618	2015-08-31 00:00:00	10	22
1803	10	225	141	20	39	85	512	101	34	592	331	832	277	1659	2015-09-30 00:00:00	10	10
1804	10	208	148	18	35	91	467	115	30	568	352	820	280	1541	2015-10-31 00:00:00	10	17
3	1	1729	888	203	1442	3094	5561	714	168	7277	3007	7491	7743	24541	2002-03-31 00:00:00	1	1264
4	1	1648	1032	199	1560	3436	5919	730	142	7659	3311	8165	8096	28266	2002-04-30 00:00:00	1	1140
1805	10	151	142	23	27	74	474	92	40	575	350	822	322	1423	2015-11-30 00:00:00	10	13
1806	10	193	170	28	31	87	559	123	38	658	319	853	390	1481	2015-12-31 00:00:00	10	18
1807	10	267	208	27	52	109	632	127	44	738	347	979	326	1719	2016-01-31 00:00:00	10	13
1809	10	219	160	41	26	97	584	123	34	672	431	1018	323	1734	2016-03-31 00:00:00	10	14
1810	10	202	136	23	34	84	536	109	32	646	324	854	340	2144	2016-04-30 00:00:00	10	18
1811	10	248	151	27	35	97	490	115	47	588	353	836	314	1684	2016-05-31 00:00:00	10	14
1812	10	229	163	32	36	105	496	124	36	613	363	868	262	1501	2016-06-30 00:00:00	10	10
1813	10	232	142	28	40	94	508	101	29	643	400	911	239	1481	2016-07-31 00:00:00	10	14
1814	10	280	129	29	20	93	502	78	32	616	361	864	252	1395	2016-08-31 00:00:00	10	17
1815	10	279	142	30	29	79	458	102	30	539	316	770	282	1393	2016-09-30 00:00:00	10	17
1816	10	306	177	33	22	61	535	137	21	585	323	844	267	1474	2016-10-31 00:00:00	10	19
1817	10	251	137	23	29	68	476	90	26	550	347	794	264	1326	2016-11-30 00:00:00	10	11
1818	10	313	188	40	37	74	544	95	18	639	321	871	341	1483	2016-12-31 00:00:00	10	20
1819	10	398	241	33	31	75	616	118	26	722	374	987	359	1669	2017-01-31 00:00:00	10	17
1820	10	368	183	35	26	80	513	119	24	614	378	891	308	1498	2017-02-28 00:00:00	10	16
2186	13	143	74	16	140	232	406	19	6	534	205	582	184	1461	2002-02-28 00:00:00	13	34
2192	13	160	80	26	112	184	357	13	6	472	336	608	191	1825	2002-08-31 00:00:00	13	27
2193	13	146	85	41	123	191	373	10	8	469	304	615	221	1787	2002-09-30 00:00:00	13	41
2194	13	125	79	14	109	237	388	17	0	520	352	672	201	1790	2002-10-31 00:00:00	13	39
2195	13	159	64	37	115	201	412	20	1	536	333	684	202	1676	2002-11-30 00:00:00	13	39
2197	13	123	64	24	105	162	380	18	5	480	299	612	170	1624	2003-01-31 00:00:00	13	38
2198	13	138	72	19	126	183	383	19	8	526	318	670	184	1700	2003-02-28 00:00:00	13	33
2199	13	165	73	21	148	231	460	22	9	615	376	795	230	1733	2003-03-31 00:00:00	13	46
2200	13	151	81	17	115	190	454	16	6	586	322	749	189	1828	2003-04-30 00:00:00	13	48
2201	13	128	94	16	126	233	445	31	1	590	428	823	215	1911	2003-05-31 00:00:00	13	43
2202	13	118	82	20	117	214	402	20	4	545	381	737	223	1757	2003-06-30 00:00:00	13	34
2203	13	167	79	21	93	212	395	15	3	551	324	698	185	1722	2003-07-31 00:00:00	13	36
2204	13	129	69	30	107	207	387	22	3	510	337	714	196	2068	2003-08-31 00:00:00	13	45
2205	13	153	83	18	112	201	396	19	14	534	358	698	180	1853	2003-09-30 00:00:00	13	50
2206	13	153	82	26	122	212	401	15	5	510	310	686	201	2064	2003-10-31 00:00:00	13	39
2207	13	146	78	21	84	198	353	30	13	479	303	624	184	1747	2003-11-30 00:00:00	13	28
2208	13	122	81	10	101	193	366	17	9	536	263	654	174	1503	2003-12-31 00:00:00	13	41
2209	13	158	78	22	77	185	329	21	3	429	268	433	136	1375	2004-01-31 00:00:00	13	38
2211	13	135	96	30	104	214	369	28	6	507	381	606	182	1789	2004-03-31 00:00:00	13	30
2212	13	159	93	29	95	175	388	24	3	514	323	592	199	1817	2004-04-30 00:00:00	13	26
2213	13	166	109	20	99	189	385	28	4	520	344	602	168	1806	2004-05-31 00:00:00	13	34
2214	13	148	83	20	96	192	344	34	7	469	249	485	199	1626	2004-06-30 00:00:00	13	34
2215	13	107	86	26	87	168	321	13	3	423	240	457	186	1415	2004-07-31 00:00:00	13	38
2216	13	126	112	25	98	199	379	26	18	491	288	591	211	1585	2004-08-31 00:00:00	13	42
2217	13	129	77	16	105	190	336	15	3	436	184	462	197	1481	2004-09-30 00:00:00	13	44
2218	13	157	101	18	113	249	368	15	8	490	227	515	192	1678	2004-10-31 00:00:00	13	32
2219	13	127	96	27	107	220	371	11	7	480	341	542	160	1673	2004-11-30 00:00:00	13	32
2220	13	129	98	18	101	223	343	25	8	440	199	465	183	1522	2004-12-31 00:00:00	13	30
2221	13	112	73	17	104	165	312	32	3	426	264	531	175	1260	2005-01-31 00:00:00	13	38
2222	13	122	106	15	100	169	358	29	3	523	210	518	196	1504	2005-02-28 00:00:00	13	44
2223	13	136	76	40	93	165	368	35	12	469	290	555	210	1580	2005-03-31 00:00:00	13	34
2224	13	124	86	17	92	177	355	24	1	491	284	574	200	1512	2005-04-30 00:00:00	13	34
2225	13	161	104	24	95	166	418	51	5	570	296	638	200	1610	2005-05-31 00:00:00	13	30
2226	13	137	122	27	83	158	333	35	6	498	341	555	173	1682	2005-06-30 00:00:00	13	33
2227	13	153	116	18	80	191	347	42	1	448	318	585	174	1420	2005-07-31 00:00:00	13	28
2228	13	149	127	28	79	165	369	38	14	490	321	566	174	1716	2005-08-31 00:00:00	13	37
2230	13	157	114	19	70	178	354	36	6	462	210	477	174	1559	2005-10-31 00:00:00	13	24
2231	13	124	111	27	84	150	324	46	1	424	248	457	192	1404	2005-11-30 00:00:00	13	16
2232	13	144	131	18	83	151	360	36	0	497	225	485	179	1315	2005-12-31 00:00:00	13	42
2233	13	136	138	27	73	165	303	44	5	381	283	467	142	1311	2006-01-31 00:00:00	13	24
2234	13	169	130	26	73	144	372	39	5	510	275	540	141	1448	2006-02-28 00:00:00	13	32
2235	13	152	130	30	81	118	347	55	10	430	277	515	175	1691	2006-03-31 00:00:00	13	33
2236	13	109	139	19	77	151	372	33	3	512	306	538	189	1492	2006-04-30 00:00:00	13	33
2237	13	140	125	17	80	167	360	37	6	455	289	515	165	1600	2006-05-31 00:00:00	13	51
2238	13	125	151	23	65	139	328	54	2	414	262	467	150	1488	2006-06-30 00:00:00	13	31
2239	13	122	133	16	79	129	322	24	5	419	307	519	146	1217	2006-07-31 00:00:00	13	24
2240	13	113	150	17	87	152	384	40	5	506	431	610	138	1620	2006-08-31 00:00:00	13	33
2241	13	133	140	18	78	162	325	24	16	435	216	441	157	1433	2006-09-30 00:00:00	13	24
2242	13	120	152	20	72	143	398	33	5	518	256	527	164	1746	2006-10-31 00:00:00	13	22
2243	13	149	133	26	57	145	369	39	6	475	294	569	132	1668	2006-11-30 00:00:00	13	21
2244	13	140	135	22	65	124	365	25	7	469	222	474	133	1480	2006-12-31 00:00:00	13	25
2245	13	132	168	39	55	102	413	40	10	531	309	602	155	1634	2007-01-31 00:00:00	13	27
2246	13	143	172	32	78	175	406	43	12	511	242	564	143	1695	2007-02-28 00:00:00	13	18
2247	13	155	176	30	83	151	465	39	12	592	465	764	150	1849	2007-03-31 00:00:00	13	26
2248	13	165	184	25	68	140	401	58	8	536	405	727	149	1690	2007-04-30 00:00:00	13	26
2249	13	152	172	29	82	172	420	31	13	542	466	808	164	1871	2007-05-31 00:00:00	13	26
2250	13	122	163	32	71	147	406	43	6	522	410	730	184	1720	2007-06-30 00:00:00	13	26
2251	13	102	144	19	52	110	357	38	7	453	321	614	132	1483	2007-07-31 00:00:00	13	20
2252	13	141	175	18	66	133	406	36	14	517	455	797	155	1710	2007-08-31 00:00:00	13	20
2253	13	128	154	27	72	175	414	28	11	556	420	737	139	1791	2007-09-30 00:00:00	13	16
2254	13	141	159	32	64	142	376	19	7	485	513	802	139	1800	2007-10-31 00:00:00	13	36
2255	13	173	178	22	91	147	394	27	10	486	443	776	125	1717	2007-11-30 00:00:00	13	19
2256	13	141	164	36	52	114	354	32	4	458	303	664	144	1506	2007-12-31 00:00:00	13	16
2257	13	122	186	33	45	135	364	38	9	478	313	621	150	1536	2008-01-31 00:00:00	13	25
2259	13	152	191	26	62	131	416	40	19	557	425	772	159	1770	2008-03-31 00:00:00	13	28
2260	13	145	168	20	62	135	395	29	8	1101	445	788	143	1846	2008-04-30 00:00:00	13	16
2261	13	129	179	42	67	144	424	33	7	553	403	807	141	1719	2008-05-31 00:00:00	13	28
2262	13	131	182	47	49	100	384	35	10	489	409	739	167	1712	2008-06-30 00:00:00	13	23
2263	13	148	179	37	43	146	445	35	16	551	466	846	130	1827	2008-07-31 00:00:00	13	22
2264	13	122	162	44	45	116	424	28	12	529	661	1039	126	1787	2008-08-31 00:00:00	13	17
2265	13	101	125	29	27	81	372	26	14	435	635	957	118	1546	2008-09-30 00:00:00	13	22
2266	13	88	96	30	35	109	313	27	6	366	325	600	158	1141	2008-10-31 00:00:00	13	17
2267	13	130	115	28	46	96	348	31	5	435	377	679	161	1415	2008-11-30 00:00:00	13	28
2268	13	123	138	28	32	113	371	35	10	440	452	774	138	1562	2008-12-31 00:00:00	13	32
2269	13	161	144	52	49	131	465	43	7	567	345	776	184	1502	2009-01-31 00:00:00	13	31
2270	13	221	190	45	61	108	545	36	20	680	387	904	189	1773	2009-02-28 00:00:00	13	24
2271	13	183	213	41	57	152	564	34	26	681	512	1028	196	2056	2009-03-31 00:00:00	13	26
2272	13	177	181	36	51	109	491	29	21	581	437	874	206	1931	2009-04-30 00:00:00	13	24
2273	13	169	155	25	53	141	475	46	13	664	402	806	220	2093	2009-05-31 00:00:00	13	33
2274	13	149	162	14	41	116	474	39	16	575	389	872	219	1814	2009-06-30 00:00:00	13	20
2275	13	123	181	29	47	110	481	31	9	598	423	819	177	1841	2009-07-31 00:00:00	13	20
2276	13	150	186	38	51	150	499	45	24	610	417	842	201	2036	2009-08-31 00:00:00	13	20
2277	13	154	194	41	39	92	476	61	16	554	349	807	190	2061	2009-09-30 00:00:00	13	27
2278	13	154	218	48	57	127	510	50	20	610	506	909	204	2027	2009-10-31 00:00:00	13	23
2279	13	168	151	47	46	127	472	37	19	568	421	789	230	1895	2009-11-30 00:00:00	13	29
2280	13	149	159	34	52	140	438	25	6	560	340	749	175	1896	2009-12-31 00:00:00	13	20
2281	13	179	195	23	54	108	443	40	16	545	314	723	213	1568	2010-01-31 00:00:00	13	24
2282	13	167	202	23	53	108	521	33	13	639	294	796	200	1862	2010-02-28 00:00:00	13	18
2283	13	163	207	17	54	96	521	47	15	668	412	873	205	2183	2010-03-31 00:00:00	13	31
2284	13	124	208	23	49	116	492	49	18	606	383	823	196	2127	2010-04-30 00:00:00	13	24
2285	13	137	202	25	38	98	475	39	13	571	341	737	217	2010	2010-05-31 00:00:00	13	23
2286	13	149	204	22	35	129	453	55	15	542	270	646	189	1785	2010-06-30 00:00:00	13	18
2287	13	98	234	15	40	80	509	55	3	586	314	798	188	1702	2010-07-31 00:00:00	13	18
2288	13	164	217	22	40	82	481	46	9	621	424	807	174	2012	2010-08-31 00:00:00	13	19
2289	13	161	210	22	47	103	449	41	11	541	334	716	171	1747	2010-09-30 00:00:00	13	13
2290	13	225	180	15	49	97	437	54	11	527	252	638	203	1667	2010-10-31 00:00:00	13	17
2291	13	172	216	28	54	121	502	67	13	599	333	746	178	1734	2010-11-30 00:00:00	13	19
759	5	233	285	20	286	906	1539	109	8	2105	849	1945	3240	8279	2004-07-31 00:00:00	5	304
760	5	278	287	24	327	846	1667	140	16	2255	885	1978	3410	8642	2004-08-31 00:00:00	5	269
762	5	231	283	15	269	829	1495	120	21	2118	719	1709	3243	8025	2004-10-31 00:00:00	5	279
763	5	248	279	21	293	977	1618	126	30	2173	715	1900	3209	8297	2004-11-30 00:00:00	5	234
764	5	229	205	25	252	1055	1545	142	19	2084	736	1794	3075	8320	2004-12-31 00:00:00	5	290
767	5	250	284	30	291	880	1647	198	13	2239	726	1893	3187	8192	2005-03-31 00:00:00	5	237
768	5	213	247	45	295	853	1614	215	17	2219	819	1834	3056	7678	2005-04-30 00:00:00	5	224
769	5	198	259	15	241	849	1592	172	12	2148	690	1844	3118	7976	2005-05-31 00:00:00	5	241
770	5	206	273	17	245	1216	1542	197	6	2100	908	1797	3296	8647	2005-06-30 00:00:00	5	219
771	5	206	229	23	243	831	1512	171	17	2008	757	1713	3120	7857	2005-07-31 00:00:00	5	210
772	5	237	289	22	269	1350	1646	216	18	2171	939	1896	3047	8434	2005-08-31 00:00:00	5	227
773	5	236	321	14	257	718	1563	265	28	2086	699	1804	3090	8109	2005-09-30 00:00:00	5	179
774	5	202	331	19	268	857	1573	216	18	2121	644	1805	3120	8453	2005-10-31 00:00:00	5	206
779	5	268	345	25	285	750	1662	252	20	2132	661	1844	2963	8476	2006-03-31 00:00:00	5	208
780	5	258	308	23	224	650	1501	192	3	2044	642	1710	2926	7842	2006-04-30 00:00:00	5	199
781	5	196	323	19	202	763	1408	182	4	1853	775	1662	2565	8334	2006-05-31 00:00:00	5	252
782	5	169	291	35	192	601	1395	187	8	1860	638	1589	2568	7613	2006-06-30 00:00:00	5	181
783	5	180	278	21	204	649	1459	136	11	1991	730	1667	2499	7787	2006-07-31 00:00:00	5	181
784	5	264	337	24	183	680	1531	164	14	1979	851	1832	2447	8187	2006-08-31 00:00:00	5	203
785	5	212	308	31	197	574	1434	167	9	1895	579	1658	2496	7936	2006-09-30 00:00:00	5	133
790	5	223	298	21	187	609	1571	144	20	2031	757	1812	2295	8321	2007-02-28 00:00:00	5	156
791	5	340	446	26	208	631	1799	194	23	2266	955	2171	2703	8932	2007-03-31 00:00:00	5	130
792	5	257	400	26	206	562	1627	195	17	2127	798	1946	2618	8366	2007-04-30 00:00:00	5	151
793	5	223	431	22	183	667	1708	201	20	2227	848	2060	2671	9937	2007-05-31 00:00:00	5	140
794	5	248	476	40	189	570	1675	204	11	2196	970	2065	2486	9422	2007-06-30 00:00:00	5	120
795	5	227	361	32	184	610	1528	151	10	1983	768	1819	2457	8440	2007-07-31 00:00:00	5	118
796	5	253	442	30	211	652	1750	182	9	2248	820	2041	2655	8810	2007-08-31 00:00:00	5	148
797	5	261	406	26	193	519	1573	185	11	2259	735	1817	2320	8032	2007-09-30 00:00:00	5	144
800	5	165	354	39	174	527	1437	169	11	1990	449	1700	1959	7366	2007-12-31 00:00:00	5	140
803	5	264	506	20	180	516	1700	176	9	2215	865	2021	2403	7507	2008-03-31 00:00:00	5	116
804	5	240	557	28	169	525	1750	137	19	2414	933	2080	2338	8121	2008-04-30 00:00:00	5	85
805	5	201	490	24	147	487	1614	146	12	2344	813	1955	2415	6983	2008-05-31 00:00:00	5	131
806	5	219	478	10	120	490	1615	138	13	2208	828	1988	2240	8050	2008-06-30 00:00:00	5	103
807	5	200	463	24	132	534	1741	128	4	2417	846	2073	2181	8351	2008-07-31 00:00:00	5	111
808	5	250	480	30	135	498	1719	131	13	2383	817	2018	2157	7653	2008-08-31 00:00:00	5	105
809	5	221	618	18	133	498	1795	166	7	2433	587	2149	2080	7834	2008-09-30 00:00:00	5	101
810	5	156	460	12	140	573	1651	182	4	2110	504	1963	2357	7031	2008-10-31 00:00:00	5	106
811	5	144	458	37	144	496	1562	182	5	2007	554	1874	2215	6490	2008-11-30 00:00:00	5	127
812	5	192	397	18	115	480	1511	180	18	1932	495	1807	2094	6659	2008-12-31 00:00:00	5	117
814	5	191	371	19	176	559	1758	155	21	2244	525	2011	2568	7236	2009-02-28 00:00:00	5	96
815	5	205	437	25	150	679	1888	179	37	2419	640	2183	2845	8113	2009-03-31 00:00:00	5	120
816	5	223	429	21	160	619	1832	150	18	2358	669	2137	2746	7997	2009-04-30 00:00:00	5	120
817	5	201	476	18	190	579	1947	136	27	2504	644	2253	2902	8644	2009-05-31 00:00:00	5	125
818	5	147	462	18	135	625	1842	190	12	2322	741	2181	2814	7773	2009-06-30 00:00:00	5	92
819	5	156	473	24	154	588	1789	166	14	2467	754	2112	2768	7768	2009-07-31 00:00:00	5	97
820	5	160	522	29	156	544	1873	203	19	2537	799	2244	2710	7865	2009-08-31 00:00:00	5	97
821	5	154	476	27	136	478	1877	224	20	2354	681	2199	2632	7872	2009-09-30 00:00:00	5	97
822	5	190	638	15	163	548	2039	196	19	2580	923	2581	2607	8272	2009-10-31 00:00:00	5	114
823	5	174	484	26	144	543	1831	195	31	2617	700	2189	2347	8371	2009-11-30 00:00:00	5	116
824	5	130	439	21	146	447	1808	172	20	2464	554	2164	2287	8123	2009-12-31 00:00:00	5	117
826	5	123	420	21	125	519	1597	145	13	2269	687	1916	2290	7555	2010-02-28 00:00:00	5	130
827	5	125	494	27	159	593	1873	183	28	2514	739	2224	2760	8321	2010-03-31 00:00:00	5	137
829	5	106	490	36	126	468	1784	161	25	2388	785	2159	2512	8035	2010-05-31 00:00:00	5	115
830	5	114	471	20	156	474	1723	161	16	2179	724	2098	2485	7689	2010-06-30 00:00:00	5	74
831	5	110	477	25	129	501	1746	212	37	2281	689	2117	2725	7383	2010-07-31 00:00:00	5	93
833	5	146	494	30	102	431	1728	206	37	2251	652	2134	2503	7771	2010-09-30 00:00:00	5	104
834	5	124	498	20	104	435	1741	195	14	2224	591	2083	2688	7901	2010-10-31 00:00:00	5	86
838	5	142	467	38	131	437	1798	203	11	2223	749	2237	2642	9329	2011-02-28 00:00:00	5	87
839	5	115	591	45	148	436	1999	167	23	2593	785	2447	2851	8281	2011-03-31 00:00:00	5	54
840	5	136	559	37	127	506	2001	176	26	2560	740	2359	2638	8035	2011-04-30 00:00:00	5	94
841	5	129	629	47	155	598	2062	250	34	2531	783	2501	2841	9632	2011-05-31 00:00:00	5	93
842	5	119	593	31	148	617	1939	200	23	2432	814	2303	2803	8561	2011-06-30 00:00:00	5	90
843	5	96	600	24	139	483	1838	173	28	2307	822	2151	3093	8496	2011-07-31 00:00:00	5	109
844	5	94	557	16	161	481	2073	133	18	2518	579	2033	3255	9545	2011-08-31 00:00:00	5	95
848	5	124	462	35	128	392	1904	187	7	2395	433	1822	2950	8555	2011-12-31 00:00:00	5	100
851	5	138	676	26	161	470	2305	221	5	2810	555	2301	3602	11457	2012-03-31 00:00:00	5	99
852	5	124	615	16	144	415	2233	228	10	2775	536	2286	3504	10996	2012-04-30 00:00:00	5	106
853	5	114	641	17	143	507	2563	302	27	2778	571	2281	3465	11857	2012-05-31 00:00:00	5	108
854	5	110	588	14	157	411	2217	232	8	2535	439	2069	3167	10845	2012-06-30 00:00:00	5	134
855	5	103	674	22	110	469	2111	216	18	2578	595	2149	3009	11615	2012-07-31 00:00:00	5	102
856	5	190	754	25	130	448	2473	250	7	2932	723	2329	3305	11963	2012-08-31 00:00:00	5	114
857	5	157	666	30	141	526	2211	174	29	2562	619	2173	2950	10189	2012-09-30 00:00:00	5	143
858	5	160	661	42	137	587	2195	176	32	2758	472	2205	3125	11155	2012-10-31 00:00:00	5	176
859	5	161	596	31	140	468	2163	182	45	2427	527	2133	2801	9901	2012-11-30 00:00:00	5	170
860	5	134	536	28	121	468	2224	179	39	2649	475	2028	2910	9505	2012-12-31 00:00:00	5	170
862	5	182	682	65	111	339	2485	220	67	2898	573	2525	3036	9107	2013-02-28 00:00:00	5	91
863	5	197	714	31	151	407	2765	290	55	2997	613	2783	3518	10036	2013-03-31 00:00:00	5	125
864	5	194	720	31	147	465	2544	233	54	3098	774	2990	3507	11083	2013-04-30 00:00:00	5	102
865	5	263	814	69	132	421	2796	335	131	3231	1300	3307	3256	10861	2013-05-31 00:00:00	5	117
866	5	194	575	29	110	427	2431	262	53	2988	732	2868	3304	10058	2013-06-30 00:00:00	5	115
867	5	146	562	33	110	440	2382	269	37	2875	690	2773	3310	9695	2013-07-31 00:00:00	5	85
868	5	194	594	47	112	604	2566	372	54	3050	728	2871	3396	9843	2013-08-31 00:00:00	5	88
869	5	174	565	35	119	444	2367	344	28	2883	702	2738	3089	8951	2013-09-30 00:00:00	5	92
870	5	162	527	40	109	443	2488	307	24	3118	750	2958	3380	9135	2013-10-31 00:00:00	5	117
871	5	200	542	44	111	417	2455	305	42	3038	650	2808	3199	9376	2013-11-30 00:00:00	5	110
872	5	188	446	30	122	391	2350	290	17	2816	596	2629	3402	8519	2013-12-31 00:00:00	5	104
874	5	234	480	41	110	346	2250	334	48	2788	639	2567	3366	9761	2014-02-28 00:00:00	5	95
875	5	160	508	35	124	428	2472	350	61	3022	644	2791	3620	8941	2014-03-31 00:00:00	5	110
876	5	184	434	27	129	465	2339	345	56	2830	669	2662	3669	9122	2014-04-30 00:00:00	5	98
877	5	205	576	23	101	433	2332	308	69	2826	742	2766	3446	9508	2014-05-31 00:00:00	5	85
878	5	118	529	42	120	359	2372	288	50	2901	644	2702	3286	9112	2014-06-30 00:00:00	5	96
879	5	250	635	41	122	407	2453	357	78	2923	794	2887	3349	9443	2014-07-31 00:00:00	5	94
880	5	311	682	47	100	319	2312	313	48	2782	847	2709	3360	9301	2014-08-31 00:00:00	5	88
881	5	259	609	48	104	346	2204	354	37	2767	781	2592	3380	8891	2014-09-30 00:00:00	5	108
882	5	327	690	57	104	364	2527	318	26	3094	614	2784	3344	8988	2014-10-31 00:00:00	5	119
883	5	237	473	47	93	477	2160	323	45	2675	663	2489	3258	8193	2014-11-30 00:00:00	5	89
884	5	148	397	30	91	394	2073	279	29	2524	583	2351	3200	7780	2014-12-31 00:00:00	5	112
886	5	241	506	51	109	363	2157	269	34	2591	586	2428	3188	8017	2015-02-28 00:00:00	5	98
887	5	291	661	73	148	469	2605	319	54	3062	818	3026	3352	9523	2015-03-31 00:00:00	5	114
888	5	335	627	68	125	392	2408	327	30	2895	871	2767	2952	7835	2015-04-30 00:00:00	5	97
889	5	416	660	61	106	353	2530	352	55	3084	835	2941	3060	8532	2015-05-31 00:00:00	5	84
890	5	556	685	60	112	273	2484	321	56	3004	780	2863	2732	8990	2015-06-30 00:00:00	5	74
891	5	573	609	66	102	327	2588	362	38	3110	1290	2922	2882	8739	2015-07-31 00:00:00	5	75
892	5	786	634	45	111	372	2690	379	42	3185	949	3048	2725	8919	2015-08-31 00:00:00	5	69
893	5	777	553	49	105	507	2542	403	6	3044	845	2802	2779	8183	2015-09-30 00:00:00	5	82
894	5	1213	585	45	100	327	2634	470	37	3169	961	2976	2952	8536	2015-10-31 00:00:00	5	73
895	5	1399	534	65	113	300	2469	384	36	2895	821	2799	3103	8076	2015-11-30 00:00:00	5	83
896	5	1175	406	54	125	354	2480	388	17	2852	751	2712	3009	8371	2015-12-31 00:00:00	5	106
899	5	666	833	27	110	397	3217	382	19	3835	1039	3496	2823	9675	2016-03-31 00:00:00	5	82
901	5	483	836	72	108	307	3004	442	21	3573	993	3256	2805	9028	2016-05-31 00:00:00	5	64
902	5	598	945	20	99	339	3064	323	5	3600	1258	3316	2704	9898	2016-06-30 00:00:00	5	64
910	5	259	677	19	90	308	2633	408	9	3107	1191	2920	2368	7967	2017-02-28 00:00:00	5	77
2292	13	158	211	25	42	98	460	45	7	527	316	702	188	1735	2010-12-31 00:00:00	13	22
2293	13	204	232	16	31	101	471	64	6	567	322	740	170	1631	2011-01-31 00:00:00	13	25
2294	13	178	219	20	34	108	504	67	17	592	308	682	208	2000	2011-02-28 00:00:00	13	21
2295	13	196	297	15	45	86	601	79	11	732	325	876	222	2086	2011-03-31 00:00:00	13	22
2297	13	204	270	12	41	115	550	67	27	683	382	852	227	2076	2011-05-31 00:00:00	13	16
2298	13	162	235	14	48	121	466	43	21	567	391	762	134	1867	2011-06-30 00:00:00	13	21
2299	13	148	202	8	42	118	424	52	14	488	364	651	199	1734	2011-07-31 00:00:00	13	23
2300	13	161	224	9	36	79	539	59	23	655	409	840	187	2017	2011-08-31 00:00:00	13	24
2365	13	206	283	18	26	191	587	86	17	767	476	1082	214	2212	2017-01-31 00:00:00	13	19
2366	13	180	254	13	28	91	571	54	27	695	638	1193	173	2213	2017-02-28 00:00:00	13	26
\.


--
-- Name: instance_id_seq; Type: SEQUENCE SET; Schema: public; Owner: aurea
--

SELECT pg_catalog.setval('instance_id_seq', 2366, true);


--
-- Data for Name: saopaulopolice_attribute; Type: TABLE DATA; Schema: public; Owner: aurea
--

COPY saopaulopolice_attribute (saopaulopolice_attribute_id, saopaulopolice_attribute_name, saopaulopolice_attribute_category) FROM stdin;
1	drug_possession	occurrence
5	seized_firearms	number
2	drug_traffic	occurrence
12	recovered_vehicles	number
13	police_inquiries	total
9	people_arrested_in_flagrante	number
3	drug_seizure	occurrence
10	people_arrested_on_warrant	number
7	offenders_detained_in_flagrante	number
8	offenders_detained_on_warrant	number
4	illegal_weapon_possession	occurrence
11	prisons_issued	number
6	flagrant_issued	number
14	murder	violent_crime
\.


--
-- Name: firstkey_area; Type: CONSTRAINT; Schema: public; Owner: aurea
--

ALTER TABLE ONLY area
    ADD CONSTRAINT firstkey_area PRIMARY KEY (area_id);


--
-- Name: firstkey_instace; Type: CONSTRAINT; Schema: public; Owner: aurea
--

ALTER TABLE ONLY instance
    ADD CONSTRAINT firstkey_instace PRIMARY KEY (instance_id);


--
-- Name: firstkey_saopaulopolice_attribute; Type: CONSTRAINT; Schema: public; Owner: aurea
--

ALTER TABLE ONLY saopaulopolice_attribute
    ADD CONSTRAINT firstkey_saopaulopolice_attribute PRIMARY KEY (saopaulopolice_attribute_id);


--
-- Name: instance_area_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aurea
--

ALTER TABLE ONLY instance
    ADD CONSTRAINT instance_area_id_fkey FOREIGN KEY (area_id) REFERENCES area(area_id);


--
-- Name: public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM postgres;
GRANT ALL ON SCHEMA public TO postgres;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

